<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

// Start session

// Database connection
include 'include/db_connection.php';

// Include PHPMailer classes
 
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $name = $_POST['txtname'];
    $email = $_POST['txtemail'];
    $password = $_POST['password']; // Not hashed as requested
    $profile_image = $_FILES['profile_image'];

    // Validate file (profile image)
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $fileExtension = strtolower(pathinfo($profile_image['name'], PATHINFO_EXTENSION));
    $fileSize = $profile_image['size'];

    if (!in_array($fileExtension, $allowedExtensions) || $fileSize > 3145728) {
        echo json_encode(['success' => false, 'message' => 'Invalid image file. Only JPG, PNG, and GIF files under 3MB are allowed.']);
        exit;
    }

    // Save the image to the uploads directory
    $targetDir = "uploads/"; 
    $targetFile = $targetDir . basename($profile_image['name']);
    move_uploaded_file($profile_image['tmp_name'], $targetFile);

    // Insert user data into the database
    $query = "INSERT INTO user (names, email, passwords, profile_img) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $name, $email, $password, $targetFile);

    if ($stmt->execute()) {
        // Initialize PHPMailer object
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = 0; // Disable verbose debug output
            $mail->isSMTP(); // Send using SMTP
            $mail->Host = 'mail.skillgewin.com'; // Set the SMTP server to send through
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'noreply@skillgewin.com'; // SMTP username
            $mail->Password = '@Noreply12345#'; // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption
            $mail->Port = 465;
 
            //Recipients
            $mail->setFrom('noreply@skillgewin.com', 'SKILLGEWIN');
            $mail->addAddress($email);

            // Add embedded image
            $mail->addEmbeddedImage('img/logo.jpg', 'logo_cid'); // Provide correct path to your logo
            $logo = "<img src='cid:logo_cid' alt='SKILLGEWIN Logo' style='display: block; margin: 0 auto; width: 200px;'>";

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mailContent = "$logo <br> <h1>Welcome to SKILLGEWIN</h1>
            Hi  $name, <br>
            <p style='text-align: justify; font-size: 18px;'>Congratulations on taking the first step towards unlocking your potential! We're thrilled to welcome you to Skillgewin, your premier online learning platform. </p>
            <p style='text-align: justify; font-size: 18px;'>
            Thank you for registering with us. We're excited to have you on board and look forward to helping you achieve your learning goals.
            </p>
            <div style=' font-size: 18px;'>
            
            - Access to high-quality courses and tutorials <br>
- Expert instructors and industry professionals <br>
- Personalized learning paths and recommendations <br>
- Interactive community forums and support<br> <br>
 To get started: <br>
            </div>
            <div style=' font-size: 18px;'>
            1. Explore our course catalog: [insert link] <br>
2. Complete your profile: [insert link]<br>
3. Join our community forums: [insert link]<br>
<br>

Need Help?<br>
<br>

Contact us: support@skillgewin.com<br>

<br>
We're honored to be part of your learning journey. Let's grow and succeed together! <br>
<br>

Best regards,

            </div>
            
            
          
            <footer style='text-align: center; background: green; color: white;padding: 20px'>SKILLGEWIN Team</footer>
            ";
            $mail->Subject = 'Welcoming Message';
            $mail->Body = $mailContent;
            $mail->AltBody = 'Welcome to SKILLGEWIN';
            echo '<script> 
            //alert("Account Successful created");
            
            window.location.href = "loginUser.php"; </script>';
            // Send the email
            if ($mail->send()) {
                echo '<script> 
                alert("Account Successful created")
                window.location.href = "loginUser.php"; </script>';
                // echo json_encode(['success' => true]);
            } else {
                echo '<script> 
                alert("Account Not created") </script>';
                // echo json_encode(['success' => false, 'message' => 'Failed to send verification email.']);
            }
        } catch (Exception $e) {
            // echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
        }
    } else {
        // echo json_encode(['success' => false, 'message' => 'Failed to create account.']);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
