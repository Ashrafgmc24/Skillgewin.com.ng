<?php
session_start();
include 'include/db_connection.php';

// Fetch product details for items in the cart
$cart_items = [];
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $product_id => $details) {
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
            $product['quantity'] = $details['quantity']; // Add the quantity from the session
            $cart_items[] = $product;
        }
        $stmt->close();
    }
} else {
    echo "Your cart is empty.";
}

$conn->close();
$title = "Your Cart";
include 'include/webheader1.php';
?>

    <div class="container mt-5" data-aos="zoom" data-aos-duration="1000" data-aos-delay="500">
        <h2>Your Cart</h2>
        <?php if (!empty($cart_items)) { ?>
            <table class="table table-striped" >
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody> 
                    <?php foreach ($cart_items as $item) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td>$<?php echo number_format($item['price'], 2); ?></td>
                            <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                            <td>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <!-- Proceed to checkout button -->
            <a href="checkout.php" class="btn btn-success">Proceed to Checkout</a>
        <?php } else { ?>
            <p>Your cart is empty.</p>
        <?php } ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<?php  
include 'include/webfooter.php';
?>