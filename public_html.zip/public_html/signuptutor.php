<?php session_start() ?>

<?php   
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

$title = "Signup As Tutor";
include 'include/webheader1.php';
include 'include/db_connection.php'; // Include your database connection file
?>
      
      <?php // include "include/subject.php"; ?>
      
      <form id="regForm" action="" method="post" enctype="multipart/form-data">

<h1 class="w3-center"><i class="fas fa-chalkboard-teacher"></i> Signup As Tutor:</h1>

<!-- One "tab" for each step in the form: -->
<div class="tab">Name:
  <p><input required type="text" name="txtname" id="txtname" placeholder="First name..." oninput="this.className = ''"></p>
  <p><input required type="email" name="txtemail" id="txtemail" placeholder="Email Address." oninput="this.className = ''"></p>
</div>

<div class="tab">Contact Info:
  <p><input type="text" placeholder="Phone No..." id="txtphone" name="txtphone" oninput="this.className = ''"></p>
  <p><input type="password" placeholder="Password" id="txtpass" name="txtpass" oninput="this.className = ''"></p>
  <p>
      <p>Country</p>
      <select id="country" name="country" class="" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
          <option value=""></option>
          <?php include 'include/countries.php'; ?>
      </select>
  </p>
  
  <p><input type="text" placeholder="Location" id="txtlocation" name="txtlocation" oninput="this.className = ''"></p>
 <h4 class="w3-center">Good to know</h4>
 <div class="card">
     <div class="card-body">
     <ul class="w3-ul">
         <li>Your address will never appear on the site. It will only be given to the students you agree to teach.</li>
         <li>You can offer your lessons at home at the address indicated</li>
         <li>"You can travel" indicates that classes can be held at the student's home or at another location that you determine together.</li>
         <li>You can also teach your classes around the world via webcam!</li>
     </ul></div>
</div>
</div>

<div class="tab">About Your Skill:
  <p><input type="hidden" placeholder="Experience" id="txtexperience" name="txtexperience" oninput="this.className = ''" value="About Your Skill"></p>
  <!--<p><input type="text" placeholder="Skills" id="txtsubject" name="txtsubject" oninput="this.className = ''"></p>-->
  
  <!---->
  <p>Select Academic or Skill:</p>
  <select id="txtsubject" name="txtsubject" class="" oninput="showSubjectInput()">
      <option value=""></option>
    <option value="Skill">Skill</option>
    <option value="Academic">Academic</option>
</select>

<!-- Skill input field -->
<div id="skillInput" style="display:none;">
    <label for="skillDetails">Enter your Skill:</label>
    <textarea style="resize: none; width: 100%; height:50px; name="skillDetails" id="" cols="30" rows="10" id="skillDetails" name="skillDetails" placeholder="e.g., Coding, Painting"></textarea>
</div>

<!-- Academic input field -->
<div id="academicInput" style="display:none;">
    <label for="academicSubject">Enter your Academic Subject:</label>
    <textarea style="resize: none;  width: 100%; height:50px; cols="30" rows="10" id="academicSubject" name="academicSubject" placeholder="e.g., Mathematics, Physics"></textarea>
</div>

<script>
function showSubjectInput() {
    var selectedValue = document.getElementById("txtsubject").value;
    if (selectedValue === "Academic") {
        document.getElementById("academicInput").style.display = "block";
        document.getElementById("skillInput").style.display = "none";
    } else {
        document.getElementById("skillInput").style.display = "block";
        document.getElementById("academicInput").style.display = "none";
    }
}
</script>

  <!---->
  <p><input type="hidden" placeholder="Title" id="txttitle" name="txttitle" oninput="this.className = ''" value="Title"></p>
</div>

<div class="tab">About Lesson: (Not less than 12 words)
  <p><textarea style="resize: none; width: 100%;" id="txtaboutlesson" name="txtaboutlesson" placeholder="Now is the time to convince future students of your personal approach to private tutoring." class="w3-input" name="" id="" cols="30" rows="10" oninput="this.className = ''"></textarea></p>
</div>

<div class="tab">About You: (Not less than 40 words)
  <p><textarea style="resize: none; width: 100%;" id="txtaboutyou" name="txtaboutyou" placeholder="Tell your future students who you are and why you want to teach." class="w3-input" name="" id="" cols="30" rows="10" oninput="this.className = ''"></textarea></p>
  <h4 class="w3-center">Good to know</h4>
 <div class="card">
     <div class="card-body">
     <ul class="w3-ul">
         <li>    
Inspire confidence, establish your legitimacy and reassure students of your professionalism. </li>
<li>
This is one of the first things that the students will read about you, remember to take care of your spelling and grammar.</li>
 </div>
 </div>
 <!---->
</div>
<div class="tab">Hourly Rate: (Example: N3000 P/H)
  <p><input type="number"  id="txthour" name="txthour" placeholder="3000" class="w3-input"></p>
</div>

<div class="tab">Profile Image (A Beautiful Image of less than 3MB)
  <p><input type="file" name="profile" id="profile_image" class="w3-input" id="profile"></p>
  <p>Preview Image</p>
        <img id="imagePreview" src="#" alt="Image Preview" style="display:none; width:100px; height:100px;">

</div>
<div class="tab">Save
  <p><input type="submit" name="btnsubmit" class="w3-btn w3-green w3-round" value="Submit" id="btns"></p>
</div>
<div style="overflow:auto;">
  <div style="float:right;" class="w3-padding">
    <button type="button" class="w3-green w3-round w3-padding" style="font-size: 16px" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" class="w3-green w3-round w3-padding" style="font-size: 16px" onclick="nextPrev(1)">Next</button>
  </div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>
<hr>
<div class="w3-center">
  <p>Already have Account</p>
<a href="loginTutor.php" style="color:white" class="w3-btn w3-green"><i class="fa fa-lock"></i> Sign in</a>
</div>
<hr>
<!--<script src="save_js.js"></script>-->
<!-- Modals -->

<div id="progressModal" class="w3-modal">
  <div class="w3-modal-content w3-round-large w3-card-4" style="max-width:400px;">
    <header class="w3-container w3-green">
      <h2 class="w3-center">Submitting Data</h2>
    </header>
    <div class="w3-container">
      <p>Please wait...</p>
      <div class="w3-light-grey w3-round">
        <div id="progressBar" class="w3-green w3-round" style="height:24px;width:0%"></div>
      </div>
    </div>
  </div>
</div>

<?php
if (isset($_POST['btnsubmit'])) {
    include 'include/db_connection.php'; // Include your database connection file

    $name = $_POST['txtname'];
    $email = $_POST['txtemail'];
    $phone = $_POST['txtphone'];
    $password = $_POST['txtpass'];
    $country = $_POST['country'];
    $location = $_POST['txtlocation'];
    $experience = $_POST['txtexperience'];
    $subject = $_POST['txtsubject'];
    $txtskillDetails = $_POST['skillDetails'];
    $txtacademicSubject = $_POST['academicSubject'];
    $title = $_POST['txttitle'];
    $aboutLesson = $_POST['txtaboutlesson'];
    $aboutYou = $_POST['txtaboutyou']; 
    $hourlyRate = $_POST['txthour'];

    // File upload handling (for profile image)
    $allowedTypes = ['image/jpeg', 'image/png'];
    $maxFileSize = 3 * 1024 * 1024; // 3MB

    if (isset($_FILES['profile']) && $_FILES['profile']['error'] === UPLOAD_ERR_OK) {
        $profileImage = $_FILES['profile']['name'];
        $profileImageType = $_FILES['profile']['type'];
        $profileImageSize = $_FILES['profile']['size'];
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($profileImage);
        
        // Validate file type
        if (!in_array($profileImageType, $allowedTypes)) {
            echo json_encode(['status' => 'error', 'message' => 'Only JPG and PNG images are allowed.']);
            exit();
        }

        // Validate file size
        if ($profileImageSize > $maxFileSize) {
            echo json_encode(['status' => 'error', 'message' => 'File size must be less than 3MB.']);
            exit();
        }

        // Move the uploaded file
        if (!move_uploaded_file($_FILES['profile']['tmp_name'], $targetFile)) {
            echo json_encode(['status' => 'error', 'message' => 'Error uploading the file.']);
            exit();
        }
    } else {
        $profileImage = null;
    }

    // Insert into the database
    $sql = "INSERT INTO tutor (names, email, phone, passwords, country, locations, experience, subjects, skills, academic,
    title, about_lesson, about_you, hourly_rate, profile_img) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssss", $name, $email, $phone, $password, $country, $location, $experience, $subject, $txtskillDetails, $txtacademicSubject, $title, $aboutLesson, $aboutYou, $hourlyRate, $profileImage);



    if ($stmt->execute()) {
        $_SESSION["ready"] = "Okay";
        $_SESSION["usernameT"] = $_POST['txtname'];
        $_SESSION["email"] = $email;
        $_SESSION["name"] = $name;
        $_SESSION['tutor_id'] = $email;
        // echo json_encode(['status' => 'success']);
        
    echo "<script> window.location.href ='getready.php';</script>";

    } else {
        // echo json_encode(['status' => 'error', 'message' => 'Error saving the tutor data']);
        echo "<script> window.location.href='signuptutor.php'</script>";
        
    }

    $stmt->close();
    $conn->close();
}
?>


   
    <script>
       $("#profile_image").change(function() {
    let reader = new FileReader();
    reader.onload = function(e) {
      $('#imagePreview').attr('src', e.target.result).show();
    }
    reader.readAsDataURL(this.files[0]); // Read the image file as a data URL
  });

    var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
    // document.getElementById("nextBtn").style.display = "none";
    
  } else {
    // document.getElementById("nextBtn").style.display = "inline";

    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  // if (currentTab >= x.length) {
  //   //...the form gets submitted:
  //   document.getElementById("regForm").submit();
  //   return false;
  // }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
    </script>

    <?php  

include 'include/webfooter.php';
?>
