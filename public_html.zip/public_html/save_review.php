<?php
session_start();
include "include/db_connection.php";

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tutor_id'], $_POST['rating'], $_POST['review'])) {
    // Check if session user ID is set
    if (!isset($_SESSION['user_id'])) {
        die("User not logged in");
    }
    
    $user_id = $_SESSION['user_id'];
    $tutor_id = intval($_POST['tutor_id']);
    $rating = intval($_POST['rating']);
    $review = htmlspecialchars($_POST['review']);

    // Check if the tutor ID exists in the tutor table to prevent foreign key violation
    $check_tutor_sql = "SELECT id FROM tutor WHERE id = ?";
    $stmt = $conn->prepare($check_tutor_sql);
    $stmt->bind_param("i", $tutor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        // Tutor does not exist, return an error
        die("Tutor not found. Review cannot be submitted.");
    }

    // Check if a review already exists for this tutor by the user
    $check_sql = "SELECT id FROM reviews WHERE user_id = ? AND tutor_id = ?";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("ii", $user_id, $tutor_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // // Update existing review
        // $update_sql = "UPDATE reviews SET rating = ?, review = ?, review_time = NOW() WHERE user_id = ? AND tutor_id = ?";
        // $stmt = $conn->prepare($update_sql);
        // $stmt->bind_param("isii", $rating, $review, $user_id, $tutor_id);  // Bind all four parameters
    } else {
        // Insert new review
        $insert_sql = "INSERT INTO reviews (user_id, tutor_id, rating, review, review_time) VALUES (?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("iiis", $user_id, $tutor_id, $rating, $review);
    }

    if ($stmt->execute()) {
        header("Location: contacted_tutors.php"); // Redirect after success
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    die("Invalid request.");
}
?>
