<?php
session_start();
@include __DIR__ . "include/db_connection.php";
$tutor_id = $_GET['tutor_id'];
if (!isset($_GET['tutor_id'])) {
    echo json_encode(['user_name' => 'Unknown User']);
    exit();
}


$query = "SELECT names FROM tutor WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row) {
    echo json_encode(['user_name' => $row['names']]);
} else {
    echo json_encode(['user_name' => 'Unknown User']);
}
?>
