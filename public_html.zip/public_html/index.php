<?php  
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$title ="Home - SKILLGEWIN";

include "include/webheader1.php"; // Header file
include "include/db_connection.php"; // Database connection

$page = "index.php";
include "include/mysearch.php"; // Search functionality

?>
<section class="w3-container">
<div class="w3-row">
    <div class="w3-half w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <button class="w3-btn w3-green w3-round-xlarge w3-hover w3-margin-top" onclick="usertutor()">
            <i class="fas fa-chalkboard-teacher"></i> Tutoring Jobs
        </button>
    </div>
    <div class="w3-half w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <button class="w3-btn w3-green w3-round-xlarge w3-hover w3-margin-top" onclick="userpage()">
            <i class="fa fa-user"></i> Create Account
        </button>
    </div>
</div>


<section class="container my-5 w3-white">
        <h6 class="w3-center" data-aos="fade-up" data-aos-delay="200"><span class="w3-gray w3-round w3-padding w3-text-white">Categories</span></h6>
<br>
    <div class="text-center mb-5">
        <h2 data-aos="fade-up" data-aos-delay="200">Browse Tutors by Categories</h2>
        <?php
include 'include/db_connection.php'; // Adjust the path based on your setup

// Query to count tutors in each category
$query = "
    SELECT 
        SUM(CASE WHEN subjects = 'Academic' THEN 1 ELSE 0 END) AS total_academics,
        SUM(CASE WHEN subjects = 'Skill' THEN 1 ELSE 0 END) AS total_skills
    FROM tutor";

$result = $conn->query($query);

// Fetch results
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalAcademics = $row['total_academics'];
    $totalSkills = $row['total_skills'];
} else {
    $totalAcademics = 0;
    $totalSkills = 0;
}
?>

    </div>
    <div class="row justify-content-center">
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="card2 shadow-sm w3-white">
                <i class="fas fa-book-open icon-circle2"></i>
                <h4 class="mt-3">Academics</h4>
                 <p><?php echo $totalAcademics; ?> Tutors</p> 
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="card2 shadow-sm w3-white">
                <i class="fas fa-cogs icon-circle2"></i>
                <h4 class="mt-3">Skill Acquisition</h4>
                 <p><?php echo $totalSkills; ?> Tutors</p>
            </div>
        </div>
    </div>
</section>


<script>
function userpage() {
    window.location.href = "signupuser.php";
}
function usertutor() {
    window.location.href = "signuptutor.php";
}
function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    document.getElementById(cityName).style.display = "block";
}
</script>

<!-- Tutor Cards Section -->
<div class="container my-5 w3-white">
    <h2 class="text-center mb-4" data-aos="fade-up" data-aos-delay="200">Learn and grow with help from world-class tutors <i class="fas fa-star" style="color: #f39c12;"></i></h2>
    <div class="row" id="tutor-results">
        <!-- Fetch Tutor Data -->
        <?php
        $select = "SELECT * FROM tutor";
        $result = $conn->query($select);

        if (!$result) {
            // Output error if query fails
            die("Query Error: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Calculate the number of stars to display
                // $full_stars = floor($row['rating']);
                // $empty_stars = 5 - $full_stars;
        ?>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
            <div class="card">
                <img src="uploads/<?php echo $row['profile_img']; ?>" alt="Tutor Image" class="card-img-top">
                <i class="fas fa-heart favorite-icon"></i>
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($row['names']); ?></h5>
                    <!--<p class="card-text w3-text-black"><i class="fa fa-map-marker"></i> <?php //echo htmlspecialchars($row['locations']); ?></p>-->
                    <p class="card-text w3-text-black"><?php echo htmlspecialchars($row['webcam_face']); ?></p>
                    <div class="star-rating mb-2">
                        <?php 
                        // Display full stars
                        // for ($i = 0; $i < $full_stars; $i++) {
                        //     echo '<i class="fas fa-star"></i>';
                       // }
                        // Display empty stars
                        // for ($i = 0; $i < $empty_stars; $i++) {
                        //     echo '<i class="far fa-star"></i>';
                       // } 
                        ?>
                        <!--<span>(<?php //echo $row['subjects']; ?> )</span>-->
                    </div>
                    <p class="card-text w3-text-black"><?php echo htmlspecialchars($row['about_you']); ?></p>
                    <p class="price">₦<?php echo number_format($row['hourly_rate'], 2); ?>/h <span class="first-lesson">- 1st lesson free</span></p>
                    <a href="tutor_detail1.php?tutor_id=<?php echo $row['id']; ?>" class="w3-link">Review</a>

                </div>
            </div>
        </div>
        <?php
            }
        } else {
            echo "<p class='text-center'>No tutors found.</p>";
        }
        ?>
    </div>
</div>


<?php include "include/webfooter.php"; ?> <!-- Footer file -->
