<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

include "include/db_connection.php";



// require '';
// require '';
// require '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $tutor_id = $_SESSION['tutor_id'];
    $action = $_POST['action'];

    if ($action === 'accept') {
        // Fetch tutor details
        $query = $conn->prepare("SELECT names, phone, email, country, locations FROM tutor WHERE id = ?");
        $query->bind_param("i", $tutor_id);
        $query->execute();
        $result = $query->get_result();
        $tutor = $result->fetch_assoc();
        $mail = new PHPMailer(true);
 //Server settings
    $mail->SMTPDebug = 0;                      // Enable verbose debug output
    $mail->isSMTP();                           // Send using SMTP
    $mail->Host       = 'mail.skillgewin.com'; // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                  // Enable SMTP authentication
    $mail->Username   = 'noreply@skillgewin.com'; // SMTP username
    $mail->Password   = '@Noreply12345#';       // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption; `PHPMailer::ENCRYPTION_STARTTLS` also accepted 
    $mail->Port       = 465;    
    
        // Prepare the email
        $mail = new PHPMailer(true);
        $mail->setFrom('noreply@skillgewin.com', 'Your Name');
        $mail->addAddress($user_id); // Set user's email address
        $mail->Subject = "Your contact request has been accepted";
        $mail->Body = "Hello,\n\nYour contact request has been accepted by Tutor: {$tutor['names']}\n\n"
                    . "Tutor Details:\n"
                    . "Name: {$tutor['names']}\n"
                    . "Phone: {$tutor['phone']}\n"
                    . "Email: {$tutor['email']}\n"
                    . "Country: {$tutor['country']}\n"
                    . "Location: {$tutor['location']}\n\n"
                    . "Best Regards,\nYour Tutor Team";
        
        if (!$mail->send()) {
            echo "Mailer Error: " . $mail->ErrorInfo;
        }

        // Update the contact_tutor table to set accepted status
        $updateQuery = $conn->prepare("UPDATE contact_tutor SET accepted = 'Accepted' WHERE user_id = ? AND tutor_id = ?");
        $updateQuery->bind_param("ii", $user_id, $tutor_id);
        $updateQuery->execute();

        echo "Accepted user with ID: $user_id";

    } elseif ($action === 'decline') {
        // Send approval email
        $mail = new PHPMailer(true);
          $mail->SMTPDebug = 0;                      // Enable verbose debug output
    $mail->isSMTP();                           // Send using SMTP
    $mail->Host       = 'mail.skillgewin.com'; // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                  // Enable SMTP authentication
    $mail->Username   = 'noreply@skillgewin.com'; // SMTP username
    $mail->Password   = '@Noreply12345#';       // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption; `PHPMailer::ENCRYPTION_STARTTLS` also accepted 
    $mail->Port       = 465;  
    
        $mail->setFrom('noreply@skillgewin.com', 'Your Name');
        $mail->addAddress($user_id); // Set user's email address
        $mail->Subject = "Your contact request has been declined";
        $mail->Body = "Hello,\n\nYour contact request has been declined.\n\n"
                    . "Best Regards,\nYour Tutor Team";

        if (!$mail->send()) {
            echo "Mailer Error: " . $mail->ErrorInfo;
        }
// Update the contact_tutor table to set accepted status
        $updateQuery = $conn->prepare("UPDATE contact_tutor SET accepted = 'Declined' WHERE user_id = ? AND tutor_id = ?");
        $updateQuery->bind_param("ii", $user_id, $tutor_id);
        $updateQuery->execute();
        
        echo "Declined user with ID: $user_id";

    } elseif ($action === 'delete') {
        // Delete the contact record
        $query = $conn->prepare("DELETE FROM contact_tutor WHERE user_id = ? AND tutor_id = ?");
        $query->bind_param("ii", $user_id, $tutor_id);
        $query->execute();
        echo "Deleted user contact with ID: $user_id";
    }

    // Redirect back to the tutor dashboard
    header("Location: tutor_dashboard.php");
    exit();
}
?>
