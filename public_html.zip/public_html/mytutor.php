<?php
session_start();
$title = "My Contacted Tutors";
include "include/webheader_dash.php";
include "include/db_connection.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: loginUser.php");
    exit(); 
}

// Get the current user's ID from the session
$user_id = $_SESSION['user_id'];

// Fetch tutors contacted by the current user from contact_tutor table
$sql = "SELECT tutor.id, tutor.names, tutor.locations, tutor.profile_img, tutor.experience, tutor.hourly_rate, tutor.about_you
        FROM tutor
        JOIN contact_tutor ON tutor.id = contact_tutor.tutor_id
        WHERE contact_tutor.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

?>

<!-- Display the list of tutors the user has contacted -->
<div class="container my-5">
    <h2 class="text-center mb-4">My Contacted Tutors</h2>
    
    <?php if ($result->num_rows > 0) { ?>
        <div class="row">
            <?php while ($tutor = $result->fetch_assoc()) { 
                // Fetch existing review and rating for this tutor by the user
                $review_sql = "SELECT rating, review FROM reviews WHERE user_id = ? AND tutor_id = ?";
                $review_stmt = $conn->prepare($review_sql);
                $review_stmt->bind_param("ii", $user_id, $tutor['id']);
                $review_stmt->execute();
                $review_result = $review_stmt->get_result();
                $existing_review = $review_result->fetch_assoc();
            ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="uploads/<?php echo htmlspecialchars($tutor['profile_img']); ?>" alt="Tutor Image" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($tutor['names']); ?></h5>
                            <!--<p><strong>Location:</strong> <?php //echo htmlspecialchars($tutor['locations']); ?></p>-->
                            <!--<p><strong>Experience:</strong> <?php //echo htmlspecialchars($tutor['experience']); ?></p>-->
                            <p class="card-text w3-text-black"><strong>About You: </strong><?php echo htmlspecialchars($tutor['about_you']); ?></p>
                            <p><strong>Hourly Rate:</strong> ₦<?php echo number_format($tutor['hourly_rate'], 2); ?></p>

                            <!-- Rate Button -->
                            <button class="btn btn-primary" data-toggle="modal" data-target="#rateModal<?php echo htmlspecialchars($tutor['id']); ?>" 
                                data-tutorid="<?php echo $tutor['id']; ?>" 
                                data-rating="<?php echo $existing_review ? $existing_review['rating'] : ''; ?>" 
                                data-review="<?php echo $existing_review ? htmlspecialchars($existing_review['review']) : ''; ?>">
                                <?php echo $existing_review ? 'Update Rating' : 'Rate'; ?>
                            </button>
                        </div>

                        <!-- Reviews Section -->
                        <div class="reviews-section mt-3" style="max-height: 150px; overflow-y: scroll;">
                            <div class="card">
                                <div class="card-body">
                                    
                                
                            <h6>Reviews:</h6>
                            <?php if ($existing_review) { ?>
                                <p><strong>Rating:</strong>
                                    <!-- Display Stars -->
                                    <?php
                                    $full_stars = floor($existing_review['rating']); // Full stars
                                    $empty_stars = 5 - $full_stars; // Empty stars
                                    
                                    // Display full stars
                                    for ($i = 0; $i < $full_stars; $i++) {
                                        echo '<i class="fas fa-star text-warning"></i>';
                                    }

                                    // Display empty stars
                                    for ($i = 0; $i < $empty_stars; $i++) {
                                        echo '<i class="far fa-star text-warning"></i>';
                                    }
                                    ?>
                                </p>
                                
                                <p><strong>Review:</strong> <?php echo htmlspecialchars($existing_review['review']); ?></p>
                                </div>
                            </div>
                            <?php } else { ?>
                                <p>No reviews yet.</p>
                                
                            <?php } ?>
                        </div>
                    </div>
                </div>
                
                <!-- Modal for Adding/Updating Review and Rating -->
                <div class="modal fade" id="rateModal<?php echo htmlspecialchars($tutor['id']); ?>" tabindex="-1" aria-labelledby="rateModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form id="rateForm" method="POST">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="rateModalLabel">Rate and Review Tutor</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <!-- Hidden input to hold tutor_id -->
                                    <input type="hidden" name="tutor_id" id="tutor_id" value="<?php echo htmlspecialchars($tutor['id']); ?>">
                                    <div class="form-group">
                                        <label for="rating">Rating</label>
                                        <select name="rating" id="rating" class="form-control" required>
                                            <option value="5" <?php if($existing_review && $existing_review['rating'] == 5) echo 'selected'; ?>>5 Stars</option>
                                            <option value="4" <?php if($existing_review && $existing_review['rating'] == 4) echo 'selected'; ?>>4 Stars</option>
                                            <option value="3" <?php if($existing_review && $existing_review['rating'] == 3) echo 'selected'; ?>>3 Stars</option>
                                            <option value="2" <?php if($existing_review && $existing_review['rating'] == 2) echo 'selected'; ?>>2 Stars</option>
                                            <option value="1" <?php if($existing_review && $existing_review['rating'] == 1) echo 'selected'; ?>>1 Star</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="review">Review</label>
                                        <textarea name="review" id="review" class="form-control" rows="4" required><?php echo $existing_review ? htmlspecialchars($existing_review['review']) : ''; ?></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" name="btnrate" class="btn btn-primary">Save Review</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
            <?php } ?>
        </div>
    <?php } else { ?>
        <p class="text-center">You have not contacted any tutors yet.</p>
    <?php } ?>
</div>

<?php
if(isset($_POST['btnrate'])){
    $user_id = $_SESSION['user_id'];
    $tutor_id = $_POST['tutor_id'];
    $rating = $_POST['rating'];
    $review = $_POST['review'];

    // Insert the review and rating into the database
    $insert_sql = "INSERT INTO reviews (user_id, tutor_id, rating, review, review_time) 
                   VALUES (?, ?, ?, ?, NOW())
                   ON DUPLICATE KEY UPDATE rating = VALUES(rating), review = VALUES(review), review_time = NOW()";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("iiis", $user_id, $tutor_id, $rating, $review);
    if ($stmt->execute()) {
      //  header("Location: contacted_tutors.php");// Redirect after success
        echo "<script> window.location.href='mytutor.php'; </script>";
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<script>
// jQuery to dynamically set tutor_id and populate existing review/rating in the modal
$('#rateModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); // Button that triggered the modal
    var tutorId = button.data('tutorid'); // Extract tutor_id from data attribute
    var rating = button.data('rating') || 5; // Default rating is 5 if none exists
    var review = button.data('review') || ''; // Default review is empty

    // Update the modal's form fields with the data
    var modal = $(this);
    modal.find('#tutor_id').val(tutorId);
    modal.find('#rating').val(rating);
    modal.find('#review').val(review);
});
</script>

<?php include "include/webfooter.php"; ?>
