<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: loginUser.php");
    exit();
}

$title = "My Dashboard";
include "include/webheader_dash.php";
include "include/db_connection.php";
?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <!-- List of Contacted Tutors -->
            <button class="btn btn-primary d-md-none mb-2" id="toggleUsersBtn">
                Contacted Tutors
            </button>
<div id="contactedUsersSidenav" class="w3-sidebar w3-bar-block w3-light-grey" style="">

            <h4>Contacted Tutors</h4>
            <ul id="tutorList">
                <!-- Dynamic list of tutors the user has contacted -->
            </ul>
        </div>
        <div class="col-md-8">
            <!-- Chat window -->
            <div id="chatWindow" style="border: 1px solid #ccc; padding: 20px; height: 400px; overflow-y: scroll;">
                <!-- Messages will be displayed here -->
            </div>
            <!-- Message Input -->
            <div class="mt-2">
                <input type="hidden" id="receiver_id" value=""> <!-- The tutor or user being contacted -->
                <textarea id="messageInput" class="form-control" placeholder="Type your message..."></textarea>
                <button id="sendMessageBtn" class="btn btn-primary mt-2">Send</button>
            </div>
        </div>
    </div>
</div>
<script>
// Fetch list of tutors the user has contacted
fetch('fetch_contacted_tutors.php')
    .then(response => response.json())
    .then(tutors => {
        const tutorList = document.getElementById('tutorList');
        tutorList.innerHTML = '';  // Clear any previous data

        if (tutors.length === 0) {
            tutorList.innerHTML = '<li>No tutors contacted yet.</li>';
            return;
        }

        tutors.forEach(tutor => {
            const li = document.createElement('li');
            li.textContent = tutor.names;
            li.classList.add('list-group-item', 'tutor-item');
            li.setAttribute('data-tutorid', tutor.id);  // Store the tutor ID as a data attribute

            // Attach the event listener to each tutor
            li.addEventListener('click', function() {
                const tutorId = this.getAttribute('data-tutorid');
                loadMessages(tutorId);  // Load the chat messages for the selected tutor
            });

            tutorList.appendChild(li);
        });
    })
    .catch(error => {
        console.error('Error fetching tutors:', error);
    });

// Load chat messages for the selected tutor
function loadMessages(tutor_id) {
    console.log(`Loading messages for tutor ID: ${tutor_id}`);  // Debugging log
    document.getElementById('receiver_id').value = tutor_id;  // Set the hidden field with the tutor ID

    fetch(`fetch_messages.php?receiver_id=${tutor_id}`)
        .then(response => response.json())
        .then(messages => {
            const chatWindow = document.getElementById('chatWindow');
            chatWindow.innerHTML = '';  // Clear previous messages

            if (messages.length === 0) {
                chatWindow.innerHTML = '<p>No messages yet. Start the conversation!</p>';
                return;
            }

            messages.forEach(message => {
                const msg = document.createElement('p');
                msg.textContent = message.message;  // Display the message content
                chatWindow.appendChild(msg);
            });
        })
        .catch(error => {
            console.error('Error loading messages:', error);
        });
}

// Send a new message
document.getElementById('sendMessageBtn').addEventListener('click', function () {
    const receiver_id = document.getElementById('receiver_id').value;
    const message = document.getElementById('messageInput').value.trim();

    if (message === '' || receiver_id === '') {
        alert('Please select a tutor and type a message.');
        return;
    }

    // Sending the message via POST request
    fetch('send_message.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `receiver_id=${receiver_id}&message=${encodeURIComponent(message)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadMessages(receiver_id);  // Reload the chat window after sending the message
            document.getElementById('messageInput').value = '';  // Clear the input field
        } else {
            alert('Failed to send message');
        }
    })
    .catch(error => {
        console.error('Error sending message:', error);
    });
});

</script>
<?php include "include/webfooter.php"; ?>
