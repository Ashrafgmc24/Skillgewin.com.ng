<?php
include 'include/db_connection.php'; // Ensure you have the correct DB connection

if (isset($_POST['query'])) {
    $search = "%{$_POST['query']}%"; 

    $stmt = $conn->prepare("SELECT * FROM tutor WHERE names LIKE ? OR country LIKE ? OR locations LIKE ? OR skills LIKE ? OR academic LIKE ?");
    $stmt->bind_param("sssss", $search, $search, $search, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // $full_stars = floor($row['rating']);
            // $empty_stars = 5 - $full_stars;

            echo '<div class="col-md-4 mb-4" data-aos="zoom-out" data-aos-duration="1000" data-aos-delay="500">
                    <div class="card">
                        <img src="uploads/'.htmlspecialchars($row['profile_img']).'" alt="Tutor Image" class="card-img-top">
                        <i class="fas fa-heart favorite-icon"></i>
                        <div class="card-body">
                            <h5 class="card-title">'.htmlspecialchars($row['names']).'</h5>
                            <p class="card-text">'.htmlspecialchars($row['locations']).'</p>
                            <p class="card-text">'.htmlspecialchars($row['webcam_face']).'</p>
                            <div class="star-rating mb-2">';
            // for ($i = 0; $i < $full_stars; $i++) {
            //     echo '<i class="fas fa-star"></i>';
            // }
            // for ($i = 0; $i < $empty_stars; $i++) {
            //     echo '<i class="far fa-star"></i>';
            // }
            echo '</div><p class="card-text">'.htmlspecialchars($row['experience']).'</p>
                        <p class="price">₦'.number_format($row['hourly_rate'], 2).'<span class="first-lesson"> - 1st lesson free</span></p>
                    </div></div></div>';
        }
    } else {
        echo '<p class="text-center">No tutors found for the search query.</p>';
        //echo "<script> window.location.href = '$page.php'; </script>";
        header("Location: " . $_SERVER['PHP_SELF']);
            exit;
        
    }
    $stmt->close();
}
?>
