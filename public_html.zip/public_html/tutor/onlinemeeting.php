<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Check if the user is logged in
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit();
}

$title = "Tutor - Online Meeting";
include __DIR__ . "/includes/app_header.php";
include __DIR__ . "/includes/app_nav.php";
include 'includes/db_connection.php'; // Your database connection

// Initialize variables
$tutor_id = $_SESSION['tutor_id'];
$meetingOption = '';
$meetUrl = '';

// Handle form submission to save meeting details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $meetingOption = $_POST['meetingOption'];
    $meetUrl = $_POST['meetUrl'];

    // Prepare and execute SQL query to insert the meeting details into the database
    $stmt = $conn->prepare("INSERT INTO online_meetings (tutor_id, meeting_option, google_meet_url) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $tutor_id, $meetingOption, $meetUrl);
    $stmt->execute();
    $stmt->close();

    echo "<div class='alert alert-success'>Meeting details saved successfully.</div>";
}

// Fetch meeting records for the current tutor
$stmt = $conn->prepare("SELECT * FROM online_meetings WHERE tutor_id = ?");
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

    <!-- Header -->
    <header class="w3-container" style="padding-top:22px">
        <h5><b><i class="fa fa-dashboard"></i> Online Meeting</b></h5>
    </header>

    <div class="w3-row-padding w3-margin-bottom">
        <div class="container mt-5">
            <div class="row">
                <div>
                    <h3>Online Meeting</h3>

                    <!-- Online Meeting Form -->
                    <form class="form" method="POST" action="">
                        <div class="mb-3">
                            <label for="meetingOption" class="form-label">Default virtual meeting option</label>
                            <select class="form-select" id="meetingOption" name="meetingOption" required>
                                <option value="zoom">Zoom</option>
                                <option value="google_meet">Google Meet</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="meetUrl" class="form-label">Google meet invitation URL</label>
                            <textarea class="form-control" id="meetUrl" name="meetUrl" rows="2"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
            
            <!-- Fetch and display saved meeting records -->
            <div class="row mt-5">
                <h4>Saved Meetings</h4>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Meeting Option</th>
                            <th>Google Meet URL</th>
                            <th>Date Added</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['meeting_option']); ?></td>
                                <td><?php echo htmlspecialchars($row['google_meet_url']); ?></td>
                                <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<?php
include "includes/app_footer.php";
$stmt->close();
$conn->close();
?>
