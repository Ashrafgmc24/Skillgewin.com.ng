<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Assuming the tutor_id is stored in the session

if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
  header('Location: ../loginTutor.php');
    exit();
}
$title = "Tutor - My Dashboard";

include __DIR__ . "/includes/db_connection.php";


include __DIR__ ."/includes/app_header.php";
@include __DIR__ ."/includes/app_nav.php";

//include __DIR__ . "/includes/app_nav.php";
// Fetch users who contacted the tutor
$tutor_id = $_SESSION['tutor_id'];
$query = $conn->prepare("SELECT contact_tutor.user_id, user.names, user.email, contact_tutor.contact_time 
FROM contact_tutor 
JOIN user ON contact_tutor.user_id = user.id 
WHERE contact_tutor.tutor_id = ?
");
$query->bind_param("i", $tutor_id);
$query->execute();
$result = $query->get_result();
?>
<!-- !PAGE CONTENT! -->
<main class="w3-main" style="margin-left:300px;margin-top:43px;">

<div class="container mt-5">
    <h3>Users Who Contacted You</h3>
    <table class="table table-responsive table-bordered table-striped">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Email</th>
                <th>Contact Time</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['names']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['contact_time']; ?></td>
                    <td>
                        <form method="POST" action="handle_contact_actions.php" style="display:inline;">
                            <input type="hidden" name="user_id" value="<?php echo $row['email']; ?>">
                            <button type="submit" name="action" value="accept" class="btn btn-success">Accept</button>
                        </form>
                        <form method="POST" action="../handle_contact_actions.php" style="display:inline;">
                            <input type="hidden" name="user_id" value="<?php echo $row['email']; ?>">
                            <button type="submit" name="action" value="decline" class="btn btn-warning">Decline</button>
                        </form>
                        <form method="POST" action="handle_contact_actions.php" style="display:inline;">
                            <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                            <!--<button type="submit" name="action" value="delete" class="btn btn-danger">Delete</button>-->
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</main>
<?php
require "includes/app_footer.php";
?>
