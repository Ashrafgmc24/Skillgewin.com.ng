<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit(); // Ensure no further code is executed
}
$title = "Tutor -Dashboard";


include __DIR__ ."/includes/app_header.php";
@include __DIR__ ."/includes/app_nav.php";
// require "../app_settings.php";
// require  "../app_header.php";
// require  "../app_nav.php";
?>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
  </header>

  <div class="w3-row-padding w3-margin-bottom">
   <!-- Main Content -->
<div class="container mt-4">
    <div class="row">
        <!-- Card 1 -->
        <div class="col-md-3 mb-3">
            <div class="card p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4>00</h4>
                        <p>Sessions</p>
                    </div>
                    <div class="icon-circle bg-blue">
                        <i class="fas fa-tv"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- Card 2 -->
        <div class="col-md-3 mb-3">
            <div class="card p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4>00</h4>
                        <p>Bookings</p>
                    </div>
                    <div class="icon-circle bg-purple">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- Card 3 -->
        <div class="col-md-3 mb-3">
            <div class="card p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4>00+</h4>
                        <p>Total Minutes</p>
                    </div>
                    <div class="icon-circle bg-green">
                        <i class="fas fa-clock"></i>
                    </div>
                </div>
            </div>
        </div>
        <!-- Card 4 -->
        <div class="col-md-3 mb-3">
            <div class="card p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4>0</h4>
                        <p>Users</p>
                    </div>
                    <div class="icon-circle bg-orange">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // JavaScript for notification dropdown functionality
    document.getElementById('notificationDropdown').addEventListener('click', function() {
        // Logic to display notifications can be added here
        alert('Notification clicked!');
    });
</script>
  </div>
<?php
require "includes/app_footer.php";
?>