<!DOCTYPE html>
<html>
<head>
<title><?php echo $title; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles/w3.css">
<link rel="stylesheet" href="styles/all.css">
<link rel="stylesheet" href="styles/datatables.css">
<script src="js/jquery-3.7.1.min.js"></script>
<script src="js/datatables.js"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Include Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<!-- Include Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }
        html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .icon-circle {
            width: 50px;
            height: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            color: white;
        }
        .bg-blue { background-color: #5bc0de; }
        .bg-purple { background-color: #6f42c1; }
        .bg-green { background-color: #28a745; }
        .bg-orange { background-color: #fd7e14; }
        .nav-item.dropdown {
            position: relative;
        }
        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            left: auto;
            will-change: transform;
        }
        .preview-img {
            max-width: 100px;
            height: auto;
            margin-bottom: 10px;
        }
          .tab-content {
            margin-left: 220px;
        }
        .nav-tabs {
            width: 200px;
            position: fixed;
        }
        #contactedUsersSidenav{
            display: block;
        }
        
           .step {
            display: none;
        }
        .step.active {
            display: block;
        }
        .form-description {
            font-size: 0.9rem;
            color: #555;
        }
        .error {
            color: red;
            font-size: 0.85rem;
        }
        @media (max-width: 768px) {
            #contactedUsersSidenav{
            display: none;
        }
            .tab-content {
                margin-left: 0;
            }
            .nav-tabs {
                width: 100%;
                position: relative;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body class="w3-light-grey">

<!-- Top container -->
<div class="w3-bar w3-top w3-white w3-large" style="z-index:4">
  <button class="w3-bar-item w3-button w3-hide-large w3-hover-none w3-hover-text-light-grey" onclick="w3_open();"><i class="fa fa-bars"></i> &nbsp;Menu</button>
  <span class="w3-bar-item w3-right"><img src="../img/logo.png" style="height: 30px"></span>
</div>
