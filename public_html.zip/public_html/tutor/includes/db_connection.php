<?php
// Database connection
$servername = "localhost";
$username = "skillgew_skilluser";
$password = "p!j$?x@655Vc=#U";
$database = "skillgew_skill";

$conn = mysqli_connect ($servername, $username, $password, $database); 
?>   