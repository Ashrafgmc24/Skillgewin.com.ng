<?php


// Fetch profile image from 'tutor' table
$tutor_id = $_SESSION['tutor_id']; // Replace with dynamic tutor ID based on session or other logic
$result = $conn->query("SELECT names, profile_img FROM tutor WHERE id = $tutor_id");
$tutor = $result->fetch_assoc();
$profile_img = $tutor['profile_img'];
$tutorname = $tutor['names'];
?>
<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="#">
    <img src="../img/logo.png" alt="Logo" style="height: 30px;">
  </a>
  <div class="search-bar ml-3">
    <input type="text" class="form-control" placeholder="What do you want to learn?">
  </div>
  <button class="btn btn-danger ml-2 myb-s">
    <i class="fas fa-search"></i>
  </button>
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item"><a class="nav-link active" href="dashboard_new.php">Dashboard</a></li>
      <li class="nav-item"><a class="nav-link" href="../chats.html">My Messages</a></li>
      <li class="nav-item"><a class="nav-link" href="ad_page.php">My Ads</a></li>
      <li class="nav-item"><a class="nav-link" href="#">Evaluations</a></li>
      <li class="nav-item"><a class="nav-link" href="#">My Account</a></li>
      <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
    </ul>
    <div class="ml-3 d-flex align-items-center">
      <a href="#" class="mr-3"><i class="far fa-question-circle"></i></a>
      <a href="#" class="mr-3"><i class="far fa-heart"></i></a>
      <img src="../uploads/<?php echo htmlspecialchars($profile_img); ?>" alt="Profile" class="profile-img">
    </div>
  </div>
</nav>