 
<?php
        session_start();

    // Check if the user is logged in
    if (!isset($_SESSION['tutor_id'])) {
      // If the user is not logged in, redirect them to the login page
      header('Location: ../loginTutor.php');
      exit(); // Ensure no further code is executed
    } 

    // // Database connection
    // $servername = "localhost";
    // $username = "skillgew_skilluser";
    // $password = "p!j$?x@655Vc=#U";
    // $database = "skillgew_skill";
    

    // // Create connection
    // $conn = mysqli_connect($servername, $username, $password, $database);

    // // Check connection
    // if (!$conn) {
    //     die("Connection failed: " . mysqli_connect_error());
    // }

    // // Fetch the tutor's profile information based on session id
    // $tutor_id = $_SESSION['tutor_id'];
    // $query = "SELECT names, email, phone, title, profile_img FROM tutor WHERE id = ?";
    // $stmt = $conn->prepare($query);
    // $stmt->bind_param("s", $tutor_id);
    // $stmt->execute();
    // $stmt->bind_result($name, $email, $phone, $title, $profile);
    // $stmt->fetch();
    // $stmt->close();
    // $conn->close();
    ?>
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar">
  <div class="w3-container">
    <h5>Dashboard</h5>
   
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>&nbsp; Close Menu</a>
    
    <a href="dashboard.php" class="w3-bar-item w3-button w3-padding w3-green"><i class="fa fa-home"></i>&nbsp; Dashboard</a>
    
    <!--<a href="my_ads.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-bullseye fa-fw"></i>&nbsp; Create Ads</a>-->
    <a href="ad_page.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-bullseye fa-fw"></i>&nbsp; My Ads</a>
    <a href="profile_tutor.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-file"></i> Profile</a>
    <!--<a href="setAccpayout.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-credit-card"></i>&nbsp; Set Payout</a>-->
    <!--<a href="payout.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-credit-card"></i>&nbsp; Payout</a>-->
    <!--<a href="session.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-book"></i>&nbsp; Session</a> -->
    <!--<a href="booking.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-book"></i>&nbsp; Bookings</a>-->
    <!-- <a href="contact_user.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-users"></i>&nbsp; Contacted Users</a>-->
    <a href="onlinemeeting.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-bullseye fa-fw"></i>&nbsp; Online Meeting</a>
   
    <!--<a href="mentorship.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-diamond fa-fw"></i>&nbsp; Mentorship</a>-->
    <a href="messages.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-message"></i>&nbsp; Message</a>
    <a href="marketuplaod.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-shopping-cart"></i>&nbsp; Market Place Upload</a>
   
    <a href="logout.php" class="w3-bar-item w3-button w3-red"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</nav>
<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>


<div id="id03" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id03').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h2 class="w3-center">My Profile</h2>
    </header>

    <div class="w3-container">
    

    <div class="w3-container">
    <div class="w3-center w3-padding">
  <?php if (!empty($profile)) { ?>
    <img src="<?php echo '../uploads/' . htmlspecialchars($profile); ?>" alt="Profile Image" style="width:150px; height:150px; border-radius:50%;">
  <?php } else { ?>
    <i class="fa fa-user fa-9x"></i>
  <?php } ?>
</div>

      <h4 class="w3-green w3-padding">PERSONAL INFORMATION</h4>
      <p><strong>Name:</strong></p> 
      <h3 class="w3-border w3-padding" style="overflow: auto;"><?php echo htmlspecialchars($name); ?></h3>
      <p><strong>Email:</strong></p> 
      <h3 class="w3-border w3-padding" style="overflow: auto;"><?php echo htmlspecialchars($email); ?></h3>
       <p><strong>Phone No.:</strong></p> 
      <h3 class="w3-border w3-padding" style="overflow: auto;"><?php echo htmlspecialchars($phone); ?></h3>
      <p><strong>Title:</strong> </p>
      <h3 class="w3-border w3-padding" style="overflow: auto;"><?php echo htmlspecialchars($title); ?></h3>
      <div class="w3-card w3-padding w3-margin">
        <a href="logout.php" class="w3-button w3-red">Logout</a>
      </div>
    </div>

    </div>

    <footer class="w3-container w3-green">
      <p>SKILLGEWIN</p>
    </footer>

  </div>
</div> 

<!-- Send Message Modal -->
<div id="id04" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id04').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h2 class="w3-center">Send Message</h2>
    </header>

    <div class="w3-container">
      <!-- Add form to send a message if necessary -->
    </div>

    <footer class="w3-container w3-green">
      <p>SKILLGEWIN</p>
    </footer>

  </div>
</div>
