<?php
session_start();
$title = "My Profile";
include "includes/app_header.php";
include "includes/db_connection.php";

// Check if the tutor is logged in
if (!isset($_SESSION['tutor_id'])) {
    header("Location: ../loginTutor.php");
    exit();
}

// Fetch tutor's information from the database
$tutor_id = $_SESSION['tutor_id'];
$sql = "SELECT names, email, phone, country, locations, experience, about_you, profile_img FROM tutor WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$stmt->bind_result($names, $email, $phone, $country, $locations, $experience, $about_you, $profile_img);
$stmt->fetch();
$stmt->close();
@include __DIR__ ."/includes/app_nav.php";
?>
    <div class="w3-main" style="margin-left:300px;margin-top:43px; w3-white">

<div class="container mt-5 w3-white">
    <h2 class="text-center">My Profile</h2>
    <div class="row justify-content-center">
        <div class="col-md-6">
            
              
                                <img src="../uploads/<?php echo htmlspecialchars($profile_img); ?>" class="card-img-top" alt="Profile Image">
    
             
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($names); ?></h5>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($phone); ?></p>
                    <p><strong>Country:</strong> <?php echo htmlspecialchars($country); ?></p>
                    <p><strong>Location:</strong> <?php echo htmlspecialchars($locations); ?></p>
                    <p><strong>Experience:</strong> <?php echo htmlspecialchars($experience); ?> years</p>
                    <p><strong>About Me:</strong> <?php echo nl2br(htmlspecialchars($about_you)); ?></p>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#editProfileModal">Edit Profile</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Editing Profile -->
<div class="modal fade" id="editProfileModal" tabindex="-1" role="dialog" aria-labelledby="editProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="editProfileForm" action="update_profile_tutor.php" method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="names">Full Name</label>
                        <input type="text" name="names" id="names" class="form-control" value="<?php echo htmlspecialchars($names); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($phone); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="country">Country</label>
                        <input type="text" name="country" id="country" class="form-control" value="<?php echo htmlspecialchars($country); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="locations">Location</label>
                        <input type="text" name="locations" id="locations" class="form-control" value="<?php echo htmlspecialchars($locations); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="experience">Experience (years)</label>
                        <input type="text" name="experience" id="experience" class="form-control" value="<?php echo htmlspecialchars($experience); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="about_you">About You</label>
                        <textarea name="about_you" id="about_you" class="form-control" rows="4" required><?php echo htmlspecialchars($about_you); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="profile_img">Profile Image</label>
                        <input type="file" name="profile_img" id="profile_img" class="form-control-file">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div></div>

<!-- Include jQuery and Bootstrap -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<?php include "includes/app_footer.php"; ?>
