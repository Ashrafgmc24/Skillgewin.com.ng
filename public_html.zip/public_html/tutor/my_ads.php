<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Ads</title>
  <link rel="stylesheet" href="styles/w3.css">
<link rel="stylesheet" href="styles/all.css">
<link rel="stylesheet" href="styles/datatables.css">
<script src="js/jquery-3.7.1.min.js"></script>
<script src="js/datatables.js"></script>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <style>
    .navbar {
      background-color: #fff;
    }
    .navbar .nav-link {
      color: #333;
    }
    .navbar .nav-link.active {
      font-weight: bold;
      color: #000;
    }
    .navbar .search-bar {
      max-width: 300px;
    }
    .navbar .profile-img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
    }
     .create-ad-btn {
      background-color: #ff5a5f;
      color: #fff;
      border-radius: 25px;
    }
    .ad-list-item {
      background-color: #f5f5f5;
      border-radius: 15px;
      padding: 10px;
      display: flex;
      align-items: center;
      
      margin-top: 10px;
    }
    .ad-list-item img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 10px;
    }
    .premium-section {
      background-color: #333;
      color: #fff;
      padding: 20px;
      border-radius: 15px;
      margin-top: 20px;
      text-align: center;
    }
    .go-premium-btn {
      background-color: #007bff;
      color: #fff;
      border-radius: 25px;
    }
    .profile-section {
      background-color: #f5f5f5;
      padding: 20px;
      border-radius: 15px;
      text-align: center;
      margin-top: 20px;
    }
    .profile-section img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
    }
     body {
            background-color: #f8f9fa;
        }
        html,body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .icon-circle {
            width: 50px;
            height: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            color: white;
        }
        .bg-blue { background-color: #5bc0de; }
        .bg-purple { background-color: #6f42c1; }
        .bg-green { background-color: #28a745; }
        .bg-orange { background-color: #fd7e14; }
        .nav-item.dropdown {
            position: relative;
        }
        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            left: auto;
            will-change: transform;
        }
        .preview-img {
            max-width: 100px;
            height: auto;
            margin-bottom: 10px;
        }
          .tab-content {
            margin-left: 220px;
        }
        .nav-tabs {
            width: 200px;
            position: fixed;
        }
        #contactedUsersSidenav{
            display: block;
        }
        
           .step {
            display: none;
        }
        .step.active {
            display: block;
        }
        .form-description {
            font-size: 0.9rem;
            color: #555;
        }
        .error {
            color: red;
            font-size: 0.85rem;
        }
        /*.w3-modal{*/
        /*    display: block;*/
        /*}*/
        @media (max-width: 768px) {
        /*     .w3-modal{*/
        /*    display: none;*/
        /*}*/
            #contactedUsersSidenav{
            display: none;
        }
            .tab-content {
                margin-left: 0;
            }
            .nav-tabs {
                width: 100%;
                position: relative;
                margin-bottom: 20px;
            }
        }
    @media (max-width: 768px) {
      .navbar .nav-item {
        display: block;
        text-align: center;
      }
      .search-bar, .myb-s{
          display: none;
      }
    }
  </style>
</head>
<body>

<?php
// Database connection

error_reporting(E_ALL);
ini_set('display_errors', 1);


 // Check if the user is logged in
    if (!isset($_SESSION['tutor_id'])) {
      // If the user is not logged in, redirect them to the login page
      echo "<script> window.location.href='../loginTutor.php' </script>";
      //header('Location: ../loginTutor.php');
      exit(); // Ensure no further code is executed
    } 
    
include __DIR__ . "/includes/db_connection.php";

// Fetch profile image from 'tutor' table
$tutor_id = $_SESSION['tutor_id']; // Replace with dynamic tutor ID based on session or other logic
$result = $conn->query("SELECT profile_img FROM tutor WHERE id = $tutor_id");
$tutor = $result->fetch_assoc();
$profile_img = $tutor['profile_img'];
?>

<nav class="navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="#">
    <img src="../img/logo.png" alt="Logo" style="height: 30px;">
  </a>
  <div class="search-bar ml-3">
    <input type="text" class="form-control" placeholder="What do you want to learn?">
  </div>
  <button class="btn btn-danger ml-2 myb-s">
    <i class="fas fa-search"></i>
  </button>
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
    <span class="navbar-toggler-icon"></span>
  </button>
  
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item"><a class="nav-link active" href="#">Dashboard</a></li>
      <li class="nav-item"><a class="nav-link" href="#">My Messages</a></li>
      <li class="nav-item"><a class="nav-link" href="ad_page.php">My Ads</a></li>
      <li class="nav-item"><a class="nav-link" href="#">Evaluations</a></li>
      <li class="nav-item"><a class="nav-link" href="#">My Account</a></li>
      <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
    </ul>
    <div class="ml-3 d-flex align-items-center">
      <a href="#" class="mr-3"><i class="far fa-question-circle"></i></a>
      <a href="#" class="mr-3"><i class="far fa-heart"></i></a>
      <img src="../uploads/<?php echo htmlspecialchars($profile_img); ?>" alt="Profile" class="profile-img">
    </div>
  </div>
</nav>
<?php
// Database connection

include __DIR__ ."/includes/db_connection.php";
if (isset($_POST['savebtn'])){
    // Retrieve form data
$tutor_id = $_SESSION['tutor_id']; // Replace with dynamic tutor ID from session or other method
$ad_title = $_POST['ad_title'];
$subject = $_POST['subjects'];

$lessons_taught = $_POST['lessons_taught'];
$location = $_POST['location'];
$levels = $_POST['level'];
$languages = $_POST['languages'];
$about_lesson = $_POST['about_lesson'];
$about_tutor = $_POST['about_tutor'];
$rate_details = $_POST['rate_details'];
$video_url = $_POST['video_url'];
$recommendations = $_POST['recommendations'];

// Insert data into the database
$sql = "INSERT INTO ads (tutor_id, ad_title, subjects, lessons_taught, location, levels, languages, about_lesson, about_tutor, rate_details, video_url, recommendations)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isssssssssss", $tutor_id, $ad_title, $subject, $lessons_taught, $location, $levels, $languages, $about_lesson, $about_tutor, $rate_details, $video_url, $recommendations);

if ($stmt->execute()) {
    $update_online_status = $conn->prepare("UPDATE ads SET title = 'online' WHERE tutor_id = ?");
$update_online_status->bind_param('i', $_SESSION['tutor_id']);
$update_online_status->execute();

    //echo "Ad saved successfully!";
   // echo "<script> window.location.href='my_ads.php' </script>";
        echo "<script> window.location.href='ad_page.php' </script>";

} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
}

?>



<body>
    <!-- !PAGE CONTENT! -->
    <div class="w3-main" style="margin-left:300px;margin-top:43px;">
<main class="container mt-5 w3-white">
    <h2 class="text-center">Create Your Ad</h2>
    <form id="adForm" method="post" action="">
        <div class="row">
            <div class="col-md-8">
                <!-- Step 1: Ad Title -->
                <div class="step active">
                    <div class="form-group">
                        <label for="ad_title">Title of your ad (12 words minimum)</label>
                        <textarea class="form-control" id="ad_title" name="ad_title" rows="3" required></textarea>
                        <div id="titleError" class="error"></div>
                        <!-- Trigger/Open the Modal -->
                        <div class="w3-center"> <button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
               


                    </div>
                   
                   <!---->
                   <div id="id01" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id01').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
        <p>
Your title is the key to your ad! Take care of it! It must be unique, eye-catching and contain at least 12 words:</p>
<ul>
    <li>The subject you teach</li>
    <li>The level you teach</li>
    <li>Location of the lessons</li>
    <li>Qualifications, experience etc.</li>
</ul>
<p><strong>Title of your ad:</strong> Provide a brief title describing your lessons. Minimum of 12 words.</p>
    </div>

    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id01').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                   
                   <!---->
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                </div>
                
                 <!-- Step 2: Lessons Taught -->
                <div class="step">
                    <div class="form-group">
                        <label for="subjects">Subject</label>
                        <textarea class="form-control" id="subjects" name="subjects" rows="3" required></textarea>
                    </div>
                    <div class="w3-center"> <button onclick="document.getElementById('id02').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                    
                     <!---->
                   
                   <div id="id02" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id02').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
        <p>
Explain your approach to tutoring and how you teach your classes:</p>
<ul>
    <li>Your techniques and teaching methodology</li>
    <li>Typical length of a lesson</li>
    <li>Your qualifications/experience as a tutor</li>
    <li>Who are your lesson for (level, age, etc.)</li>
</ul>
 <p><strong>Lessons taught:</strong> Specify the subjects or skills you offer.</p>
<p><strong>DON'T FORGET</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id02').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                </div>

                
                <!-- Step : Lessons Taught -->
                <div class="step">
                    <div class="form-group">
                        <label for="lessons_taught">Lessons taught</label>
                        <textarea class="form-control" id="lessons_taught" name="lessons_taught" rows="3" required></textarea>
                    </div>
                      <div class="w3-center"> <button onclick="document.getElementById('id033').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                    
                    </div>
                   
                      <!---->
                   
                   <div id="id033" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id033').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
     Lessons taught: Specify the subjects or skills you offer.
 <p><strong>Lessons taught:</strong> Specify the subjects or skills you offer.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id033').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    
                    <!--end-->
                </div>

                <!-- Step 3: Location -->
                <div class="step">
                    <div class="form-group">
                        <label for="location">Location</label>
                        <textarea class="form-control" id="location" name="location" rows="3" required></textarea>
                    </div>
                    <div class="w3-center"> <button onclick="document.getElementById('id04').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                    
                      <!---->
                   
                   <div id="id04" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id04').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
       <p>Your address will never appear on the site. It will only be given to the students you agree to teach.
</p> 
<<p>You can offer your lessons at home at the address indicated</p>

<p>"You can travel" indicates that classes can be held at the student's home or at another location that you determine together.</p>

<p>You can also teach your classes around the world via webcam!</p>


     
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id04').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    <!---->
                </div>

                <!-- Step 4: Location -->
                <div class="step">
                    <div class="form-group">
                        <label for="location">Level</label>
                        <textarea class="form-control" id="level" name="level" rows="3" required></textarea>
                    </div>
                     <div class="w3-center"> <button onclick="document.getElementById('id05').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                      <!---->
                   
                   <div id="id05" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id05').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
     Lessons taught: Specify the subjects or skills you offer.
 <p><strong>Lessons taught:</strong> Specify the subjects or skills you offer.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id05').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    <!---->
                </div>
                
                  <!-- Step 5: Location -->
                <div class="step">
                    <div class="form-group">
                        <label for="Languages">Languages</label>
                        <textarea class="form-control" id="languages" name="languages" rows="3" required></textarea>
                    </div>
                     <div class="w3-center"> <button onclick="document.getElementById('id06').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                      <!---->
                   
                   <div id="id06" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id06').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
    <p><strong>Languages:</strong> Mention languages you can teach or teach in.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id06').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    <!---->
                </div>
                  <!-- Step 6: Location -->
                <div class="step">
                    <div class="form-group">
                        <label for="About Lesson">About Lesson</label>
                        <textarea class="form-control" id="about_lesson" name="about_lesson" rows="3" required></textarea>
                    </div>
                     <div class="w3-center"> <button onclick="document.getElementById('id07').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                    
                      <!---->
                   
                   <div id="id07" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id07').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
     <p><strong>About the Lesson:</strong> Describe the lesson format, topics, etc.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id07').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    <!---->
                </div>
                <!-- Step 7: Location -->
                <div class="step">
                    <div class="form-group">
                        <label for="about_tutor">About You</label>
                        <textarea class="form-control" id="about_tutor" name="about_tutor" rows="3" required></textarea>
                    </div>
                     <div class="w3-center"> <button onclick="document.getElementById('id08').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                      <!---->
                   
                   <div id="id08" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id08').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
      <p> Inspire confidence, establish your legitimacy and reassure students of your professionalism.</p> 
<p>This is one of the first things that the students will read about you, remember to take care of your spelling and grammar.</p>

     <p><strong>About the Tutor:</strong> Briefly introduce yourself and your qualifications.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id08').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    <!---->
                </div>
                
                <!-- Step 8: Location -->
                <div class="step">
                    <div class="form-group">
                        <label for="rate_details">Hourly Rate</label>
                        <textarea class="form-control" id="rate_details" name="rate_details" rows="3" required></textarea>
                    </div>
                     <div class="w3-center"> <button onclick="document.getElementById('id09').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                      <!---->
                   
                   <div id="id09" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id09').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
       <p>You are free to choose your hourly rate and change it at any time.</p> 
<P>If you are just starting out, and don't have any reviews or recommendations be aware that a very high price might put people off. You can always use a lower rate to attract students initially and adjust it as you gain a reputation.</P>

     <p><strong>Rate Details:</strong> Provide information on your rates.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id09').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    <!---->
                </div>
                
                    <!-- Step 9: Location -->
                <div class="step">
                    <div class="form-group">
                        <label for="video_url">video Url</label>
                        <textarea class="form-control" id="video_url" name="video_url" rows="3" required></textarea>
                    </div>
                     <div class="w3-center"> <button onclick="document.getElementById('id010').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="button" class="btn btn-primary" onclick="nextStep()">Next</button>
                      <!---->
                   
                   <div id="id10" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id10').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
   <p><strong>Video URL:</strong> (Optional) Link to a video demonstrating your lessons.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id10').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
                    <!---->
                </div>
                <!-- Step 4 to Step 10: Remaining fields (similar structure) -->
                <!-- Add similar sections here for levels, languages, etc., using the provided structure -->

                <!-- Step 10: Recommendations -->
                <div class="step">
                    <div class="form-group">
                        <label for="recommendations">Recommendations</label>
                        <textarea class="form-control" id="recommendations" name="recommendations" rows="3"></textarea>
                    </div>
                     <div class="w3-center"> <button onclick="document.getElementById('id11').style.display='block'" class="w3-button w3-text-red"><i class="fa fa-info-circle"></i></button></div>
                    <button type="button" class="btn btn-secondary" onclick="prevStep()">Previous</button>
                    <button type="submit" class="btn btn-success" name="savebtn">Save Ad</button>
                    
                      <!---->
                   
                   <div id="id11" class="w3-modal">
  <div class="w3-modal-content">

    <header class="w3-container w3-green">
      <span onclick="document.getElementById('id11').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
      <h1>Good to know</h1>
    </header>

    <div class="w3-container">
     <p><strong>Recommendations:</strong> Add any notable recommendations or testimonials.</p>
<p><strong>Reminder</strong> Contact details and URLs must not appear in your ad.</p>
    </div>
    <footer class="w3-container w3-green">
       <span onclick="document.getElementById('id11').style.display='none'"
      class="w3-button">I understand</span>
    </footer>

  </div>
</div>
<!---->
                    
                </div>
            </div>

        </div>
    </form>
</main>
</div>


<script>
    let currentStep = 0;

    function showStep(step) {
        document.querySelectorAll('.step').forEach((el, index) => {
            el.classList.toggle('active', index === step);
        });
    }

    function nextStep() {
        if (currentStep === 0) {
            let adTitle = document.getElementById('ad_title').value.trim();
            let wordCount = adTitle.split(/\s+/).length;
            if (wordCount < 12) {
                document.getElementById('titleError').textContent = "Title must contain at least 12 words.";
                return;
            } else {
                document.getElementById('titleError').textContent = "";
            }
        }
        currentStep++;
        showStep(currentStep);
    }

    function prevStep() {
        currentStep--;
        showStep(currentStep);
    }

    document.getElementById('adForm').addEventListener('submit', function(event) {
        let adTitle = document.getElementById('ad_title').value.trim();
        let wordCount = adTitle.split(/\s+/).length;
        if (wordCount < 12) {
            event.preventDefault();
            document.getElementById('titleError').textContent = "Title must contain at least 12 words.";
        }
    });
</script>
<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // JavaScript for notification dropdown functionality
    document.getElementById('notificationDropdown').addEventListener('click', function() {
        // Logic to display notifications can be added here
        alert('Notification clicked!');
    });
</script>
  </div>
<?php
require "includes/app_footer.php";
?>