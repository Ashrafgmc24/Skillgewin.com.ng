<?php
session_start(); // Start the session
 
error_reporting(E_ALL);
ini_set('display_errors', 1);
include __DIR__ . "/includes/db_connection.php";

// Set status to 'offline' when tutor logs out
if (isset($_SESSION['tutor_id'])) {
    $update_offline_status = $conn->prepare("UPDATE ads SET title = 'offline' WHERE tutor_id = ?");
    $update_offline_status->bind_param('i', $_SESSION['tutor_id']);
    $update_offline_status->execute();
}



// Destroy all session data
session_unset(); // Remove all session variables
session_destroy(); // Destroy the session

// Redirect to the login page (index.php)
// header('Location: ../loginTutor.php');
      echo "<script> window.location.href='../loginTutor.php' </script>";

exit(); // Ensure no further code is executed
?>
