<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the user is logged in
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit(); // Ensure no further code is executed
}
$title = "Create Session";


include __DIR__ ."/includes/app_header.php";
@include __DIR__ ."/includes/app_nav.php";
// require "../app_settings.php";
// require  "../app_header.php";
// require  "../app_nav.php";

include __DIR__ ."/includes/app_nav.php";

// Assuming the tutor_id is stored in the session after login

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tutor_id = $_SESSION['tutor_id'];  // Ensure tutor is logged in

    $session_name = $_POST['session_name'];
    $duration = $_POST['duration'];
    $price = $_POST['price'];
    $details = $_POST['details'];
    $session_type = $_POST['session_type'];
    $session_topic = $_POST['session_topic'];
    $intro_url = $_POST['intro_url'];
    $status = $_POST['status'];
    $enable_group_booking = isset($_POST['enable_group_booking']) ? 1 : 0;
    $persons_per_slot = $_POST['persons_per_slot'];
    $schedule = ($_POST['schedule']); // JSON encoding for schedule times

    // Insert into database
    $sql = "INSERT INTO sessions (tutor_id, session_name, duration, price, details, session_type, session_topic, intro_url, status, enable_group_booking, persons_per_slot, schedule)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssssssssss', $tutor_id, $session_name, $duration, $price, $details, $session_type, $session_topic, $intro_url, $status, $enable_group_booking, $persons_per_slot, $schedule);
    if ($stmt->execute()) {
        echo "Session created successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">
<div class="container mt-5">
    <h2>Create New Session</h2>
    <form action="" method="POST">
        <div class="row">
            <div class="col-md-6">
                <!-- Session Name -->
                <div class="form-group">
                    <label for="session_name">Session Name</label>
                    <input type="text" name="session_name" id="session_name" class="form-control" required>
                </div>
                <!-- Duration -->
                <div class="form-group">
                    <label for="duration">Duration</label>
                    <input type="number" name="duration" id="duration" class="form-control" placeholder="Minutes" required>
                </div>
                <!-- Price -->
                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="number" step="0.01" name="price" id="price" class="form-control" required>
                    <small class="text-muted">Set price to 0 for free session</small>
                </div>
                <!-- Details -->
                <div class="form-group">
                    <label for="details">Details</label>
                    <textarea name="details" id="details" rows="4" class="form-control" required></textarea>
                </div>
                <!-- Session Type -->
                <div class="form-group">
                    <label for="session_type">Session Type</label>
                    <select name="session_type" id="session_type" class="form-control" required>
                        <option value="Private">Private</option>
                        <option value="Group">Group</option>
                    </select>
                </div>
                <!-- Session Topic -->
                <div class="form-group">
                    <label for="session_topic">Session Topic</label>
                    <select name="session_topic" id="session_topic" class="form-control" required>
                        <option value="Math">Math</option>
                        <option value="Science">Science</option>
                        <option value="English">English</option>
                    </select>
                </div>
                <!-- Intro Video URL -->
                <div class="form-group">
                    <label for="intro_url">Intro Video URL (embedded)</label>
                    <input type="url" name="intro_url" id="intro_url" class="form-control">
                </div>
                <!-- Status -->
                <div class="form-group">
                    <label>Status</label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="status" id="statusShow" value="Show" checked>
                        <label class="form-check-label" for="statusShow">Show</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="status" id="statusHide" value="Hide">
                        <label class="form-check-label" for="statusHide">Hide</label>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <!-- Group Booking -->
                <div class="form-group">
                    <label>Group Booking</label><br>
                    <input type="checkbox" name="enable_group_booking" id="enable_group_booking"> Enable Group Booking
                </div>
                <div class="form-group">
                    <label for="persons_per_slot">Allow number of persons per slot</label>
                    <input type="number" name="persons_per_slot" id="persons_per_slot" class="form-control" min="1">
                </div>
                <!-- Schedule -->
                <div class="form-group">
                    <label>Set Schedule</label>
                    <select name="timezone" id="timezone" class="form-control mb-2">
                        <option value="Antarctica/Davis">Antarctica/Davis</option>
                        <!-- Add more timezones here -->
                    </select>
                    <div>
                        <?php
                        $days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        foreach ($days as $day) {
                            echo '<div class="form-group">';
                            echo '<label>' . $day . '</label>';
                            echo '<input type="time" name="schedule[' . $day . '][start]" class="form-control">';
                            echo '<input type="time" name="schedule[' . $day . '][end]" class="form-control mt-1">';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
