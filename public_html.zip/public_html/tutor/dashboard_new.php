<?php session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);


 // Check if the user is logged in
    if (!isset($_SESSION['tutor_id'])) {
      // If the user is not logged in, redirect them to the login page
      echo "<script> window.location.href='../loginTutor.php' </script>";
      //header('Location: ../loginTutor.php');
      exit(); // Ensure no further code is executed
    } 
    
include __DIR__ . "/includes/db_connection.php";

// Fetch profile image from 'tutor' table

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutor Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
          .navbar {
      background-color: #fff;
    }
    .navbar .nav-link {
      color: #333;
    }
    .navbar .nav-link.active {
      font-weight: bold;
      color: #000;
    }
    .navbar .search-bar {
      max-width: 300px;
    }
    .navbar .profile-img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
    }
     .create-ad-btn {
      background-color: #ff5a5f;
      color: #fff;
      border-radius: 25px;
    }
    .ad-list-item {
      background-color: #f5f5f5;
      border-radius: 15px;
      padding: 10px;
      display: flex;
      align-items: center;
      
      margin-top: 10px;
    }
    .ad-list-item img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 10px;
    }
    .premium-section {
      background-color: #333;
      color: #fff;
      padding: 20px;
      border-radius: 15px;
      margin-top: 20px;
      text-align: center;
    }
    .go-premium-btn {
      background-color: #007bff;
      color: #fff;
      border-radius: 25px;
    }
    .profile-section {
      background-color: #f5f5f5;
      padding: 20px;
      border-radius: 15px;
      text-align: center;
      margin-top: 20px;
    }
    .profile-section img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
    }
       .progress-container {
        background: linear-gradient(135deg, #ff9a9e, #fad0c4);
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        color: white;
        text-align: center;
    }
    .progress-container .d-flex {
        position: relative;
        height: 40px;
    }
    .dd-flex{
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
    }
    .progress-step {
        flex: 1;
        position: relative;
        text-align: center;
        color: rgba(255, 255, 255, 0.7);
        font-weight: bold;
    }
    .progress-step.active {
        color: white;
    }
    .progress-step::before {
        content: '';
        width: 20px;
        height: 20px;
        background-color: white;
        border-radius: 20%;
        position: absolute;
        top: 0;
        left: 50%;
        transform: translate(-50%, -20%);
    }
    .progress-step::after {
        content: '';
        position: absolute;
        top: 4px;
        left: 50%;
        width: 100%;
        height: 2px;
        background-color: rgba(255, 255, 255, 0.7);
        z-index: -1;
    }
    .progress-step:first-child::after {
        left: 50%;
        width: 50%;
    }
    .progress-step:last-child::after {
        left: 0;
        width: 50%;
    }
    .progress-step.active + .progress-step::after {
        background-color: white;
    }
    .modal-content {
    background-color: #fefefe;
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}
/* General Styles */
.status-container {
    text-align: center;
    padding: 20px;
    background: linear-gradient(135deg, #ff7e5f, #feb47b);
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.status-indicator {
    background: #ff7e5f;
    color: #fff;
    padding: 10px 20px;
    border-radius: 20px;
    display: inline-block;
    margin-bottom: 15px;
}

.progress-bar {
    background: #f3f3f3;
    border-radius: 10px;
    height: 8px;
    margin: 10px auto;
    width: 80%;
    position: relative;
}

.progress {
    background: #ff7e5f;
    border-radius: 10px 0 0 10px;
    height: 100%;
    width: 25%; /* Set based on the user's status */
}

.upgrade-btn {
    background: none;
    border: none;
    color: #fff;
    font-weight: bold;
    cursor: pointer;
}

/* Styles for Small Screens */
@media (max-width: 768px) {
    .status-indicator span {
        display: block;
    }
}

/* Styles for Large Screens */
@media (min-width: 769px) {
    .status-container {
        display: flex;
        align-items: center;
        justify-content: space-around;
    }

    .status-indicator {
        flex: 1;
    }

    .progress-bar {
        flex: 3;
        margin-left: 20px;
        margin-right: 20px;
    }

    .upgrade-btn {
        flex: 1;
    }
}

    @media (max-width: 768px) {
        .hided{
            display: none;
        }
      .navbar .nav-item {
        display: block;
        text-align: center;
      }
      .search-bar, .myb-s{
          display: none;
      }
        .ad-title {
        display: inline-block;
        max-width: 150px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    }
    </style>
</head>
<body>
<?php 
include __DIR__ . "/includes/new_nav.php";
?>


<div class="container my-4">
    
    <div class="row">
        <div class="col-md-3 text-center">
            
            <!-- Profile Section -->
            <div class="card"> 
                <div class="card-body">
                    <?php
                    $tutor_id = $_SESSION['tutor_id']; // Replace with dynamic tutor ID based on

                    $result = $conn->query("SELECT names, profile_img FROM tutor WHERE id = $tutor_id");
                    $row = $result->fetch_assoc();
                    $use_tutor =  $row['profile_img'];
                    ?>
                    <img src="../uploads/<?php echo $row['profile_img']; ?>" class="rounded-circle" width="100" height="100" alt="Profile Image">
                    <h5 class="mt-3"><?php echo $row['names']; ?></h5>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#updateProfileModal">
                        <i class="fas fa-camera"></i> Update Profile Image
                    </button>
                </div>
            </div>
        </div>
       

        
        <div class="col-md-9">
            <!-- Dashboard Navigation -->
          <div class="status-container">
    <div class="status-indicator">
        <span>New</span>
    </div>
    <div class="progress-bar">
        <div class="progress"></div>
    </div>
    <button class="upgrade-btn">Upgrade my status</button>
</div>


            <!-- Content Sections -->
            <div class="card mt-3">
                <div class="card-body">
                    <h5 class="card-title">Lesson Requests</h5>
                    <p>No requests</p>
                </div>
            </div>

            <div class="card mt-3">
                    <!--open-->
                    <?php
// Assuming $tutor_id is already defined based on the logged-in tutor's ID
include __DIR__ . "/includes/db_connection.php";

// Fetch ads data
// Fetch ads data with a LEFT JOIN to include tutor data
$query = "SELECT ads.ad_title, ads.profile_img_ad AS ad_img, tutor.profile_img AS tutor_img 
          FROM ads 
          LEFT JOIN tutor ON ads.tutor_id = tutor.id 
          WHERE tutor.id = $tutor_id";
$result = $conn->query($query);
?>

<div class="container mt-4">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">My Ads</h5>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <div class="d-flex ad-list-item align-items-center">
                
            <?php 
                        // Determine which profile image to use based on the condition
                        $profile_img = !empty($row['ad_img']) ? $row['ad_img'] : $row['tutor_img'];
                    ?>
                    <img src="../uploads/<?php echo $profile_img; ?>" alt="Ad Image" class="rounded-circle" width="50" height="50">

                    <div class="ml-3">
                        <p class="mb-0 font-weight-bold"><?php //echo $row['ad_title']; ?></p>
                        <?php echo implode(' ', array_slice(explode(' ', $row['ad_title']), 0, 2)); ?>...
                    </div>
                    
<!--                    <div class="ml-3">-->
<!--    <p class="mb-0 font-weight-bold ad-title" onclick="openModal('<?php //echo htmlspecialchars($row['ad_title'], ENT_QUOTES); ?>')">-->
<!--        <?php //echo implode(' ', array_slice(explode(' ', $row['ad_title']), 0, 2)); ?>...-->
<!--    </p>-->
<!--</div>-->

<!-- Modal Structure -->
<!--<div id="adModal" style="display:none;">-->
<!--    <div class="modal-content">-->
<!--        <span class="close" onclick="closeModal()">&times;</span>-->
<!--        <p id="modal-text"></p>-->
<!--    </div>-->
<!--</div>-->

                    <!---->
                    <div class="ml-auto d-flex align-items-center">
                        <span class="badge badge-pill badge-success mr-2"></span>
                        <button class="btn btn-outline-secondary btn-sm mr-2 hided">
                            <i class="fas fa-eye hided"></i>
                        </button>
                        <button class="btn btn-outline-secondary btn-sm hided">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                    <div><i class="fas fa-eye"></i> <i class="fas fa-edit"></i></div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>
<br>
  <section class="card">
                <div class="card-body">
                <p>Become a Pro!</p>
                <p>More students!</p>
                <p>Increased visibility!</p>
                <p>More statistics!</p>
                <p> <button class="btn btn-primary">Find out more..</button></p>
                </div>
            </section>

                    <!--close-->
                </div>
            </div>
        </div>
        
    </div>


<script>
    function openModal(fullText) {
        document.getElementById('modal-text').innerText = fullText;
        document.getElementById('adModal').style.display = 'block';
    }

    function closeModal() {
        document.getElementById('adModal').style.display = 'none';
    }
</script>



<!-- Update Profile Image Modal -->
<div class="modal fade" id="updateProfileModal" tabindex="-1" role="dialog" aria-labelledby="updateProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document"> 
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateProfileModalLabel">Update Profile Image</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="file" name="profile_img" class="form-control" required>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="btn_update" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
 <?php
// Database connection
include __DIR__ . "/includes/db_connection.php";

if (isset($_POST['btn_update'])) {
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($_FILES["profile_img"]["name"]);
    
    if (move_uploaded_file($_FILES["profile_img"]["tmp_name"], $target_file)) {
        $sql = "UPDATE tutor SET profile_img = '$target_file' WHERE id = $tutor_id";
        if ($conn->query($sql) === TRUE) {
            echo "Profile image updated successfully.";
        } else {
            echo "Error updating profile image: " . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
    
    $conn->close();
          echo "<script> window.location.href='dashboard_new.php' </script>";

    header("Location: index.php"); // Redirect back to the dashboard
}
?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
