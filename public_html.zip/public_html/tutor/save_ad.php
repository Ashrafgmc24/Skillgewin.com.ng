<?php
// Database connection

include __DIR__ ."/includes/db_connection.php";

// Retrieve form data
$tutor_id = $_SESSION['tutor_id']; // Replace with dynamic tutor ID from session or other method
$ad_title = $_POST['ad_title'];
$lessons_taught = $_POST['lessons_taught'];
$location = $_POST['location'];
$levels = $_POST['levels'];
$languages = $_POST['languages'];
$about_lesson = $_POST['about_lesson'];
$about_tutor = $_POST['about_tutor'];
$rate_details = $_POST['rate_details'];
$video_url = $_POST['video_url'];
$recommendations = $_POST['recommendations'];

// Insert data into the database
$sql = "INSERT INTO ads (tutor_id, ad_title, lessons_taught, location, levels, languages, about_lesson, about_tutor, rate_details, video_url, recommendations)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("issssssssss", $tutor_id, $ad_title, $lessons_taught, $location, $levels, $languages, $about_lesson, $about_tutor, $rate_details, $video_url, $recommendations);

if ($stmt->execute()) {
    echo "Ad saved successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
