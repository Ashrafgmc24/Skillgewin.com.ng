<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['ready']) || !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit();
}

$tutor_id = $_SESSION['tutor_id']; // Assuming you store the tutor's ID in the session
$title = "Tutor - Dashboard";
include __DIR__ . "/includes/app_header.php";
include __DIR__ . "/includes/app_nav.php";

// Database connection
include "includes/db_connection.php";

// Initialize variables
$kyc_data = null;
$error_message = "";

// Check if KYC is already submitted for this tutor using email
if (isset($_SESSION['tutor_email'])) {
    $email = $_SESSION['tutor_email'];
    $query = "SELECT * FROM kyc_details WHERE kycEmail = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $kyc_data = $result->fetch_assoc();
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Fetch form data
    $issuing_country = $_POST['issuing_country'];
    $document_type = $_POST['document_type'];
    $document_number = strip_tags($_POST['document_number']);
    $first_name = strip_tags($_POST['first_name']);
    $last_name = strip_tags($_POST['last_name']);
    $date_of_birth = $_POST['date_of_birth'];
    $address = strip_tags($_POST['address']);
    $kycEmail = strip_tags($_POST['kycEmail']);
    $accepted_terms = isset($_POST['accepted_terms']) ? 1 : 0;

    // Check if email already exists in KYC
    $check_query = "SELECT * FROM kyc_details WHERE kycEmail = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("s", $kycEmail);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // If email already exists, don't submit the form
        $error_message = "KYC details for this email already exist!";
    } else {
        // Handle file uploads
        $target_dir = "uploads/";
        $front_image = $target_dir . basename($_FILES["front_image"]["name"]);
        $back_image = $target_dir . basename($_FILES["back_image"]["name"]);
        $passport_photo = $target_dir . basename($_FILES["passport_photo"]["name"]);

        move_uploaded_file($_FILES["front_image"]["tmp_name"], $front_image);
        move_uploaded_file($_FILES["back_image"]["tmp_name"], $back_image);
        move_uploaded_file($_FILES["passport_photo"]["tmp_name"], $passport_photo);

        // Insert into database
        $insert_query = "INSERT INTO kyc_details (id, issuing_country, document_type, document_number, front_image, back_image, passport_photo, first_name, last_name, date_of_birth, address, kycEmail, accepted_terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("isssssssssssi", $tutor_id, $issuing_country, $document_type, $document_number, $front_image, $back_image, $passport_photo, $first_name, $last_name, $date_of_birth, $address, $kycEmail, $accepted_terms);

        if ($stmt->execute()) {
            echo "<script> 
            alert('KYC details submitted successfully!');
            window.location.href='kyc.php'; 
            </script>";
        } else {
            $error_message = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
    
}

?>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

    <!-- Header -->
    <header class="w3-container" style="padding-top:22px">
        <h5><b><i class="fa fa-dashboard"></i> My Dashboard</b></h5>
    </header>

    <div class="container mt-5 w3-padding">
        <?php if ($kyc_data): ?>
            <!-- Display submitted KYC details -->
            <h2 class="w3-center">Submitted KYC Details</h2>
            <p><strong>Issuing Country/Region:</strong> <?php echo $kyc_data['issuing_country']; ?></p>
            <p><strong>Document Type:</strong> <?php echo $kyc_data['document_type']; ?></p>
            <p><strong>Document Number:</strong> <?php echo $kyc_data['document_number']; ?></p>
            <p><strong>First Name:</strong> <?php echo $kyc_data['first_name']; ?></p>
            <p><strong>Last Name:</strong> <?php echo $kyc_data['last_name']; ?></p>
            <p><strong>Date of Birth:</strong> <?php echo $kyc_data['date_of_birth']; ?></p>
            <p><strong>Address:</strong> <?php echo $kyc_data['address']; ?></p>
            <p><strong>Front Image:</strong> <img src="<?php echo $kyc_data['front_image']; ?>" class="img-thumbnail" width="100" /></p>
            <p><strong>Back Image:</strong> <img src="<?php echo $kyc_data['back_image']; ?>" class="img-thumbnail" width="100" /></p>
            <p><strong>Passport Photo:</strong> <img src="<?php echo $kyc_data['passport_photo']; ?>" class="img-thumbnail" width="100" /></p>
        <?php else: ?>
            <!-- Show the form if no KYC data is submitted -->
            <?php if ($error_message): ?>
                <div class="alert alert-danger">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <h2 class="w3-center">KYC FORM</h2>
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="issuing_country" class="form-label">Issuing Country/Region</label>
                    <?php include "countries.php"; ?>
                </div>
                <div class="mb-3">
                    <label for="document_type" class="form-label">Document Type</label>
                    <select name="document_type" id="document_type" class="form-select" required>
                        <option value=""></option>
                        <option value="National ID">National ID</option>
                        <option value="Driving License">Driving License</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="document_number" class="form-label">Document Number</label>
                    <input type="text" class="form-control" id="document_number" name="document_number" required>
                </div>

                <!-- Image Upload with Preview -->
                <div class="mb-3">
                    <label for="front_image" class="form-label">Front Side of Document</label>
                    <input type="file" class="form-control" id="front_image" name="front_image" accept="image/*">
                    <img id="front_preview" class="preview-img"/>
                </div>
                <div class="mb-3">
                    <label for="back_image" class="form-label">Back Side of Document</label>
                    <input type="file" class="form-control" id="back_image" name="back_image" accept="image/*">
                    <img id="back_preview" class="preview-img"/>
                </div>
                <div class="mb-3">
                    <label for="passport_photo" class="form-label">Passport Photo</label>
                    <input type="file" class="form-control" id="passport_photo" name="passport_photo" accept="image/*">
                    <img id="passport_preview" class="preview-img"/>
                </div>

                <!-- Personal Info -->
                <div class="mb-3">
                    <label for="first_name" class="form-label">First Name (As on the document)</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" required>
                </div>
                <div class="mb-3">
                    <label for="last_name" class="form-label">Last Name (As on the document)</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" required>
                </div>
                <div class="mb-3">
                    <label for="date_of_birth" class="form-label">Date of Birth (As on the document)</label>
                    <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" required>
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label">Address (As on the document)</label>
                    <textarea class="form-control" id="address" name="address" required></textarea>
                </div>

                <!-- Email -->
                <div class="mb-3">
                    <label for="kycEmail" class="form-label">Email Address</label>
                    <input type="email" class="form-control" id="kycEmail" name="kycEmail" required>
                </div>

                <!-- Terms Checkbox -->
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="accepted_terms" name="accepted_terms" required>
                    <label class="form-check-label" for="accepted_terms">
                        I accept the <a href="#">terms and conditions</a>
                    </label>
                </div>

                <button type="submit" class="btn btn-primary mt-3">Submit KYC</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
    // Preview image function for front, back, and passport images
    document.getElementById('front_image').addEventListener('change', function() {
        previewImage(this, 'front_preview');
    });
    document.getElementById('back_image').addEventListener('change', function() {
        previewImage(this, 'back_preview');
    });
    document.getElementById('passport_photo').addEventListener('change', function() {
        previewImage(this, 'passport_preview');
    });

    function previewImage(input, previewId) {
        const file = input.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById(previewId).src = e.target.result;
                document.getElementById(previewId).style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    }
</script>

<?php include __DIR__ . "/includes/app_footer.php"; ?>
