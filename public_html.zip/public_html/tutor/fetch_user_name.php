<?php
session_start();
@include __DIR__ . "/includes/db_connection.php";

if (!isset($_GET['user_id'])) {
    echo json_encode(['user_name' => 'Unknown User']);
    exit();
}

$user_id = $_GET['user_id'];
$query = "SELECT names FROM user WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($row) {
    echo json_encode(['user_name' => $row['names']]);
} else {
    echo json_encode(['user_name' => 'Unknown User']);
}
?>
