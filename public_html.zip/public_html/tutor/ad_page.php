<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Header</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Include Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<!-- Include Bootstrap JS --> 
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    .navbar {
      background-color: #fff;
    }
    .navbar .nav-link {
      color: #333;
    }
    .navbar .nav-link.active {
      font-weight: bold;
      color: #000;
    }
    .navbar .search-bar {
      max-width: 300px;
    }
    .navbar .profile-img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
    }
     .create-ad-btn {
      background-color: #ff5a5f;
      color: #fff;
      border-radius: 25px;
    }
    .ad-list-item {
      background-color: #f5f5f5;
      border-radius: 15px;
      padding: 10px;
      display: flex;
      align-items: center;
      
      margin-top: 10px;
    }
    .ad-list-item img {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 10px;
    }
    .premium-section {
      background-color: #333;
      color: #fff;
      padding: 20px;
      border-radius: 15px;
      margin-top: 20px;
      text-align: center;
    }
    .go-premium-btn {
      background-color: #007bff;
      color: #fff;
      border-radius: 25px;
    }
    .profile-section {
      background-color: #f5f5f5;
      padding: 20px;
      border-radius: 15px;
      text-align: center;
      margin-top: 20px;
    }
    .profile-section img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
    }
    @media (max-width: 768px) {
      .navbar .nav-item {
        display: block;
        text-align: center;
      }
      .search-bar, .myb-s{
          display: none;
      }
    }
  </style>
</head>
<body>

<?php
// Database connection

error_reporting(E_ALL);
ini_set('display_errors', 1);


 // Check if the user is logged in
    if (!isset($_SESSION['tutor_id'])) {
      // If the user is not logged in, redirect them to the login page
      echo "<script> window.location.href='../loginTutor.php' </script>";
      //header('Location: ../loginTutor.php');
      exit(); // Ensure no further code is executed
    } 
    
include __DIR__ . "/includes/db_connection.php";

// Fetch profile image from 'tutor' table
$tutor_id = $_SESSION['tutor_id']; // Replace with dynamic tutor ID based on session or other logic
$result = $conn->query("SELECT names, profile_img FROM tutor WHERE id = $tutor_id");
$tutor = $result->fetch_assoc();
$profile_img = $tutor['profile_img'];
$tutorname = $tutor['names'];
?>


<?php
// Database connection
include __DIR__ . "/includes/new_nav.php";
include __DIR__ . "/includes/db_connection.php";


// Fetch ads from 'ads' table 
$id = $_SESSION['tutor_id'];
$ads_result = $conn->query("SELECT subjects, profile_img_ad, title FROM ads WHERE tutor_id =$id "); // Replace with dynamic tutor ID

// Fetch profile image and hourly rate from 'ads' table
$tutor_result = $conn->query("SELECT profile_img_ad, rate_details FROM ads WHERE tutor_id = $id LIMIT 1");
$tutor_ad = $tutor_result->fetch_assoc();
?>

<div class="container mt-4">
  <div class="row">
    <!-- Left Side: Create Ad Button and Ads List -->
    <div class="col-md-4">
      <button class="btn create-ad-btn btn-block" onclick="window.location.href='tutor_ad_page.php'">
        <i class="fas fa-plus"></i> Create an Ad
      </button>
      
      <?php while($ad = $ads_result->fetch_assoc()): ?>
  <div class="ad-list-item">
    <?php if (!empty($ad['profile_img'])): ?>
      <img src="../uploads/<?php echo htmlspecialchars($ad['profile_img']); ?>" alt="Ad Profile">
    <?php else: ?>
      <i class="fa fa-user fa-3x"></i> <!-- Placeholder icon when profile_img is missing -->
    <?php endif; ?>

    <div>
      <span><?php echo htmlspecialchars($ad['subjects'] ?? ''); ?></span>
      <p>
        <?php echo htmlspecialchars($ad['title'] ?? ''); ?>
        <?php if ($ad['title'] === 'online'): ?>
          <i class="fas fa-circle text-success"></i> <!-- Green icon for online -->
        <?php else: ?>
          <i class="fas fa-circle text-secondary"></i> <!-- Gray icon for offline -->
        <?php endif; ?>
      </p>
    </div>
  </div>
<?php endwhile; ?>

      <!-- Premium Section -->
      <div class="premium-section mt-4">
        <h5>Discover how many students click on your listing & boost your visibility</h5>
        <button class="btn go-premium-btn mt-2">Go Premium</button>
      </div>
    </div>

    <!-- Right Side: Profile Section -->
    <div class="col-md-8">
      <div class="profile-section">
  <?php if (!empty($tutor_ad['profile_img'])): ?>
    <img src="../uploads/<?php echo htmlspecialchars($tutor_ad['profile_img']); ?>" alt="Ad Profile">
  <?php else: ?>
    <i class="fa fa-user fa-9x"></i> <!-- Placeholder icon when profile_img is missing -->
  <?php endif; ?>

  <h4 class="mt-2"><?php echo htmlspecialchars($tutorname ?? 'Tutor'); ?></h4>
  <p>Hourly rate <strong>₦<?php echo htmlspecialchars($tutor_ad['rate_details'] ?? ' Not specified'); ?></strong></p>
</div>

    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
