<?php
include "includes/db_connection.php";

$id = $_POST['ad_id'];
$ad_title = $_POST['ad_title'];
$location = $_POST['location'];
$rate = $_POST['rate'];

$stmt = $conn->prepare("UPDATE ads SET ad_title = ?, location = ?, rate = ? WHERE id = ?");
$stmt->bind_param("sssi", $ad_title, $location, $rate, $id);
if ($stmt->execute()) {
    echo "Ad updated successfully.";
} else {
    echo "Error updating ad.";
}
?>
