<?php
session_start();
include "includes/db_connection.php";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tutor_id = $_SESSION['tutor_id'];
    $names = $_POST['names'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $country = $_POST['country'];
    $locations = $_POST['locations'];
    $experience = $_POST['experience'];
    $about_you = $_POST['about_you'];

    // Handle profile image upload
    if (!empty($_FILES['profile_img']['name'])) {
        $target_dir = "../uploads/";
        $profile_img = basename($_FILES["profile_img"]["name"]);
        $target_file = $target_dir . $profile_img;
        move_uploaded_file($_FILES["profile_img"]["tmp_name"], $target_file);
    } else {
        // If no new image is uploaded, keep the old one
        $sql_img = "SELECT profile_img FROM tutor WHERE id = ?";
        $stmt = $conn->prepare($sql_img);
        $stmt->bind_param("i", $tutor_id);
        $stmt->execute();
        $stmt->bind_result($profile_img);
        $stmt->fetch();
        $stmt->close();
    }
 
    // Update tutor profile in the database
    $sql = "UPDATE tutor SET names = ?, email = ?, phone = ?, country = ?, locations = ?, experience = ?, about_you = ?, profile_img = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssi", $names, $email, $phone, $country, $locations, $experience, $about_you, $profile_img, $tutor_id);

    if ($stmt->execute()) {
        // Profile updated successfully, redirect or show success message
        //header("Location: profile_tutor.php?update=success");
       echo '<script> window.location.href="profile_tutor.php?update=success"; </script>';
    } else {
        // Handle error
        echo "Error updating profile: " . $conn->error;
    }
    
    $stmt->close();
    $conn->close();
}
?>
