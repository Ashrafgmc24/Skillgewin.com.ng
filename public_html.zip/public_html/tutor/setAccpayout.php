<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit(); // Ensure no further code is executed
}
$title = "Tutor -Dashboard";


include __DIR__ ."/includes/app_header.php";


@include __DIR__ ."/includes/app_nav.php";
// require "../app_settings.php";
// require  "../app_header.php";
// require  "../app_nav.php";
?>

<!-- !PAGE CONTENT! -->
<main class="w3-main" style="margin-left:300px;margin-top:43px;">

<div class="container mt-5">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Setup Payout Accounts</h5>
            <!-- Nav Tabs -->
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="paystack-tab" data-bs-toggle="tab" data-bs-target="#paystack" type="button" role="tab" aria-controls="paystack" aria-selected="true">Paystack</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="iban-tab" data-bs-toggle="tab" data-bs-target="#iban" type="button" role="tab" aria-controls="iban" aria-selected="false">IBAN</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="swift-tab" data-bs-toggle="tab" data-bs-target="#swift" type="button" role="tab" aria-controls="swift" aria-selected="false">SWIFT</button>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content mt-3" id="myTabContent">
                <!-- Paystack Form -->
                <div class="tab-pane fade show active" id="paystack" role="tabpanel" aria-labelledby="paystack-tab">
                    <form method="post">
                        <div class="mb-3">
                            <label for="paystackEmail" class="form-label">Paystack Email <span class="text-danger">*</span></label>
                            <input type="email" class="form-control" id="paystackEmail" name="paystack_email" placeholder="Enter Paystack email" required>
                        </div>
                        <button type="submit" name="paystack" class="btn btn-primary">Save Changes</button> <br>
                        <?php //echo $_SESSION['tutor_id'];  ?>
                    </form>
                    
                </div>
<?php


// Handle Paystack Form Submission
include __DIR__ ."/includes/db_connection.php";

if (isset($_POST['paystack'])) {
    
    $tutor_id = $_SESSION['tutor_id'];
    $paystackEmail = $_POST['paystack_email'];
    
    $stmt = $conn->prepare("INSERT INTO paystack_accounts (tutor_id, payout_email, created_at) VALUES (?, ?, NOW())");
    $stmt->bind_param('is', $tutor_id, $paystackEmail);
    if ($stmt->execute()) {
        echo "<script> window.location.href = 'setAccpayout.php'; </script>";
    } else {
               echo "<script> alert('Please try again letter'); </script>";
 
    }
}
?>



                <!-- IBAN Form -->
                <div class="tab-pane fade" id="iban" role="tabpanel" aria-labelledby="iban-tab">
                       <form method="POST">
                        <div class="form-group">
                            <label for="fullName">Full Name <span class="text-danger">*</span></label>
                            <input type="text" name="full_name" class="form-control" id="fullName" placeholder="Enter your full name" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="country">Country <span class="text-danger">*</span></label>
                                <select class="form-control" name="country" id="country" required>
                                    <option value="">Select</option>
                                    <option value="USA">USA</option>
                                    <option value="UK">UK</option>
                                    <option value="Canada">Canada</option>
                                    <!-- Add more countries as needed -->
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="bankName">Bank Name <span class="text-danger">*</span></label>
                                <input type="text" name="bank_name" class="form-control" id="bankName" placeholder="Enter your bank name" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="iban">International Bank Account Number (IBAN) <span class="text-danger">*</span></label>
                            <input type="text" name="iban" class="form-control" id="iban" placeholder="Enter your IBAN" required>
                        </div>
                        <button type="submit" name="iban_btn" class="btn btn-primary">Save Changes</button>
                    </form>
                    <div class="table-responsive">
                         <!-- IBAN Accounts Table -->
    <h5>IBAN Accounts</h5>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Full Name</th>
                <th>Country</th>
                <th>Bank Name</th>
                <th>IBAN</th>
                <th>Date Created</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $stmt = $conn->prepare("SELECT id, full_name, country, bank_name, iban, created_at FROM iban_accounts WHERE tutor_id = ?");
            $stmt->bind_param('i', $tutor_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $count = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $count++ . "</td>
                    <td>" . $row['full_name'] . "</td>
                    <td>" . $row['country'] . "</td>
                    <td>" . $row['bank_name'] . "</td>
                    <td>" . $row['iban'] . "</td>
                    <td>" . $row['created_at'] . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
                    </div>
                </div>
<?php
// Handle IBAN Form Submission
if (isset($_POST['iban_btn'])) {
    $fullName = $_POST['full_name'];
    $country = $_POST['country'];
    $bankName = $_POST['bank_name'];
    $iban = $_POST['iban'];
    $tutor_id = $_SESSION['tutor_id'];

    
    $stmt = $conn->prepare("INSERT INTO iban_accounts (tutor_id, full_name, country, bank_name, iban, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param('issss', $tutor_id, $fullName, $country, $bankName, $iban);
    if ($stmt->execute()) {
        echo "<script> window.location.href = 'setAccpayout.php'; </script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}

?>
                <!-- SWIFT Form -->
                <div class="tab-pane fade" id="swift" role="tabpanel" aria-labelledby="swift-tab">
                 <form method="POST">
                        <div class="form-group">
                            <label for="fullName">Full Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="full_name" id="fullName" placeholder="Enter your full name" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="state">State <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="state" id="state" placeholder="State" required>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="city">City <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="city" id="city" placeholder="City" required>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="postcode">Postcode <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="postcode" id="postcode" placeholder="Postcode" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="address">Address <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="address" id="address" placeholder="Enter your address" required>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="accountHolderName">Bank Account Holder's Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="account_holder_name" id="accountHolderName" placeholder="Account Holder's Name" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="bankName">Bank Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="bank_name" id="bankName" placeholder="Enter your bank name" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="branchCountry">Branch Country <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="branch_country" id="branchCountry" placeholder="Branch Country" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="branchCity">Branch City <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="branch_city" id="branchCity" placeholder="Branch City" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="accountNumber">Account Number <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="account_number" id="accountNumber" placeholder="Enter your account number" required>
                        </div>
                        <div class="form-group">
                            <label for="swiftCode">SWIFT Code <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="swift_code" id="swiftCode" placeholder="Enter SWIFT code" required>
                        </div>
                        <button type="submit" name="swift" class="btn btn-primary">Save Changes</button>
                    </form>
                    
    <?php
                    // Handle SWIFT Form Submission
if (isset($_POST['swift'])) {
    $fullName = $_POST['full_name'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $postcode = $_POST['postcode'];
    $address = $_POST['address'];
    $accountHolderName = $_POST['account_holder_name'];
    $bankName = $_POST['bank_name'];
    $branchCountry = $_POST['branch_country'];
    $branchCity = $_POST['branch_city'];
    $accountNumber = $_POST['account_number'];
    $swiftCode = $_POST['swift_code'];
    $tutor_id = $_SESSION['tutor_id'];

    $stmt = $conn->prepare("INSERT INTO swift_accounts (tutor_id, full_name, state, city, postcode, address, account_holder_name, bank_name, branch_country, branch_city, account_number, swift_code, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param('isssssssssss', $tutor_id, $fullName, $state, $city, $postcode, $address, $accountHolderName, $bankName, $branchCountry, $branchCity, $accountNumber, $swiftCode);
    if ($stmt->execute()) {
        echo "<script> window.location.href = 'setAccpayout.php'; </script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
<!-- SWIFT Accounts Table --> 
<hr>

<div class="table-responsive">
    <h5>SWIFT Accounts</h5>
    <table class="table table-bordered">
    <thead>
        <tr>
            <th>#</th>
            <th>Full Name</th>
            <th>Bank Account Number</th>
            <th>Swift Code</th>
            <th>Date Created</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $stmt = $conn->prepare("SELECT id, full_name, account_number, swift_code, created_at FROM swift_accounts WHERE tutor_id = ?");
        $stmt->bind_param('i', $tutor_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $count = 1;
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>" . $count++ . "</td>
                <td>" . $row['full_name'] . "</td>
                <td>" . $row['account_number'] . "</td>
                <td>" . $row['swift_code'] . "</td>
                <td>" . $row['created_at'] . "</td>
            </tr>";
        }
        ?>
    </tbody>
</table>
</div>

                    
                </div>
            </div>
        </div>
    </div>
</div>
</main>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // JavaScript for notification dropdown functionality
    document.getElementById('notificationDropdown').addEventListener('click', function() {
        // Logic to display notifications can be added here
        alert('Notification clicked!');
    });
</script>
  </div>
<?php
require "includes/app_footer.php";
?>