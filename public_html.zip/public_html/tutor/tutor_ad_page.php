<?php session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);


 // Check if the user is logged in
    if (!isset($_SESSION['tutor_id'])) {
      // If the user is not logged in, redirect them to the login page
      echo "<script> window.location.href='../loginTutor.php' </script>";
      //header('Location: ../loginTutor.php');
      exit(); // Ensure no further code is executed
    } 
    
include __DIR__ . "/includes/db_connection.php";

// Fetch profile image from 'tutor' table
$tutor_id = $_SESSION['tutor_id']; // Replace with dynamic tutor ID based on session or other logic
$result = $conn->query("SELECT names, profile_img FROM tutor WHERE id = $tutor_id");
$tutor = $result->fetch_assoc();
$profile_img_totur = $tutor['profile_img'];
$tutorname = $tutor['names'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Multi-Step Form with Info Box</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .info-box {
      background-color: #ffecec;
      padding: 20px;
      border-radius: 5px;
    }
    
    .info-icon {
      color: red;
      display: none;
      font-size: 24px;
      cursor: pointer;
      text-align: center;
    }

    textarea {
      resize: none;
    }

    .overlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 1049;
    }

    .overlay.show {
      display: block;
    }

    @media (max-width: 768px) {
         sup{
     font-size: 11px;
 }
 h3{
   font-size: 16px;  
 }
      .info-box {
        background-color: #ffecec;
        padding: 20px;
        border-radius: 5px;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        transform: translateY(100%);
        transition: transform 0.4s ease-in-out;
        z-index: 1050;
      }
      
      .info-box.show {
        transform: translateY(0%);
      }
      
      .info-box {
        display: none;
      }
      
      .info-icon {
        display: block;
      }
      
      .info-box.show {
        display: block;
      }
    }
    
    #imagePreview {
      margin-top: 10px;
      max-width: 100%;
      height: auto;
    }
  </style>
</head>
<body>
<div class="container my-5">
  <div class="row">
    <div class="col-md-4">
      <!-- Info boxes for each step -->
      <div class="info-box" id="infoBox">
        <div id="infoStep0">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
          <p>Skillgewin gives you the opportunity to teach and share your knowledge in more than 1000 subjects.</p>
          <div style="text-align: center">
               <button onclick="toggleInfoBox()" style="color: #fff; background: green; padding: 10px;">I understand</button>
          </div>
         
        </div>
        <div id="infoStep1" style="display: none; overflow: scroll;">
            <section class="" style="overflow-y: scroll; padding-top: 30px;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
          <p>Your title is the key to your ad! Take care of it! It must be unique, eye-catching and contain at least 12 words:</p>
          <ul>
              <li>The subject you teach</li>
              <li>The level you teach</li>
              <li>Location of the lessons</li>
              <li>Qualifications, experience etc.</li>
          </ul>
          

<h4>WHAT WORKS</h4>
<p>
• Engineering Graduate teaches maths and physics for GCSE and A level in London <br>
or <br>
• Concert pianist with 15 years of experience gives piano and music theory lessons at home

</p>
<h4>WHAT DOESN'T WORK
</h4>
<p>• Singing and Guitar lessons for ₦1500.

</p>
<div style="text-align: center">
               <button onclick="toggleInfoBox()" style="color: #fff; background: green; padding: 10px;">I understand</button>
          </div>
          </section>
        </div>
        <div id="infoStep2" style="display: none;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
         <p>Explain your approach to tutoring and how you teach your classes:</p> 
<ul>
    <li>Your techniques and teaching methodology</li>
    <li>Typical length of a lesson</li>
    <li>Your qualifications/experience as a tutor</li>
    <li>Who are your lesson for (level, age, etc.)</li>
</ul>

<h4>DON'T FORGET <?php echo $tutorname;?>
</h4>
 <p>
 Contact details and URLs must not appear in your ad.
 </p>
<div style="text-align: center">
               <button onclick="toggleInfoBox()" style="color: #fff; background: green; padding: 10px;">I understand</button>
          </div>

        </div>
        <div id="infoStep4" style="display: none;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
        <p>Inspire confidence, establish your legitimacy and reassure students of your professionalism.</p>  
<p>
This is one of the first things that the students will read about you, remember to take care of your spelling and grammar.
</p>
<p><i> REMEMBER</i></p>
<p>Your contact details and URLs should still not appear.</p>

        </div>
        <div id="infoStep5" style="display: none;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
         <p>
         Your address will never appear on the site. It will only be given to the students you agree to teach.
         </p> 

<p><i class="fa fa-home"></i> You can offer your lessons at home at the address indicated</p>

<p><i class="fa fa-car"></i> "You can travel" indicates that classes can be held at the student's home or at another location that you determine together.</p>
<p> <i class="fa fa-camera"></i>
You can also teach your classes around the world via webcam!
</p>
<div style="text-align: center">
               <button onclick="toggleInfoBox()" style="color: #fff; background: green; padding: 10px;">I understand</button>
          </div>
        </div>
        <div id="infoStep6" style="display: none;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
          <p>You are free to choose your hourly rate and change it at any time.</p>
          <p> If you are just starting out, and don't have any reviews or recommendations be aware that a very high price might put people off. You can always use a lower rate to attract students initially and adjust it as you gain a reputation.</p>
          <div style="text-align: center">
               <button onclick="toggleInfoBox()" style="color: #fff; background: green; padding: 10px;">I understand</button>
          </div>
        </div>
        <div id="infoStep7" style="display: none;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
          <p>Choose a mobile number on which you can easily be reached and we will send you an SMS as soon as you receive a lesson request.</p>
          <div style="text-align: center">
               <button onclick="toggleInfoBox()" style="color: #fff; background: green; padding: 10px;">I understand</button>
          </div>
        </div>
        <div id="infoStep8" style="display: none;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
          <p> 
          Your photo will be used for all your ads, a professional quality photo will help you build trust with your future students and maximize lesson requests.
            </p>
<ul>
    <li>Show yourself alone and smiling!</li>
    <li>Face and gaze in front of the lens</li>
    <li>Avoid sunglasses, logos, blurry, pixelated or too dark photos</li>
    <li></li>
</ul>
<p>Min. 600x600px, .PNG or .JPEG</p>
<div style="text-align: center">
               <button onclick="toggleInfoBox()" style="color: #fff; background: green; padding: 10px;">I understand</button>
          </div>
        </div>
        <!-- <div id="infoStep9" style="display: none;">
          <h4><i class="fas fa-smile"></i> Good to know</h4>
          <p>Qwerty math can improve logical and analytical skills in students.</p>
        </div> -->
        <!-- Additional infoStep divs for each step -->
    
    </div>
      
    </div>
    <div class="col-md-8">
      <form id="multiStepForm" method="POST" enctype="multipart/form-data">
        <!-- Step 1 -->
        <div class="form-step">
          <h3>Which <span style="color:red;">subjects</span> do you teach?</h3>
          <input type="text" class="form-control my-3" name="subjects" placeholder="Example: Computer, Mathematics..." required oninput="validateForm()">
        </div>
        <!-- Step 2 -->
        <div class="form-step" style="display: none;">
          <h3><span style="color:red;">Title</span> of your ad <sup>(12 words minimum)</sup></h3>
          <textarea class="form-control my-3" id="ad_title" name="ad_title" cols="30" rows="10" placeholder="E.g.: Skilled Guitarist teaches guitar for all levels..." required oninput="validateForm()"></textarea>
        </div>
        <!-- Step 3 -->
        <div class="form-step" style="display: none;">
          <h3>About<span style="color:red;"> lessons</span><sup>(40 words minimum)</sup></h3>
          <textarea class="form-control my-3" id="about_lesson" name="about_lesson" cols="30" rows="10" placeholder="Explain your tutoring approach..." required oninput="validateForm()"></textarea>
        </div>
        <!-- Step 4 -->
        <div class="form-step" style="display: none;">
          <h3>About<span style="color:red;"> you</span> <sup>(40 words minimum)</sup></h3>
          <textarea class="form-control my-3" id="about_you" name="about_you" cols="30" rows="10" placeholder="Tell your future students about yourself..." required oninput="validateForm()"></textarea>
        </div>
        <!-- Step 5 -->
        <div class="form-step" style="display: none;">
          <h3><span style="color:red;">Location</span> details</h3>
          <input type="text" class="form-control my-3" name="location" placeholder="Your location" required oninput="validateForm()">
          <h4>Where can your lessons be held?</h4>
          <select name="lesson_held" class="form-control my-3" required oninput="validateForm()">
            <option value="">Select an option</option>
            <option value="Your home">Your home</option>
            <option value="You can travel">You can travel</option>
            <option value="Online">Online</option>
          </select>
        </div>
        <!-- Step 6 -->
        <div class="form-step" style="display: none;">
          <h3>Hourly <span style="color:red;">rate</span></h3>
          <input type="text" class="form-control my-3" name="rate" placeholder="Example: 3000" required oninput="validateForm()">
        </div>
        <!-- Step 7 -->
        <div class="form-step" style="display: none;">
          <h3>Phone <span style="color:red;">number</span></h3>
          <p>Your number is only shared with approved students.</p>
          <input type="number" class="form-control my-3" name="phone_number" placeholder="+123, +234...." required oninput="validateForm()">
        </div>
        <!-- Step 8 -->
        <div class="form-step" style="display: none;">
          <h3>Profile <span style="color:red;">picture</span></h3>
          
          <img id="imagePreview" src="../uploads/<?php echo $profile_img_totur; ?>" style="">
          
          <input type="file" name="profile_picture" id="profile_picture" class="form-control my-3" accept="image/*" onchange="previewImage(); validateForm()" required>
<!--          $profile_img = $tutor['profile_img'];-->
<!--$tutorname = $tutor['names'];-->

          <img id="imagePreview" src="#" alt="Image Preview" style="display: none;">
        </div>
        <!-- Navigation buttons -->
        <div class="d-flex justify-content-between">
          <button type="button" class="btn btn-secondary" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
          <button type="button" class="btn btn-primary" id="nextBtn" onclick="nextPrev(1)" disabled>Next</button>
        </div>
      </form>
      <div class="info-icon" onclick="toggleInfoBox()">
        <i class="fas fa-info-circle"></i>
      </div>
    </div>
  </div>
</div>
<div class="overlay" id="overlay" onclick="toggleInfoBox()"></div>
<?php
// session_start();
// error_reporting(E_ALL);
// ini_set('display_errors', 1);

// if (!isset($_SESSION['tutor_id'])) {
//     echo "<script> window.location.href='../loginTutor.php' </script>";
//     exit();
// }

include __DIR__ . "/includes/db_connection.php";

$tutor_id = $_SESSION['tutor_id'];
$result = $conn->query("SELECT names, profile_img FROM tutor WHERE id = $tutor_id");
$tutor = $result->fetch_assoc();
$current_profile_img = "../uploads/" . $tutor['profile_img'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tutor_id = $_SESSION['tutor_id'];
    $subjects = $_POST['subjects'];
    $ad_title = $_POST['ad_title'];
    $about_lesson = $_POST['about_lesson'];
    $about_you = $_POST['about_you'];
    $location = $_POST['location'];
    $lesson_held = $_POST['lesson_held'];
    $rate = $_POST['rate'];
    $phone_number = $_POST['phone_number'];

    // Check if a new profile picture is uploaded
    if (!empty($_FILES["profile_picture"]["name"])) {
        $target_dir = "../uploads/";
        $new_image_name = basename($_FILES["profile_picture"]["name"]);
        $target_file = $target_dir . $new_image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check file type (allow only certain types of images)
        $allowed_types = ['jpg', 'jpeg', 'png'];
        if (in_array($imageFileType, $allowed_types)) {
            if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file)) {
                $profile_img = $target_file;
            } else {
                echo "Sorry, there was an error uploading your file.";
                exit();
            }
        } else {
            echo "Sorry, only JPG, JPEG, & PNG files are allowed.";
            exit();
        }
    } else {
        // Use the current profile image if no new image is uploaded
        $profile_img = $current_profile_img;
    }

    // Insert data into the ads table
    $stmt = $conn->prepare("INSERT INTO ads (tutor_id, subjects, ad_title, about_lesson, about_tutor, location, lesson_held, rate_details, phoneNo, profile_img) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssssss", $tutor_id, $subjects, $ad_title, $about_lesson, $about_you, $location, $lesson_held, $rate, $phone_number, $profile_img);

    if ($stmt->execute()) {
        echo "Ad successfully created!";
        echo "<script>window.location.href='ad_page.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<script>
  let currentStep = 0;
  const minWords = { ad_title: 12, about_lesson: 40, about_you: 40 };
  const form = document.getElementById("multiStepForm");
  const nextBtn = document.getElementById("nextBtn");

  document.addEventListener("DOMContentLoaded", () => {
    showStep(currentStep);
    document.getElementById("profile_picture").addEventListener("change", previewImage);
  });

  function toggleInfoBox() {
    const infoBox = document.getElementById("infoBox");
    infoBox.style.display = infoBox.style.display === "none" ? "block" : "none";
  }

  function toggleInfoBox() {
    const infoBox = document.getElementById("infoBox");
    const overlay = document.getElementById("overlay");
    const isVisible = infoBox.classList.toggle("show");
    overlay.classList.toggle("show", isVisible);
  }

  function previewImage() {
    const file = document.getElementById("profile_picture").files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = e => {
        const imgPreview = document.getElementById("imagePreview");
        imgPreview.src = e.target.result;
        imgPreview.style.display = "block";
      };
      reader.readAsDataURL(file);
    }
  }

  function countWords(text) {
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
  }

  function validateForm() {
    const inputs = form.querySelectorAll(".form-step")[currentStep].querySelectorAll("input, textarea, select");
    let allValid = true;
    inputs.forEach(input => {
      if (!input.value) {
        allValid = false;
      } else if (input.id && minWords[input.id]) {
        const wordCount = countWords(input.value);
        if (wordCount < minWords[input.id]) {
          allValid = false;
        }
      }
    });
    nextBtn.disabled = !allValid;
    return allValid;
  }

  function showStep(step) {
  const steps = document.querySelectorAll(".form-step");
  const infoSteps = [
    document.getElementById("infoStep0"),
    document.getElementById("infoStep1"),
    document.getElementById("infoStep2"),
    document.getElementById("infoStep4"),
    document.getElementById("infoStep5"),
    document.getElementById("infoStep6"),
    document.getElementById("infoStep7"),
    document.getElementById("infoStep8")
  ];
  
  // Hide all steps and info steps
  steps.forEach((el, index) => el.style.display = index === step ? "block" : "none");
  infoSteps.forEach((el, index) => el.style.display = index === step ? "block" : "none");
  
  // Adjust button visibility and text
  document.getElementById("prevBtn").style.display = step === 0 ? "none" : "inline";
  nextBtn.innerHTML = step === (steps.length - 1) ? "Submit" : "Next";
  
  // Validate form for enabling/disabling next button
  validateForm();
}


  function nextPrev(n) {
    const steps = document.querySelectorAll(".form-step");
    if (n > 0 && !validateForm()) return;
    currentStep += n;
    if (currentStep >= steps.length) return form.submit();
    showStep(currentStep);
  }
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>