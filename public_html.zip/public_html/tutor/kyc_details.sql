CREATE TABLE kyc_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    issuing_country VARCHAR(100) NOT NULL,
    document_type VARCHAR(50) NOT NULL,
    document_number VARCHAR(50) NOT NULL,
    front_image VARCHAR(255),
    back_image VARCHAR(255),
    passport_photo VARCHAR(255),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    address TEXT NOT NULL,
    accepted_terms BOOLEAN NOT NULL
);
