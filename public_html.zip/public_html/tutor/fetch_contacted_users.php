<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include __DIR__ . "/includes/db_connection.php";

if (!isset($_SESSION['tutor_id'])) {
    echo json_encode(['error' => 'Tutor ID not set in session']);
    exit();
}

$tutor_id = $_SESSION['tutor_id'];
$query = $conn->prepare("SELECT contact_tutor.user_id, user.names, user.email, contact_tutor.contact_time 
FROM contact_tutor 
JOIN user ON contact_tutor.user_id = user.id 
WHERE contact_tutor.tutor_id = ?
");
$query->bind_param("i", $tutor_id);
$query->execute();
$result = $query->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['error' => 'No contacted users found']);
    exit();
}

$contacted_users = [];
while ($row = $result->fetch_assoc()) {
    $contacted_users[] = $row;
}

echo json_encode($contacted_users);
?>
