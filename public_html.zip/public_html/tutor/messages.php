<?php
session_start();

// Check if the tutor is logged in
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    header('Location: ../loginTutor.php');
    exit();
}
include __DIR__ . "/includes/db_connection.php";
$title = "Tutor - Messages";
include __DIR__ . "/includes/app_header.php";
@include __DIR__ . "/includes/app_nav.php";
?>

<!-- Main Content -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">
  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> Messages</b></h5>
  </header>

  <!-- Chat Page Layout -->
  <div class="container mt-4">
    <div class="row">
        <!-- Sidenav for contacted users -->
        <div class="col-md-4">
            <button class="btn btn-primary d-md-none mb-2" id="toggleUsersBtn">
                Show Contacted Users
            </button>
            <div id="contactedUsersSidenav" class="w3-sidebar w3-bar-block w3-light-grey" style="">
                <h4>Contacted Users</h4>
                <ul id="userList" class="list-group">
                    <!-- Contacted users will be loaded here dynamically -->
                </ul>
            </div>

            </div>
        </div>

        <!-- Chat Area -->
        <div class="col-md-8">
            <!-- Fixed User Name at the top -->
            <div id="userName" class="chat-header" style="background-color: #f8f9fa; padding: 10px; border-bottom: 1px solid #ccc; font-weight: bold; position: sticky; top: 0; z-index: 1000;">
                <!-- Contacted User's Name -->
            </div>

            <!-- Chat Window -->
            <div id="chatWindow" style="border: 1px solid #ccc; padding: 20px; height: 400px; overflow-y: scroll;">
                <!-- Messages will be displayed here -->
            </div>

            <!-- Message Input -->
            <div class="mt-2">
                <input type="hidden" id="receiver_id" value="">
                <textarea id="messageInput" class="form-control" placeholder="Type your message..."></textarea>
                <button id="sendMessageBtn" class="btn btn-primary mt-2">Send</button>
            </div>
        </div>
    </div>
  </div>

</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // Toggle Contacted Users Sidenav
    document.getElementById('toggleUsersBtn').addEventListener('click', function() {
        const sidenav = document.getElementById('contactedUsersSidenav');
        sidenav.style.display = (sidenav.style.display === 'none') ? 'block' : 'none';
    });

    // Fetch list of contacted users for the tutor
    fetch('fetch_contacted_users.php')
        .then(response => response.json())
        .then(users => {
            const userList = document.getElementById('userList');
            userList.innerHTML = ''; // Clear any previous data

            if (users.length === 0) {
                userList.innerHTML = '<li>No users contacted yet.</li>';
                return;
            }

            users.forEach(user => {
                const li = document.createElement('li');
                li.textContent = user.names;
                li.classList.add('list-group-item', 'user-item');
                li.setAttribute('data-userid', user.id);

                li.addEventListener('click', function() {
                    const userId = this.getAttribute('data-userid');
                    loadMessages(userId);  // Load chat messages for the selected user
                });

                userList.appendChild(li);
            });
        })
        .catch(error => console.error('Error fetching users:', error));

    // Load chat messages for the selected user
    function loadMessages(user_id) {
        document.getElementById('receiver_id').value = user_id;

        // Fetch user name and set it in the chat box header
        fetch(`fetch_user_name.php?user_id=${user_id}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('userName').textContent = data.user_name;
            });

        // Fetch chat messages
        fetch(`fetch_messages.php?receiver_id=${user_id}`)
            .then(response => response.json())
            .then(messages => {
                const chatWindow = document.getElementById('chatWindow');
                chatWindow.innerHTML = ''; // Clear previous messages

                if (messages.length === 0) {
                    chatWindow.innerHTML = '<p>No messages yet. Start the conversation!</p>';
                    return;
                }

                messages.forEach(message => {
                    const msg = document.createElement('div');
                    msg.classList.add('message-bubble');
                    
                    if (message.sender_id === <?php echo $_SESSION['tutor_id']; ?>) {
                        msg.classList.add('tutor-message'); // Tutor's message on the right
                    }

                    msg.innerHTML = `
                        <div class="message-content">${message.message}</div>
                        <div class="message-time">${new Date(message.timestamp).toLocaleTimeString()}</div>
                    `;
                    chatWindow.appendChild(msg);
                });
            })
            .catch(error => console.error('Error loading messages:', error));
    }

    // Send a new message
    document.getElementById('sendMessageBtn').addEventListener('click', function () {
        const receiver_id = document.getElementById('receiver_id').value;
        const message = document.getElementById('messageInput').value.trim();

        if (message === '' || receiver_id === '') {
            alert('Please select a user and type a message.');
            return;
        }

        fetch('send_message.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `receiver_id=${receiver_id}&message=${encodeURIComponent(message)}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                loadMessages(receiver_id);  // Reload the chat window after sending the message
                document.getElementById('messageInput').value = ''; // Clear the input field
            } else {
                alert('Failed to send message');
            }
        })
        .catch(error => console.error('Error sending message:', error));
    });
</script>

<?php
require "includes/app_footer.php";
?>
