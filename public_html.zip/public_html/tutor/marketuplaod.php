<?php
session_start();
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit(); // Ensure no further code is executed
}
$title = "Payout Tutor";


include __DIR__ ."/includes/app_header.php";
@include __DIR__ ."/includes/app_nav.php";
// require "../app_settings.php";
// require  "../app_header.php";
// require  "../app_nav.php";
?>


<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">


<div class="container mt-5">
    <h2 class="mb-4">Add New Product</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="product_name" class="form-label">Product Name</label>
            <input type="text" class="form-control" name="product_name" id="product_name" placeholder="Enter product name" required>
        </div>
        <div class="mb-3">
            <label for="product_price" class="form-label">Price ($)</label>
            <input type="number" step="0.01" class="form-control" name="product_price" id="product_price" placeholder="Enter product price" required>
        </div>
        <div class="mb-3">
            <label for="product_description" class="form-label">Description</label>
            <textarea class="form-control" name="product_description" id="product_description" rows="3" placeholder="Enter product description"></textarea>
        </div>
        <div class="mb-3">
            <label for="product_image" class="form-label">Product Image</label>
            <input type="file" class="form-control" name="product_image" id="product_image" required>
        </div>
        <button type="submit" name="save_product" class="btn btn-primary">Add Product</button>
    </form>
</div>
<?php

include 'includes/db_connection.php'; 

if (isset($_POST['save_product'])) {
    // Get form inputs
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_description = $_POST['product_description'];

    // Handle image upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["product_image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file is an image
    $check = getimagesize($_FILES["product_image"]["tmp_name"]);
    if ($check !== false) {
        // Move uploaded file to the server
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            // Insert product into the database
            $stmt = $conn->prepare("INSERT INTO products (name, price, description, image) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sdss", $product_name, $product_price, $product_description, $target_file);
            
            if ($stmt->execute()) {
                // Redirect to the admin page or show success message
                //echo "<script>alert('Product added successfully!'); window.location.href='admin_dashboard.php';</script>";
                                echo "<script>alert('Saved product!');</script>";

            } else {
                echo "<script>alert('Error adding product!');</script>";
            }
            
            $stmt->close();
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.');</script>";
        }
    } else {
        echo "<script>alert('File is not an image.');</script>";
    }
}

$conn->close();
?>


</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // Example: JavaScript for handling notifications
    document.getElementById('notificationDropdown').addEventListener('click', function() {
        alert('Notification clicked!');
    });
</script>

<?php
require "includes/app_footer.php";
?>
