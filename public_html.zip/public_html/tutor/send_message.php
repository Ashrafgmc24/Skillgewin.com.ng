<?php
session_start();
@include __DIR__ . "/includes/db_connection.php";

if (!isset($_SESSION['tutor_id']) || !isset($_POST['receiver_id']) || !isset($_POST['message'])) {
    echo json_encode(['success' => false]);
    exit();
}

$tutor_id = $_SESSION['tutor_id'];
$receiver_id = $_POST['receiver_id'];
$message = $_POST['message'];
$timestamp = date("Y-m-d H:i:s");

$query = "INSERT INTO messages (sender_id, receiver_id, message, timestamp) 
          VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("iiss", $tutor_id, $receiver_id, $message, $timestamp);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
?>
