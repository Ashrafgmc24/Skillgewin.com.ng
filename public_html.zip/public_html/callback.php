<?php
require_once 'vendor/autoload.php';
// Create a new client
$client = new Google_Client();
$client->setClientId('1023109408072-lvalbce6qbd86mubv4b8hoahb83fheoi.apps.googleusercontent.com'); // Replace with your Client ID
$client->setClientSecret('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'); // Replace with your Client Secret
$client->setRedirectUri('https://skillgewin.com/callback.php'); // Replace with your callback URL

if (isset($_GET['code'])) {
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $client->setAccessToken($token);

    // Get user info
    $google_oauth = new Google_Service_Oauth2($client);
    $google_account_info = $google_oauth->userinfo->get();

    // Retrieve user data
    $email = $google_account_info->email;
    $name = $google_account_info->name;

    // Start a session and store user data (or store it in your database)
    session_start();
    $_SESSION['email'] = $email;
    $_SESSION['name'] = $name;

    // Redirect to the user's dashboard or home page
    header('Location: dashboard_new.php');
    exit();
} else {
    echo "Authorization failed.";
}
