<?php
include 'include/db_connection.php';

if (isset($_GET['reference'])) {
    $reference = $_GET['reference'];

    // Paystack secret key
    $secretKey = "YOUR_SECRET_KEY"; // Replace with your Paystack secret key

    // Initialize curl for Paystack API verification
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($reference),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $secretKey",
            "Content-Type: application/json"
        ]
    ));

    // Execute curl
    $response = curl_exec($curl);
    $transaction = json_decode($response);

    // Close curl session
    curl_close($curl);

    // Verify transaction status
    if ($transaction->status && $transaction->data->status == 'success') {
        // Payment was successful, save transaction details to database
        $name = $_SESSION['checkout']['name'];
        $address = $_SESSION['checkout']['address'];
        $email = $transaction->data->customer->email;
        $amount = $transaction->data->amount / 100; // Convert kobo to NGN

        // Insert into orders table (example)
        $stmt = $conn->prepare("INSERT INTO transactions (name, email, address, amount, payment_reference) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssds", $name, $email, $address, $amount, $reference);
        $stmt->execute();

        echo "Payment successful! Order has been placed.";
    } else {
        echo "Payment failed. Please try again.";
    }
}
?>
