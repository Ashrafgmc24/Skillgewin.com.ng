<?php
session_start();

// Mock product data (you will fetch it from your database)
// For demonstration, assume products are already stored in the cart session
include 'include/db_connection.php';

// Check if cart is set
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    include 'include/webheader1.php';
    echo "<h2 class='w3-center'>Your cart is empty.</h2>";
    include 'include/webfooter.php';

    exit();
}
 
// Fetch product details from the database based on the product IDs in the cart
$product_ids = array_keys($_SESSION['cart']);
$product_ids_string = implode(",", $product_ids);

$stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($product_ids_string)");
$stmt->execute();
$products = $stmt->get_result();

// Initialize total
$total = 0;
$title = "Processing Checkout";
include 'include/webheader1.php';
?>

<div class="container mt-5 w3-padding">
    <h1 class="w3-center">Checkout</h1>

    <table class="table table-bordered" width="100%">
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = $products->fetch_assoc()) {
                $product_id = $product['id'];
                $quantity = $_SESSION['cart'][$product_id]['quantity'];
                $subtotal = $product['price'] * $quantity;
                $total += $subtotal;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                    <td>$<?php echo number_format($product['price'], 2); ?></td>
                    <td><?php echo $quantity; ?></td>
                    <td>$<?php echo number_format($subtotal, 2); ?></td>
                </tr>
            <?php } ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3" class="text-end">Total</th>
                <th>$<?php echo number_format($total, 2); ?></th>
            </tr>
        </tfoot>
    </table>

    <!-- Checkout form -->
    <form id="paymentForm">
        <div class="mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" class="form-control" id="name" required>
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Shipping Address</label>
            <textarea class="form-control" id="address" rows="3" required></textarea>
        </div>

        <button type="button" class="btn btn-success" onclick="payWithPaystack()">Pay Now with Paystack</button>
    </form>
</div>

<script src="https://js.paystack.co/v1/inline.js"></script>
<script>
    function payWithPaystack() {
        event.preventDefault();

        let handler = PaystackPop.setup({
            key: 'pk_test_9ff12b620d0374b4ff43269ba190243a8b8b31bf', // Replace with your Paystack public key
            email: document.getElementById('name').value, // Collect email or name for customer identification
            amount: <?php echo $total * 100; ?>, // Paystack expects the amount in kobo (for NGN)
            currency: 'NGN', // You can change this to match the currency you need
            ref: 'PS_' + Math.floor((Math.random() * 1000000000) + 1), // Generates a unique reference number
            callback: function(response) {
                // Payment successful, send data to the server for further processing
                let reference = response.reference;
                window.location = "verify_transaction.php?reference=" + reference;
            },
            onClose: function() {
                alert('Transaction was not completed, window closed.');
            }
        });

        handler.openIframe(); // Open Paystack's iframe for payment
    }
</script>

<?php
include 'include/webfooter.php';
?>
