<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
include 'include/db_connection.php'; // Database connection

if (isset($_POST['txtemail'])) {
    $email = $_POST['txtemail'];

    // Use prepared statement to avoid SQL injection
    $query = $conn->prepare("SELECT * FROM tutor WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        date_default_timezone_set('Africa/Lagos');
        // Generate a random number token
        $token = mt_rand(100000, 999999); // Random 6-digit number
        $expiry = date("Y-m-d H:i:s", strtotime('+1 hour'));

        // Store token in the database
        $query = "INSERT INTO password_resets (email, token, expiry) VALUES ('$email', '$token', '$expiry')";
        mysqli_query($conn, $query);

        // Send reset link to user via PHPMailer
        $mail = new PHPMailer(true);
        $mail->SMTPDebug = 0;         // Enable verbose debug output
        $mail->isSMTP();
        $mail->Host       = 'mail.skillgewin.com'; // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                  // Enable SMTP authentication
        $mail->Username   = 'noreply@skillgewin.com'; // SMTP username
        $mail->Password   = '@Noreply12345#';       // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption
        $mail->Port       = 465;                   // TCP port to connect to
 
        $mail->setFrom('noreply@skillgewin.com', 'SKILLGEWIN');
        $mail->addAddress($email);
        
        $mail->addEmbeddedImage('img/logo.jpg', 'logo_cid'); // Ensure to provide the correct path to your logo
        $logo = "<img src='cid:logo_cid' alt='SKILLGEWIN' style='display: block; margin: 0 auto; width: 200px;'>";

        // Content
        $mail->isHTML(true);                      // Set email format to HTML
        $mail->Subject = 'Password Reset Request';
        $mail->Body = "$logo <p style='font-size: 18px;text-align: center;'>Please use the following code to reset your password: <strong>$token</strong> <br> and click on this link <br>
        https://skillgewin.com/reset_pass_tutor.php?id=$token
        </p>
        <footer style='font-size: 18px; padding:10px;background:green; color:white;'>Skillgewin Team</footer>";
        $mail->AltBody = 'Your password reset code is ' . $token;
//https://skillgewin.com/reset_password.php
        if ($mail->send()) {
            echo json_encode(['success' => true, 'message' => 'Password reset code has been sent to your email.']);
            //echo "<script> window.location.href='reset_password.php';</script>";
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to send email.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Email not found.']);
    }
}
?>

