<!-- <form action="" method="get" class="w3-center w3-border w3-round-xxlarge w3-bar form w3-white"> -->
<!-- <span><i class="fa fa-search"></i></span> -->
<!-- <input type="text" name="search" class="srch" placeholder="Search" style="border: none;"> -->
<!-- <button class="w3-btn w3-green w3-round-large"><i class="fa fa-search"></i></button> -->
<!-- </form> -->
<!-- <div style="display: flex; justify-content: space-between;">
<p></p>
<div class="w3-bar w3-light-grey w3-center w3-round-xlarge" style="width: 80%">
  <a class="w3-bar-item w3-button">Home</a>
  
  <input type="text" class="w3-bar-item w3-input" placeholder="Search..">
  <a href="#" class="w3-bar-item w3-button w3-green respons">Go</a>
</div> 

</div> -->

<!--data-aos-duration="1000" data-aos-delay="500"-->
<div class="container my-5" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <!-- Search Bar -->
    <div class="search-bar">
        <!-- <i class="fas fa-book-reader"></i> -->
        <form action="" method="post" class="form" style=" width: 100%;">
        <input type="text" class="search-input w3-round" id="searchQuery" style="border: none; width: 100%" placeholder="Enter subject, e.g. 'Padel'">
        <button class="find-tutor-btn w3-green"></button>
        </form>
        
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#searchQuery').on('input', function() {
        var query = $(this).val();
        
        if (query.length > 2) { // Start searching after 3 characters
            $.ajax({
                url: 'searchTutor.php',
                method: 'POST',
                data: {query: query},
                success: function(response) {
                    $('#tutor-results').html(response);
                }
            });
        } else {
            $('#tutor-results').html(''); // Clear if less than 3 characters
        }
    });
});

</script>

    <!-- Subject List with Arrows -->
    <!--<div class="subject-container">-->
    <!--    <i class="fas fa-chevron-left arrow" onclick="scrollPrev()"></i>-->
    <!--    <div class="subject-list" id="subjectList">-->
    <!--        <div class="subject-item">-->
    <!--            <i class="fas fa-book"></i>-->
    <!--            <p class="sub-sm">Diction</p>-->
    <!--        </div>-->
    <!--        <div class="subject-item">-->
    <!--            <i class="fas fa-font"></i>-->
    <!--            <p class="sub-sm">Literature in English</p>-->
    <!--        </div>-->
    <!--        <div class="subject-item">-->
    <!--            <i class="fas fa-book-open"></i>-->
    <!--            <p class="sub-sm">History</p>-->
    <!--        </div>-->
    <!--        <div class="subject-item">-->
    <!--            <i class="fas fa-laptop"></i>-->
    <!--            <p class="sub-sm">Microsoft Word</p>-->
    <!--        </div>-->
    <!--        <div class="subject-item">-->
    <!--            <i class="fas fa-briefcase"></i>-->
    <!--            <p class="sub-sm">Commerce</p>-->
    <!--        </div>-->
    <!--        <div class="subject-item">-->
    <!--            <i class="fas fa-language"></i>-->
    <!--            <p class="sub-sm">English</p>-->
    <!--        </div>-->
    <!--        <div class="subject-item">-->
    <!--            <i class="fas fa-square-root-alt"></i>-->
    <!--            <p class="sub-sm">Maths</p>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--    <i class="fas fa-chevron-right arrow" onclick="scrollNext()"></i>-->
    <!--</div>-->
</div>

<!-- Bootstrap 4 JS -->
<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->

<!-- Custom JS for Next and Previous Scrolling -->
<script>
    function scrollNext() {
        document.getElementById('subjectList').scrollBy({ left: 120, behavior: 'smooth' });
    }

    function scrollPrev() {
        document.getElementById('subjectList').scrollBy({ left: -120, behavior: 'smooth' });
    }
</script>
