<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top w3-animate-left" style="z-index:3;width:250px"  id="mySidebar">
  <div class="w3-container w3-display-container w3-padding-16">
    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
    <h3 class="w3-wide"><b><img src="img/logo.jpg" width="160px" alt=""></b></h3>
  </div>
  
  <!-- <div class="w3-padding-64 w3-large w3-text-grey" style="font-weight:bold"> -->
    <a href="index.php" class="w3-bar-item w3-button"><i class="fa fa-home"></i> Home</a>
    <a href="tutor.php" class="w3-bar-item w3-button"><i class="fas fa-chalkboard-teacher"></i>  Tutors</a>
        <a href="marketplace.php" class="w3-bar-item w3-button"><i class="fa fa-shopping-cart"></i>  Market Place</a>

    <a href="faqs.php" class="w3-bar-item w3-button"><i class="fa fa-question-circle"></i> FAQs</a>
    <a href="contact.php" class="w3-bar-item w3-button"><i class="fa fa-address-book"></i> Contact</a>
   
    

    <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
    <i class="fa fa-book"></i> Pages <i class="fa fa-caret-down"></i>
    </a>
    <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium">
      <a href="terms.php" class="w3-bar-item w3-button"><i class="fa fas fa-file-contract"></i> Terms and Condition</a>
      <a href="policy.php" class="w3-bar-item w3-button"><i class="fa fa-shield"></i> Privacy Policy</a>
    </div>
    <a onclick="myAccFunc1()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
    <i class="fa fa-lock"></i> Logins <i class="fa fa-caret-down"></i>
    </a>
    <div id="demoAcc1" class="w3-bar-block w3-hide w3-padding-large w3-medium">
      <a href="loginTutor.php" class="w3-bar-item w3-button"><i class="fa fas fa-file-contract"></i> Tutor Jobs</a>
      <a href="loginUser.php" class="w3-bar-item w3-button"><i class="fa fa-lock"></i> Login</a>
    </div>
  <!-- </div> -->
 
  <!-- <a href="#footer" class="w3-bar-item w3-button w3-padding">Contact</a> 
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding" onclick="document.getElementById('newsletter').style.display='block'">Newsletter</a> 
  <a href="#footer"  class="w3-bar-item w3-button w3-padding">Subscribe</a> -->
</nav>
<script>

  // Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}
function myAccFunc1() {
  var x = document.getElementById("demoAcc1");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();

</script>