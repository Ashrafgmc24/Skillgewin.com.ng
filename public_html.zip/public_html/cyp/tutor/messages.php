<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit(); // Ensure no further code is executed
}
$title = "Tutor - Messages";


include __DIR__ ."/includes/app_header.php";
@include __DIR__ ."/includes/app_nav.php";
// require "../app_settings.php";
// require  "../app_header.php";
// require  "../app_nav.php";
?>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">

  <!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> Messages</b></h5>
  </header>

  <div class="w3-row-padding w3-margin-bottom">
   <!-- Main Content -->
<div class="container mt-4">
    <div class="row">
      
    </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // JavaScript for notification dropdown functionality
    document.getElementById('notificationDropdown').addEventListener('click', function() {
        // Logic to display notifications can be added here
        alert('Notification clicked!');
    });
</script>
  </div>
<?php
require "includes/app_footer.php";
?>