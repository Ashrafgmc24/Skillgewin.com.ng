<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['ready']) && !isset($_SESSION['tutor_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: ../loginTutor.php');
    exit(); // Ensure no further code is executed
}

$title = "Set Payout Account";

// Include necessary files
include __DIR__ . "/includes/app_header.php";
@include __DIR__ . "/includes/app_nav.php";
@include __DIR__ . "/includes/db_connection.php"; // Ensure database connection is included

// Handle form submission
if (isset($_POST['saveb'])) {
    // Sanitize and retrieve form input 
    $payname = $name;
    $payoutEmail = strip_tags($_POST['pay_email']);
    $payNomba = $phone;
    // Prepare and bind the SQL statement
    $stmt_pay = $conn->prepare("INSERT INTO payout_accounts (names, payout_email, phoneN) VALUES (?, ?, ?)");
    $stmt_pay->bind_param('sss', $payname, $payoutEmail, $payNomba);

    // Execute the statement
    if ($stmt_pay->execute()) {
        echo "<script>alert('Payout account saved successfully!');</script>";
        // Optional: Refresh or redirect after successful submission
        header("Refresh:2");
    } else {
        echo "<script>alert('Record not saved.');</script>";
    }

    // Close the prepared statement
    $stmt_pay->close();
}

// Close the database connection
$conn->close();
?>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:300px;margin-top:43px;">
    <!-- Header -->
    <header class="w3-container" style="padding-top:22px">
        <h5><b><i class="fa fa-dashboard"></i> Payout</b></h5>
    </header>

    <div class="w3-row-padding w3-margin-bottom">
        <div class="container mt-5">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Setup Payout Accounts</h5>
                    <!-- Nav Tabs -->
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="paystack-tab" data-bs-toggle="tab" data-bs-target="#paystack" type="button" role="tab" aria-controls="paystack" aria-selected="true">Paystack</button>
                        </li>
                    </ul>

                    <!-- Tab Content -->
                    <div class="tab-content mt-3" id="myTabContent">
                        <!-- Paystack Form -->
                        <div class="tab-pane fade show active" id="paystack" role="tabpanel" aria-labelledby="paystack-tab">
                            <form method="post">
                                <div class="mb-3">
                                    <label for="paystackEmail" class="form-label">Paystack Email <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" name="pay_email" id="pay_email" 
                                    placeholder="Enter Paystack email" required>
                                </div>
                                <button type="submit" name="saveb" class="btn btn-primary">Save Changes</button>
                            </form>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<script>
    // Example: JavaScript for handling notifications
    document.getElementById('notificationDropdown').addEventListener('click', function() {
        alert('Notification clicked!');
    });
</script>

<?php
require "includes/app_footer.php";
?>
