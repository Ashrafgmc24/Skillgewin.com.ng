<?php
// Start session for adding items to cart
session_start();

// Include the database connection
include 'include/db_connection.php';

// Check if 'id' parameter exists in the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = $_GET['id'];

    // Fetch product details from the database using prepared statements
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the product exists
    if ($result->num_rows > 0) {
        // Fetch the product data
        $product = $result->fetch_assoc();
    } else {
        echo "Product not found.";
        exit();
    }

    $stmt->close();
} else {
    echo "Invalid product ID.";
    exit();
}

// Close the database connection
$conn->close();
?>
<?php  
$title = htmlspecialchars($product['name']);;
include 'include/webheader1.php';
?>
    <div class="container mt-5" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <div class="row" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
            <div class="col-md-6" >
                <img src="<?php echo 'tutor/' . htmlspecialchars($product['image']); ?>" class="img-fluid" alt="<?php echo htmlspecialchars($product['name']); ?>">
            </div>
            <div class="col-md-6">
                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                <h4>Price: $<?php echo number_format($product['price'], 2); ?></h4>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($product['location']); ?></p>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($product['description']); ?></p>

                <!-- Add to Cart Form with Quantity -->
                <form action="add_to_cart.php" method="GET">
                    <input type="hidden" name="id" value="<?php echo $product_id; ?>">
                    <div class="form-group mb-3">
                        <label for="quantity">Quantity:</label>
                        <input type="number" name="quantity" id="quantity" class="form-control" value="1" min="1">
                    </div>
                    <button type="submit" class="btn btn-warning">Add to Cart</button>
                </form>

                <!-- Buy Now Button -->
                <a href="checkout.php?id=<?php echo $product_id; ?>" class="btn btn-success">Buy Now</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<?php  
include 'include/webfooter.php';
?>
