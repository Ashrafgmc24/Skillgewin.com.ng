<?php  
$title = "Home Page";
include 'include/webheader.php';
//include 'include/mysearch.php'; 
// include "include/subject.php";
?>
<h1 class="w3-center">
Find the <br>
perfect tutor

</h1>
  <?php    
      include 'include/mysearch.php'; 
// include "include/subject.php";
?>
      <hr>
  
      <!-- Tabs -->
      <div class="w3-bar w3-border">
        <button class="w3-bar-item w3-button" onclick="openCity('user')">User</button>
        <button class="w3-bar-item w3-button" onclick="openCity('Tutor')">Tutor</button>
      </div>

      <!-- User tab content -->
      <div id="user" class="city w3-animate-zoom w3-center">
        <h1>Learn and grow with help <br> from world-class tutors</h1>
        <p>Build an epic career with expert mentors <br> from all over the world, let's start today.</p>
        <button class="w3-btn w3-green" onclick="userpage()">Get Started</button>
      </div>

      <!-- Tutor tab content -->
      <div id="Tutor" class="city w3-animate-zoom w3-center" style="display:none">
        <h1>Teach and grow with help <br> to a learner worldwide</h1>
        <p>Build confidence as a leader, grow your network, <br> and define your legacy.</p>
        <br> 
        <button class="w3-btn w3-green" onclick ="usertutor()">Become a Member</button>
      </div>
    </header>
<script>
function userpage(){
  window.location.href ="signupuser.php";
}
function usertutor() {
  window.location.href ="signuptutor.php";
  
}
 function openCity(cityName) {
        var i;
        var x = document.getElementsByClassName("city");
        for (i = 0; i < x.length; i++) {
          x[i].style.display = "none";
        }
        document.getElementById(cityName).style.display = "block";
      }
</script>

    <hr>
    
    <!-- Workflow -->
    <div class="w3-container w3-text-black w3-center">
      <p><span class="w3-teal w3-padding w3-round">Workflow</span></p>
      <h1>Look at a glance how <br> our system works</h1>
      <article class="w3-center w3-container">
        <div class="w3-row w3-border w3-padding w3-round-xlarge w3-white">
          <div class="w3-third w3-container">
            <div class="w3-container">
              <img src="img/ava1.png" class="avata">
              <h2>Create Accounts</h2>
              <p>It’s very easy to open an account and start <br> your mentorship journey.</p> 
            </div>
          </div>

          <div class="w3-third w3-container">
            <div class="w3-container">
              <img src="img/ava2.png" class="avata">
              <h2>Complete your profile</h2>
              <p>Complete your profile with all the info to <br> get the attention of mentees</p>
            </div>
          </div>

          <div class="w3-third w3-container w3-center">
            <div class="w3-container">
              <img src="img/ava3.png" class="avata">
              <h2>Connect with Tutor</h2>
              <p>Explore our growing catalogue of <br> experienced tutors until you find the perfect fit.</p>
            </div>
          </div>
        </div>
      </article>
    </div>

    <hr>
    
    <!-- Categories -->
    <div class="w3-container w3-text-black w3-center">
      <p><span class="w3-teal w3-padding w3-round">Categories</span></p>
      <h1>Browse Tutors by Categories</h1>
    </div>

    <hr>
    
    <?php  

include 'include/webfooter.php';
?>
