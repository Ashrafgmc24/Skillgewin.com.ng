<?php 
session_start();

$title = "Privacy Policy";
include 'include/webheader1.php';
?>

<h2 class="w3-center w3-text-teal" data-aos="zoom" data-aos-duration="1000" data-aos-delay="500">Privacy Policy</h2>

<section class="w3-container w3-light-grey" style="padding: 0px;">
    <div class="w3-white w3-padding  w3-mytext" style="line-height:  30px;">
        <div class="row">
            <div class="col-12">
                <div class="content-container minh-400"> 
                    <div class="faq">
                        <div class="accordion-container text-dark">  
                            <p data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><strong>Privacy Policy for Mentorship Company</strong></p>
                            <p data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><strong>Effective Date: 22 Feb 2024</strong></p>
                            
                            <p data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">Mentorship Company ("we" or "us") is committed to protecting the privacy of our users. This Privacy Policy outlines how we collect, use, disclose, and safeguard your personal information when you use our services or website.</p>
                            
                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">1. Information We Collect:</h5>
                            <ul class="my-ull">
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><strong>1.1. Personal Information:</strong>
                                    <ul class="my-ull">
                                        <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">When you create an account or use our services, we may collect personal information such as your name, email address, and payment information.</li>
                                        <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">We may also collect demographic information, such as your age, gender, and occupation, to better tailor our services to your needs.</li>
                                    </ul>
                                </li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><strong>1.2. Usage Information:</strong>
                                    <ul class="my-ull">
                                        <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">We collect information about how you interact with our website and services, including your browsing activity, session duration, and IP address.</li>
                                    </ul>
                                </li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><strong>1.3. Communications:</strong>
                                    <ul class="my-ull">
                                        <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">When you contact us or communicate with other users through our platform, we may collect and store the content of your communications.</li>
                                    </ul>
                                </li>
                            </ul>

                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">2. Use of Information:</h5>
                            <ul class="my-ull">
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">2.1. We use the information we collect to provide and improve our services, personalize your experience, and communicate with you about our products and promotions.</li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">2.2. We may use your information to respond to your inquiries, troubleshoot technical issues, and enforce our Terms and Conditions.</li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">2.3. We may aggregate and anonymize user data for analytical purposes, such as monitoring usage trends and improving our services.</li>
                            </ul>

                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">3. Disclosure of Information:</h5>
                            <ul class="my-ull">
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">3.1. We may share your personal information with third-party service providers who assist us in operating our website, processing payments, and delivering our services.</li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">3.2. We may disclose your information in response to legal requests, court orders, or government regulations, or to protect our rights, property, or safety, or the rights, property, or safety of others.</li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">3.3. In the event of a merger, acquisition, or sale of all or a portion of our assets, your information may be transferred as part of the transaction. We will notify you via email and/or a prominent notice on our website of any change in ownership or use of your personal information.</li>
                            </ul>

                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">4. Data Security:</h5>
                            <ul class="my-ull">
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">4.1. We employ reasonable security measures to protect your personal information from unauthorized access, alteration, disclosure, or destruction.</li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">4.2. Despite our efforts to safeguard your information, no method of transmission over the Internet or electronic storage is completely secure. Therefore, we cannot guarantee absolute security.</li>
                            </ul>

                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">5. Your Choices:</h5>
                            <ul class="my-ull">
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">5.1. You may update or correct your account information at any time by logging into your account settings.</li>
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">5.2. You may opt-out of receiving promotional emails from us by following the instructions provided in the email or by contacting us directly.</li>
                            </ul>

                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">6. Children's Privacy:</h5>
                            <ul class="my-ull">
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">6.1. Our services are not intended for children under the age of 18. We do not knowingly collect personal information from children under the age of 18. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us immediately.</li>
                            </ul>

                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">7. Changes to this Privacy Policy:</h5>
                            <ul class="my-ull">
                                <li data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">7.1. We reserve the right to update or modify this Privacy Policy at any time. Any changes will be effective immediately upon posting the revised Privacy Policy on our website.</li>
                            </ul>

                            <h5 data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">8. Contact Us:</h5>
                            <p data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">If you have any questions or concerns about this Privacy Policy, please contact us at [Insert Contact Information].</p>
                            
                            <p data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">By using Mentorship Company's services, you consent to the collection and use of your information as outlined in this Privacy Policy.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php  
include 'include/webfooter.php';
?>
