<?php
session_start();
include 'include/db_connection.php'; // Make sure this connects to your database

if (isset($_POST['txtemail']) && isset($_POST['password'])) {
    $email = $_POST['txtemail'];
    $password = $_POST['password'];

    // Query the database
    $query = "SELECT * FROM tutor WHERE email = ? AND passwords = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        
        // Check if the user exists
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['tutor_id'] = $row['id']; // Store the user id in session
            $_SESSION['email'] = $row['email']; // Store the email in session
            $_SESSION["ready"] = "Okay";

            echo 'success';
        } else {
            echo 'Invalid email or password';
        }
        $stmt->close();
    } else {
        echo 'Database query error';
    }
} else {
    echo 'Please fill in both fields';
}

$conn->close();
?>
