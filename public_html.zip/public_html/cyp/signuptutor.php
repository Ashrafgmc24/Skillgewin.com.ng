<?php session_start() ?>

<?php  
$title = "Signup As Tutor";
include 'include/webheader1.php';
include 'include/db_connection.php'; // Include your database connection file
?>
      
      <?php // include "include/subject.php"; ?>
      
      <form id="regForm" action="" method="post" enctype="multipart/form-data" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">

<h1 class="w3-center"><i class="fas fa-chalkboard-teacher" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"></i> Signup As Tutor:</h1>

<!-- One "tab" for each step in the form: -->
<div class="tab">Name:
  <p><input required type="text" name="txtname" id="txtname" placeholder="First name..." oninput="this.className = ''"></p>
  <p><input required type="email" name="txtemail" id="txtemail" placeholder="Email Address." oninput="this.className = ''"></p>

  <p><input type="text" placeholder="Phone No..." id="txtphone" name="txtphone" oninput="this.className = ''"></p>
  <p><input type="password" placeholder="Password" id="txtpass" name="txtpass" oninput="this.className = ''"></p>
  <p><input type="text" placeholder="Location" id="txtlocation" name="txtlocation" oninput="this.className = ''"></p>
 <p>
 Profile Image (A Beautiful Image of less than 3MB)
 </p> 
  <p><input type="file" name="profile" id="profile_image" class="w3-input" id="profile"></p>
  <p>Preview Image</p>
        <img id="imagePreview" src="#" alt="Image Preview" style="display:none; width:100px; height:100px;">

</div>

<div class="tab">Contact Info:

</div>

<!-- <div class="tab">About Your Skill:
  <p><input type="text" placeholder="Experience" id="txtexperience" name="txtexperience" oninput="this.className = ''"></p>
  <p><input type="text" placeholder="Subjects" id="txtsubject" name="txtsubject" oninput="this.className = ''"></p>
  <p><input type="text" placeholder="Title" id="txttitle" name="txttitle" oninput="this.className = ''"></p>
</div> -->

<!-- <div class="tab">About Lesson: (Not less than 12 words)
  <p><textarea style="resize: none; width: 100%;" id="txtaboutlesson" name="txtaboutlesson" placeholder="type here" class="w3-input" name="" id="" cols="30" rows="10" oninput="this.className = ''"></textarea></p>
</div> -->

<!-- <div class="tab">About You: (Not less than 40 words)
  <p><textarea style="resize: none; width: 100%;" id="txtaboutyou" name="txtaboutyou" placeholder="type here" class="w3-input" name="" id="" cols="30" rows="10" oninput="this.className = ''"></textarea></p>
</div> -->
<!-- <div class="tab">Hourly Rate: (Example: N3000 P/H)
  <p><textarea style="resize: none; width: 100%;" id="txthour" name="txthour" placeholder="type here" class="w3-input" name="" id="" cols="30" rows="10" oninput="this.className = ''"></textarea></p>
</div> -->

<div class="tab">
</div>
<div class="tab">Save
  <p><input type="submit" name="btnsubmit" class="w3-btn w3-green w3-round" value="Submit" id="btns"></p>
</div>
<div style="overflow:auto;">
  <div style="float:right;">
    <button type="button" class="w3-green w3-round" style="font-size: 16px" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" class="w3-green w3-round" style="font-size: 16px" onclick="nextPrev(1)">Next</button>
  </div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>
<hr>
<div class="w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
  <p>Already have Account</p>
<a href="loginTutor.php" style="color:white" class="w3-btn w3-green"><i class="fa fa-lock"></i> Sign in</a>
</div>
<hr>
<script src="save_js.js"></script>
<!-- Modals -->

<div id="progressModal" class="w3-modal">
  <div class="w3-modal-content w3-round-large w3-card-4" style="max-width:400px;">
    <header class="w3-container w3-green">
      <h2 class="w3-center">Submitting Data</h2>
    </header>
    <div class="w3-container">
      <p>Please wait...</p>
      <div class="w3-light-grey w3-round">
        <div id="progressBar" class="w3-green w3-round" style="height:24px;width:0%"></div>
      </div>
    </div>
  </div>
</div>

<?php
if(isset($_POST[''])){

}
?>


    <script>
       $("#profile_image").change(function() {
    let reader = new FileReader();
    reader.onload = function(e) {
      $('#imagePreview').attr('src', e.target.result).show();
    }
    reader.readAsDataURL(this.files[0]); // Read the image file as a data URL
  });

    var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
    // document.getElementById("nextBtn").style.display = "none";
    
  } else {
    // document.getElementById("nextBtn").style.display = "inline";

    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  // if (currentTab >= x.length) {
  //   //...the form gets submitted:
  //   document.getElementById("regForm").submit();
  //   return false;
  // }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
    </script>


    <?php  

include 'include/webfooter.php';
?>
