<?php  
session_start();
$title = "User -Login";
include 'include/webheader1.php';
?>

<h1 class="w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><i class="fa fa-user"></i> Sign in As User:</h1>
<section>
<div class="mycontainer" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
  <form id="loginForm" method="post" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <div class="myrow" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
      <h2 style="text-align:center">Login with Social Media or Manually</h2>
      <div class="vl">
        <span class="vl-innertext">or</span>
      </div>

      <div class="col" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <a href="#" class="fb btn" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
          <i class="fab fa-facebook"></i> Login with Facebook
        </a>
        <a href="#" class="google btn" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
          <i class="fab fa-google "></i> Login with Google+
        </a>
      </div>

      <div class="col">
        <div class="hide-md-lg">
          <p>Or sign in manually:</p>
        </div>

        <input class="input" type="email" id="email" name="txtemail" placeholder="Enter your email" required>
        <input class="input" type="password" id="password" name="password" placeholder="Enter your password" required>
        <input class="input" type="submit" value="Login">
      </div>
    </div>
    <div id="statusMessage" style="text-align:center; color:green; margin-top:20px;"></div> <!-- For displaying status -->
  </form>
</div>

<div class="bottom-container">
  <div class="myrow">
    <div class="col">
      <a href="signupuser.php" style="color:white" class="btn">Sign up</a>
    </div>
    <div class="col">
      <a href="#" style="color:white" class="btn">Forgot password?</a>
    </div>
  </div>
</div>
</section>
<hr>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    // When the login form is submitted
    $('#loginForm').on('submit', function(e){
        e.preventDefault(); // Prevent the form from submitting normally

        // Show processing message
        $('#statusMessage').html('Login is processing...');

        // Get form data
        var email = $('#email').val();
        var password = $('#password').val();

        // Send data to loginProcess.php via AJAX
        $.ajax({
            url: 'user_login_script.php',
            type: 'POST',
            data: {
                txtemail: email,
                password: password
            },
            success: function(response) {
                // Parse JSON response
                var data = JSON.parse(response);

                if (data.success) {
                    // Redirect to dashboard if login is successful
                    window.location.href = 'dashboard.php';
                } else {
                    // Display error message
                    $('#statusMessage').html(data.message).css('color', 'red');
                }
            },
            error: function() {
                // Handle error
                $('#statusMessage').html('Error occurred while processing login.').css('color', 'red');
            }
        });
    });
});
</script>

<?php  
include 'include/webfooter.php';
?>
