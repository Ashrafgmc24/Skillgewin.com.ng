<?php
session_start();

// Include database connection
include 'include/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get email and password from the AJAX request
    $email = $_POST['txtemail'];
    $password = $_POST['password']; // Not hashed as per your requirement

    // Check if email and password are provided
    if (!empty($email) && !empty($password)) {
        // Prepare SQL query to check the user in the database
        $query = "SELECT * FROM user WHERE email = ? AND passwords = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $email, $password); // Bind email and password
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Set session variables for the logged-in user
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['names'];

            // Return JSON success response
            echo json_encode(['success' => true]);
        } else {
            // Invalid email or password
            echo json_encode(['success' => false, 'message' => 'Invalid email or password.']);
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        // Return error if email or password is missing
        echo json_encode(['success' => false, 'message' => 'Please fill in all fields.']);
    }
} else {
    // Invalid request method
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
