<?php

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

// Start session

// Database connection
include 'include/db_connection.php';

// Include PHPMailer classes
 
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $name = $_POST['txtname'];
    $email = $_POST['txtemail'];
    $password = $_POST['password']; // Not hashed as requested
    $profile_image = $_FILES['profile_image'];

    // Validate file (profile image)
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
    $fileExtension = strtolower(pathinfo($profile_image['name'], PATHINFO_EXTENSION));
    $fileSize = $profile_image['size'];

    if (!in_array($fileExtension, $allowedExtensions) || $fileSize > 3145728) {
        echo json_encode(['success' => false, 'message' => 'Invalid image file. Only JPG, PNG, and GIF files under 3MB are allowed.']);
        exit;
    }

    // Save the image to the uploads directory
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($profile_image['name']);
    move_uploaded_file($profile_image['tmp_name'], $targetFile);

    // Insert user data into the database
    $query = "INSERT INTO user (names, email, passwords, profile_img) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssss", $name, $email, $password, $targetFile);

    if ($stmt->execute()) {
        // Initialize PHPMailer object
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = 0; // Disable verbose debug output
            $mail->isSMTP(); // Send using SMTP
            $mail->Host = 'mail.legendelectrical.com.ng'; // Set the SMTP server to send through
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'muhammad@legendelectrical.com.ng'; // SMTP username
            $mail->Password = 'Muhammad@12345'; // SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption
            $mail->Port = 465;
 
            //Recipients
            $mail->setFrom('muhammad@legendelectrical.com.ng', 'SKILLGEWIN');
            $mail->addAddress($email);

            // Add embedded image
            $mail->addEmbeddedImage('img/logo.jpg', 'logo_cid'); // Provide correct path to your logo
            $logo = "<img src='cid:logo_cid' alt='SKILLGEWIN Logo' style='display: block; margin: 0 auto; width: 200px;'>";

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mailContent = "$logo <br> <h1>Welcome to SKILLGEWIN</h1>
            <p>Dear $name, your account has been created successfully.</p>
            <p style='text-align: justify; font-size: 20px;'>
            Congratulations on joining SKILLGEWIN! We are thrilled to have you on board as a tutor.<br>
                           We wish you all the best in your teaching journey.<br><br>
                           Best Regards,<br> </p>
            <footer style='text-align: center; background: green; color: white;padding: 20px'>SKILLGEWIN Team</footer>
            ";
            $mail->Subject = 'Account Verification';
            $mail->Body = $mailContent;
            $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            echo '<script> 
            alert("Account Successful created")
            window.location.href = "loginUser.php"; </script>';
            // Send the email
            if ($mail->send()) {
                echo '<script> 
                alert("Account Successful created")
                window.location.href = "loginUser.php"; </script>';
                // echo json_encode(['success' => true]);
            } else {
                echo '<script> 
                alert("Account Not created") </script>';
                // echo json_encode(['success' => false, 'message' => 'Failed to send verification email.']);
            }
        } catch (Exception $e) {
            // echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
        }
    } else {
        // echo json_encode(['success' => false, 'message' => 'Failed to create account.']);
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
