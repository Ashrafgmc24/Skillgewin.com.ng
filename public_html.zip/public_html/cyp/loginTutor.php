<?php  
session_start();
$title = "Tutor -Login";
include 'include/webheader1.php';
?>

<h1 class="w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><i class="fas fa-chalkboard-teacher" ></i> Sign in As Tutor:</h1>
<section>
<div class="mycontainer" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
  <form id="loginForm" method="post" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <div class="myrow">
      <h2 style="text-align:center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">Login with Social Media or Manually</h2>
      <div class="vl">
        <span class="vl-innertext" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">or</span>
      </div>

      <div class="col">
        <a href="#" class="fb btn" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
          <i class="fab fa-facebook"></i> Login with Facebook
        </a>
        <a href="#" class="google btn" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
          <i class="fab fa-google "></i> Login with Google+
        </a>
      </div>

      <div class="col">
        <div class="hide-md-lg">
          <p>Or sign in manually:</p>
        </div>

        <input class="input" type="email" id="txtemail" name="txtemail" placeholder="Enter your email" required>
        <input class="input" type="password" id="password" name="password" placeholder="Enter your password" required>
        <input class="input" type="submit" value="Login">
      </div>
    </div>
  </form>
</div>

<div class="bottom-container">
  <div class="myrow">
    <div class="col">
      <a href="signuptutor.php" style="color:white" class="btn">Sign up</a>
    </div>
    <div class="col">
      <a href="#" style="color:white" class="btn">Forgot password?</a>
    </div>
  </div>
</div>
</section>
<hr> 

<!-- Include jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Ajax script to handle login -->
<script type="text/javascript">
  $(document).ready(function() {
    $("#loginForm").on('submit', function(event) {
      event.preventDefault(); // Prevent form submission
      
      var email = $("#txtemail").val();
      var password = $("#password").val();

      $.ajax({
        url: "ajax_login_tutor.php", // PHP script to validate login
        method: "POST",
        data: {
          txtemail: email,
          password: password
        },
        success: function(response) {
          if (response === 'success') {
           // window.location.href = "tutor-dashboard.php"; // Redirect on success
            window.location.href='tutor/dashboard.php';
          } else {
            alert(response); // Show the error
          }
        }
      });
    });
  });
</script>

<?php  
include 'include/webfooter.php';
?>
