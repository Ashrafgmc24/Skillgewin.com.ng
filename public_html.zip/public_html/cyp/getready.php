<?php session_start(); ?>
<?php  
$title = "Get Ready";
include 'include/webheader1.php';
include 'include/db_connection.php';
if(!isset($_SESSION["ready"])){
    echo "<script>
    window.location.href = 'signuptutor.php'; </script>";
    exit;
}


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

    $email = $_SESSION["email"];
    $name = $_SESSION["name"];
    
if (isset($_POST['sendEmail'])) {
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                      // Enable verbose debug output
    $mail->isSMTP();                           // Send using SMTP
    $mail->Host       = 'mail.legendelectrical.com.ng'; // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                  // Enable SMTP authentication
    $mail->Username   = 'muhammad@legendelectrical.com.ng'; // SMTP username
    $mail->Password   = 'Muhammad@12345';       // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption; `PHPMailer::ENCRYPTION_STARTTLS` also accepted
    $mail->Port       = 465;                   // TCP port to connect to

    //Recipients
    $mail->setFrom('muhammad@legendelectrical.com.ng', 'SKILLGEWIN');
    $mail->addAddress($email, $name); // Add a recipient
// Attach the logo image
 $mail->addEmbeddedImage('img/logo.jpg', 'logo_cid'); // Ensure to provide the correct path to your logo
$logo = "<img src='cid:logo_cid' alt='SKILLGEWIN Logo' style='display: block; margin: 0 auto; width: 200px;>";
    // Content
    $mail->isHTML(true);                      // Set email format to HTML
    $mail->Subject = 'Welcome to SKILLGEWIN';
    $mail->Body    = " $logo
        <h1 style='text-align: center; background: green; color: white;padding: 20px;font-size: 20px;'>SKILLGEWIN</h1>
        <h3 style='font-size: 16px'>Dear $name,</h3>
        <p style='text-align: justify; font-size: 20px;'>
    Congratulations on joining SKILLGEWIN as Tutor! We are thrilled to have you on board as a tutor.<br>
                   We wish you all the best in your teaching journey.<br><br>
                   Best Regards,<br> </p>
                    <footer style='text-align: center; background: green; color: white;padding: 20px'>SKILLGEWIN Team</footer>
    ";
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    if(!$mail->send()){
        echo "<script> alert('Message not sent') </script>";     

    }else {
        $emailL = $_SESSION["email"];
        $query = "SELECT id, names, email FROM tutor WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $emailL);
        $stmt->execute();
        $stmt->bind_result($id, $name, $email);
        $stmt->fetch();
        $stmt->close();
        $conn->close();
        
        $_SESSION['tutor_id'] = $id;

        echo "<script> alert('Thank you. $name, Message has been sent to your email Address') </script>";     
        echo "<script> window.location.href='tutor/dashboard.php' </script>";   

    }
   
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

}

?>
      <!-- <h3 class="w3-border w3-padding" style="overflow: auto;"><?php //echo htmlspecialchars($id); ?></h3> -->


<section>
<h1 class="w3-center">!Congratulation</h1>
<p><?php echo $_SESSION["name"] ?></p>
<p><?php echo $_SESSION["email"];?></p>
<p>Please wait we are preparing your Dashboard</p>
<div class="w3-center">
    <form action="" method="post">
    <button  type="submit" name="sendEmail" class="w3-btn w3-green w3-round">Go to Dashboard</button>

    </form>
    <hr>
</div>
</section>
          
<?php  
include 'include/webfooter.php';
?>
