<?php  
$title = "Market Place";
include 'include/webheader1.php';
?>

<h1 class="w3-center w3-green">Market Place</h1>
<section>
<?php
include 'include/db_connection.php';

// Fetch products from the database
$result = $conn->query("SELECT * FROM products");
?>

<div class="container mt-5">
    <h2>Today's Picks</h2>
    <div class="row">
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="col-md-4">
                <div class="card mb-4" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
                    <img src="<?php echo 'tutor/'.$row['image']; ?>" class="card-img-top" alt="Product Image">
                    <div class="card-body">
                        <h5 class="card-title">$<?php echo $row['price']; ?></h5>
                        <p class="card-text"><?php echo $row['name']; ?></p>
                        <p class="card-text"><?php echo $row['description']; ?></p>

                        <!-- Quantity Input -->
                        <form action="add_to_cart.php" method="post" class="form-inline">
                            <div class="form-group">
                                <label for="quantity">Quantity:</label>
                                <input type="number" class="form-control mx-2" name="quantity" min="1" value="1" required>
                            </div>
                            
                            <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                            
                            <!-- View Details Button -->
                            <a href="product-details.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">View Details</a>
                            
                            <!-- Add to Cart Button -->
                            <button type="submit" class="btn btn-secondary">Add to Cart</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<?php
$conn->close();
?>
</section>

<?php  
include 'include/webfooter.php';
?>
