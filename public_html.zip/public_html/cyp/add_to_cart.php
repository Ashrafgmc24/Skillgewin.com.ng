<?php
session_start();
include 'include/db_connection.php';

// Check if product_id and quantity are set
if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Fetch the product from the database
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
        $product_name = $product['name'];
        $product_price = $product['price'];
        $product_image = $product['image'];

        // Check if the cart session exists, if not, create one
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Add the product to the cart session (or update if already exists)
        if (isset($_SESSION['cart'][$product_id])) {
            // Update the quantity if the product is already in the cart
            $_SESSION['cart'][$product_id]['quantity'] += $quantity;
        } else {
            // Add a new product to the cart
            $_SESSION['cart'][$product_id] = [
                'name' => $product_name,
                'price' => $product_price,
                'quantity' => $quantity,
                'image' => $product_image
            ];
        }

        // Redirect back to the market place or to the cart page
        header("Location: cart.php");
    } else {
        echo "Product not found.";
    }
} else {
    echo "Invalid request.";
}
?>
