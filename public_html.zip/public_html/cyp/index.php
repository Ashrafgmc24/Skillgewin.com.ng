<?php  
session_start();
$title ="Home - SKILLGEWIN";
include "include/webheader1.php"; // Header file
include "include/db_connection.php"; // Database connection

$page = "index.php";
include "include/mysearch.php"; // Search functionality

?>
<section class="w3-container">
<div class="w3-row" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <div class="w3-half w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <button class="w3-btn w3-green w3-round-xlarge w3-hover w3-margin-top" onclick="usertutor()">
            <i class="fas fa-chalkboard-teacher"></i> Tutor Jobs
        </button>
    </div>
    <div class="w3-half w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <button class="w3-btn w3-green w3-round-xlarge w3-hover w3-margin-top" onclick="userpage()">
            <i class="fa fa-user"></i> Create Account
        </button>
    </div>
</div>
<script>
function userpage() {
    window.location.href = "signupuser.php";
}
function usertutor() {
    window.location.href = "signuptutor.php";
}
function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    document.getElementById(cityName).style.display = "block";
}
</script>

<!-- Tutor Cards Section -->
<div class="container my-5">
    <h2 class="text-center mb-4" data-aos="fade-up" data-aos-delay="200">Learn and grow with help from world-class tutors <i class="fas fa-star" style="color: #f39c12;"></i></h2>
    <div class="row" id="tutor-results">
        <!-- Fetch Tutor Data -->
        <?php
        $select = "SELECT * FROM tutor";
        $result = $conn->query($select);

        if (!$result) {
            // Output error if query fails
            die("Query Error: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Calculate the number of stars to display
                // $full_stars = floor($row['rating']);
                // $empty_stars = 5 - $full_stars;
        ?>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
            <div class="card">
                <img src="uploads/<?php echo $row['profile_img']; ?>" alt="Tutor Image" class="card-img-top">
                <i class="fas fa-heart favorite-icon"></i>
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($row['names']); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($row['locations']); ?></p>
                    <p class="card-text"><?php echo htmlspecialchars($row['webcam_face']); ?></p>
                    <div class="star-rating mb-2">
                        <?php 
                        // Display full stars
                        // for ($i = 0; $i < $full_stars; $i++) {
                        //     echo '<i class="fas fa-star"></i>';
                       // }
                        // Display empty stars
                        // for ($i = 0; $i < $empty_stars; $i++) {
                        //     echo '<i class="far fa-star"></i>';
                       // } 
                        ?>
                        <span>(<?php echo $row['reviews']; ?> reviews)</span>
                    </div>
                    <p class="card-text"><?php echo htmlspecialchars($row['experience']); ?></p>
                    <p class="price">₦<?php echo number_format($row['hourly_rate'], 2); ?> <span class="first-lesson">- 1st lesson free</span></p>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
            echo "<p class='text-center'>No tutors found.</p>";
        }
        ?>
    </div>
</div>

<section class="container my-5 w3-white">
    <h6 class="w3-center" data-aos="fade-up" data-aos-delay="200"><span class="w3-gray w3-round w3-padding w3-text-white">Workflow</span></h6>
    <div class="text-center mb-5">
        <h2 data-aos="fade-up" data-aos-delay="200">Look at a glance how our system works</h2>
    </div>
    <div class="row text-center">
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="step-card shadow-sm">
                <i class="fas fa-user-plus icon-circle"></i>
                <h4 class="mt-3">Create Account</h4>
                <p>It's very easy to open an account and start your mentorship journey.</p>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="step-card shadow-sm">
                <i class="fas fa-user-check icon-circle"></i>
                <h4 class="mt-3">Complete your profile</h4>
                <p>Complete your profile with all the info to get attention from mentees.</p>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
            <div class="step-card shadow-sm">
                <i class="fas fa-search icon-circle"></i>
                <h4 class="mt-3">Connect with Tutor</h4>
                <p>Explore our growing catalogue of tutors until you find the perfect fit.</p>
            </div>
        </div>
    </div>
</section>

<section class="container my-5">
        <h6 class="w3-center" data-aos="fade-up" data-aos-delay="200"><span class="w3-gray w3-round w3-padding w3-text-white">Categories</span></h6>

    <div class="text-center mb-5">
        <h2 data-aos="fade-up" data-aos-delay="200">Browse Tutors by Categories</h2>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="card2 shadow-sm">
                <i class="fas fa-book-open icon-circle2"></i>
                <h4 class="mt-3">Academics</h4>
                <p>0 Tutors</p>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="card2 shadow-sm">
                <i class="fas fa-cogs icon-circle2"></i>
                <h4 class="mt-3">Skill Acquisition</h4>
                <p>0 Tutors</p>
            </div>
        </div>
    </div>
</section>

   
<div class="container text-center mt-5">
    <h2 data-aos="fade-up">Learn that new skill, launch that project, land your dream career.</h2>
    <div class="row mt-5">
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-user-plus fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Profile Creation</h5>
                    <p class="card-text">Users can create detailed profiles highlighting their professional background, skills, and areas of expertise. This helps facilitate mentor-mentee matches.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-search fa-3x text-primary"></i>
                    <h5 class="card-title mt-3">Search and Filter</h5>
                    <p class="card-text">Users can search for mentors based on criteria such as location, language, availability, and more. Advanced filters help narrow down search results.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-left">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-comments fa-3x text-info"></i>
                    <h5 class="card-title mt-3">Messaging System</h5>
                    <p class="card-text">Built-in messaging system enables mentees to communicate with mentors before initiating a mentoring relationship, fostering communication and connection.</p>
                </div>
            </div>
        </div>
        <!---->
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-video fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Video Sessions</h5>
                    <p class="card-text">The platform offers video conferencing capabilities, allowing mentees and mentors to schedule and conduct mentoring sessions remotely. This feature provides flexibility and convenience for users regardless of their location.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-users fa-3x text-primary"></i>
                    <h5 class="card-title mt-3">Feedback and Ratings</h5>
                    <p class="card-text">After each mentoring session, both mentees and mentors can provide feedback and ratings based on their experience. This feature helps maintain the quality of mentoring relationships and allows users to continuously improve.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-left">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-credit-card fa-3x text-info"></i>
                    <h5 class="card-title mt-3">Payment Integration</h5>
                    <p class="card-text">Supports various payment gateways for secure online payments, 
                    allowing users to pay for bookings seamlessly.</p>
                </div>
            </div>
        </div>
        <!---->
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-file fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Reports</h5>
                    <p class="card-text">Generates detailed reports, helping your businesses gain insights into most booked sessions,
                    mentees, countries & profits. These insights aid in informed decision-making.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                 
                    <i class="fa fa-lock fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Privacy and Security</h5>
                    <p class="card-text">We’re committed to keeping your data secure. We uses end-to-end encryption to
                    protect your sensitive financial information. 
                    Nobody gets a hand on your important data, not even us.</p>
                </div>
            </div>
        </div>
        
    </div>
</div>

<?php include "include/webfooter.php"; ?> <!-- Footer file -->
