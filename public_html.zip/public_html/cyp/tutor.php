<?php  
$title = "Home Page";
include 'include/webheader1.php';
include "include/db_connection.php";
$page = "tutor.php";

include "include/mysearch.php";
?>

<h1 class="w3-center">Search Tutor</h1>
<section>

</section>
      

<div class="container my-5">
<div class="row" id="tutor-results">

</div>
    <!-- Tutor search results will be displayed here -->
</div>

</div>    
<?php  
include 'include/webfooter.php';
?>
