<?php  
$title = "FAQs -SKILLGEWIN";
include 'include/webheader1.php';
include 'include/mysearch.php'; 

?>

<h1 class="w3-center" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="500">Frequently Asked Questions</h1>
<section class="w3-padding">
<p onclick="myFunctionaco('Demo1')" class="w3-btn w3-block w3-green w3-left-align w3-round" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="500">
How does the free trial work?
</p>
<div id="Demo1" class="w3-container w3-hide w3-white w3-border w3-animate-zoom w3-round" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="500">
  
  <p>Our 3 day trial is 100% free and does not require any credit card information to start. If at the end of your trial you would like to upgrade, great. If not, your plan will automatically be downgraded to the free plan. </p>
</div>

<p onclick="myFunctionaco('Demo2')" class="w3-btn w3-block w3-green w3-left-align w3-round" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="500">
Do I need to choose a plan now?
</p>
<div id="Demo2" class="w3-container w3-hide w3-white w3-border w3-animate-zoom w3-round" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="500">
    <p>No. You get the full featured, unlimited version of our service completely free for 14 days. Once you're ready to upgrade, you may choose a plan which suits your needs. </p>
</div>

<p onclick="myFunctionaco('Demo3')" class="w3-btn w3-block w3-green w3-left-align w3-round" data-aos="zoom-in" data-aos-duration="1000" data-aos-delay="500">Can I get a demo of the product?</p>
<div id="Demo3" class="w3-container w3-hide w3-white w3-border w3-animate-zoom w3-round">
  
  <p>Sure We are currently running live demos a week. You can sign up and register for our next one here. </p>
</div>
</section>


<script>
function myFunctionaco(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}

</script>
<hr>
<?php  
include 'include/webfooter.php';
?>
