<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: loginUser.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .dashboard-container {
            margin-left: 200px; /* Space for sidenav */
            padding: 16px;
        }

        .w3-sidebar {
            width: 200px;
        }

        @media screen and (max-width: 768px) {
            .w3-sidebar {
                width: 100%; /* Full width on smaller screens */
                display: block;
            }

            .dashboard-container {
                margin-left: 0; /* No left margin for smaller screens */
            }
        }
    </style>
</head>
<body>

<!-- Sidebar (sidenav) -->
<div class="w3-sidebar w3-bar-block w3-dark-grey w3-collapse w3-large" id="mySidebar">
    <h3 class="w3-bar-item w3-center"><i class="fa fa-user"></i> <?php echo $_SESSION['user_name']; ?></h3>
    <a href="#" class="w3-bar-item w3-button"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="#" class="w3-bar-item w3-button"><i class="fas fa-user-circle"></i> Profile</a>
    <a href="#" class="w3-bar-item w3-button"><i class="fas fa-envelope"></i> Messages</a>
    <a href="#" class="w3-bar-item w3-button"><i class="fas fa-cog"></i> Settings</a>
    <a href="logoutuser.php" class="w3-bar-item w3-button w3-red"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main content area -->
<div class="dashboard-container w3-light-grey">
    <header class="w3-container w3-teal">
        <h4>Welcome to your Dashboard, <?php echo $_SESSION['user_name']; ?>!</h4>
    </header>

    <div class="w3-container">
        <h2>Dashboard Content</h2>
        <p>Here is where your main content will go.</p>

        <!-- Example cards -->
        <div class="w3-row-padding">
            <div class="w3-third w3-margin-bottom">
                <div class="w3-card w3-padding w3-white">
                    <h3><i class="fas fa-chart-line"></i> Performance</h3>
                    <p>Track your performance.</p>
                </div>
            </div>
            <div class="w3-third w3-margin-bottom">
                <div class="w3-card w3-padding w3-white">
                    <h3><i class="fas fa-user-friends"></i> Users</h3>
                    <p>Manage users on the platform.</p>
                </div>
            </div>
            <div class="w3-third w3-margin-bottom">
                <div class="w3-card w3-padding w3-white">
                    <h3><i class="fas fa-cogs"></i> Settings</h3>
                    <p>Customize your experience.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add a script for responsive sidebar -->
<script>
    // Toggle sidebar on small screens
    function toggleSidebar() {
        var sidebar = document.getElementById("mySidebar");
        if (sidebar.classList.contains("w3-show")) {
            sidebar.classList.remove("w3-show");
        } else {
            sidebar.classList.add("w3-show");
        }
    }
</script>

</body>
</html>
