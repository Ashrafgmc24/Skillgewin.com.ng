<?php  
session_start();
$title = "User - Create Account";
include 'include/webheader1.php';
include 'process_signup.php';

?>

<h1 class="w3-center"><i class="fa fa-user"></i> Create Account</h1>
<section>
<div class="mycontainer">
  <form id="signupForm" action="" method="post" enctype="multipart/form-data">
    <div class="myrow">
      <h2 style="text-align:center">Sign up with Social Media or Manually</h2>
      <div class="vl">
        <span class="vl-innertext">or</span>
      </div>

      <div class="col">
        <a href="#" class="fb btn">
          <i class="fab fa-facebook-f"></i> Sign up with Facebook
        </a>
        <a href="#" class="google btn">
          <i class="fab fa-google"></i> Sign up with Google
        </a>
      </div>

      <div class="col">
        <div class="hide-md-lg">
          <p>Or sign in manually:</p>
        </div>

        <input class="input" type="text" name="txtname" id="txtname" placeholder="Enter your name" required>
        <input class="input" type="email" name="txtemail" id="txtemail" placeholder="Enter your email" required>
        <input class="input" type="password" name="password" id="password" placeholder="Enter your password" required>
        
        <p>Profile Image (less than 3MB)</p>
        <input type="file" name="profile_image" id="profile_image" accept="image/*" required>
        
        <p>Preview Image</p>
        <img id="imagePreview" src="#" alt="Image Preview" style="display:none; width:100px; height:100px;">

        <input class="input" type="submit" value="Create Account">
      </div>
    </div>
  </form>
</div>

<div class="bottom-container">
  <div class="myrow">
    <div class="col">
      <p class="w3-text-white">Already have an account?</p>
    </div>
    <div class="col">
      <a href="loginUser.php" style="color:white" class="btn"><i class="fa fa-lock"></i> Login</a>
    </div>
  </div>
</div>
</section>
<hr>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
  // Image Preview Function
  $("#profile_image").change(function() {
    let reader = new FileReader();
    reader.onload = function(e) {
      $('#imagePreview').attr('src', e.target.result).show();
    }
    reader.readAsDataURL(this.files[0]);
  });

  // $('#signupForm').on('submit', function(event) {
  //   event.preventDefault(); // Stop the form from submitting the old-fashioned way

    // var formData = new FormData(this); // Package up that form data

    // $.ajax({
    //     url: 'process_signup.php', // PHP script to handle the magic
    //     type: 'POST',
    //     data: formData,
    //     contentType: false,
    //     processData: false,
    //     success: function(response) {
    //         try {
    //             var res = JSON.parse(response);
    //             if (res.success) {
    //                 alert('Account created successfully! A welcoming message sent to your email. 🚀');
    //                 window.location.href = "loginUser.php"; // Off to the login page!
    //             } else {
    //                 alert('Error: ' + res.message); // Uh-oh, something went wrong
    //             }
    //         } catch (e) {
    //             alert('Oopsie daisy! Something went wonky with the response.');
    //             console.error('JSON parse error:', e);
    //         }
    //     },
    //     error: function(jqXHR, textStatus, errorThrown) {
    //         console.log(textStatus, errorThrown); // Log any Ajax errors
    //         alert('An error occurred while submitting the form. 😖');
    //     }
    // });
// });
</script>

<?php  
include 'include/webfooter.php';
?>
