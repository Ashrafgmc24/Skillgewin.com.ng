<?php  
session_start();
$title = "User -Login";
include 'include/webheader1.php'; 
?>

<h1 class="w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><i class="fa fa-user"></i> Sign in As User:</h1>
<section>
<div class="mycontainer" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
  <form id="loginForm" method="post" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <div class="myrow" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
      <!--<h2 style="text-align:center">Login with Social Media or Manually</h2>-->
      <div class="vl">
        <!--<span class="vl-innertext">or</span>-->
      </div>

      <div class="col w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <!--<a href="#" class="w3-margin" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">-->
        <!--  <i class="fab fa-facebook fa-3x"></i>-->
        <!--</a>-->
        
        <!--<a href="#" class="w3-margin" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">-->
        <!--  <i class="fab fa-google fa-3x"></i>-->
        <!--</a>-->
      </div>

      <div class="col">
        <div class="hide-md-lg " style="margin-top: 10px">
            <br>
          <p>Or sign in manually:</p>
        </div>

        <input class="input" type="email" id="email" name="txtemail" placeholder="Enter your email" required>
        <input class="input" type="password" id="password" name="password" placeholder="Enter your password" required>
        <input class="input" type="submit" value="Login">
      </div>
    </div>
    <div id="statusMessage" style="text-align:center; color:green; margin-top:20px;"></div> <!-- For displaying status -->
  </form>
</div>

<div class="bottom-container">
  <div class="myrow">
    <div class="col">
      <a href="signupuser.php" style="color:white" class="btn">Sign up</a>
    </div>
    <div class="col">
      <a href="forgot_password.php" style="color:white" class="btn">Forgot password?</a>
    </div>
  </div>
</div>
</section>
<hr>

<section class="container my-5 w3-white">
    <h6 class="w3-center" data-aos="fade-up" data-aos-delay="200"><span class="w3-gray w3-round w3-padding w3-text-white">Workflow</span></h6>
    <div class="text-center mb-5">
        <h2 data-aos="fade-up" data-aos-delay="200">Look at a glance how our system works</h2>
    </div>
    <div class="row text-center">
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="step-card shadow-sm">
                <i class="fas fa-user-plus icon-circle"></i>
                <h4 class="mt-3">Create Account</h4>
                <p>It's very easy to open an account and start your mentorship journey.</p>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div class="step-card shadow-sm">
                <i class="fas fa-user-check icon-circle"></i>
                <h4 class="mt-3">Complete your profile</h4>
                <p>Complete your profile with all the info to get attention from mentees.</p>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
            <div class="step-card shadow-sm">
                <i class="fas fa-search icon-circle"></i>
                <h4 class="mt-3">Connect with Tutor</h4>
                <p>Explore our growing catalogue of tutors until you find the perfect fit.</p>
            </div>
        </div>
    </div>
</section>

   
<div class="container text-center mt-5">
    <h2 data-aos="fade-up">Learn that new skill, launch that project, land your dream career.</h2>
    <div class="row mt-5">
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-user-plus fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Profile Creation</h5>
                    <p class="card-text">Users can create detailed profiles highlighting their professional background, skills, and areas of expertise. This helps facilitate mentor-mentee matches.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-search fa-3x text-primary"></i>
                    <h5 class="card-title mt-3">Search and Filter</h5>
                    <p class="card-text">Users can search for mentors based on criteria such as location, language, availability, and more. Advanced filters help narrow down search results.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-left">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-comments fa-3x text-info"></i>
                    <h5 class="card-title mt-3">Messaging System</h5>
                    <p class="card-text">Built-in messaging system enables mentees to communicate with mentors before initiating a mentoring relationship, fostering communication and connection.</p>
                </div>
            </div>
        </div>
        <!---->
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-video fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Video Sessions</h5>
                    <p class="card-text">The platform offers video conferencing capabilities, allowing mentees and mentors to schedule and conduct mentoring sessions remotely. This feature provides flexibility and convenience for users regardless of their location.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-up">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-users fa-3x text-primary"></i>
                    <h5 class="card-title mt-3">Feedback and Ratings</h5>
                    <p class="card-text">After each mentoring session, both mentees and mentors can provide feedback and ratings based on their experience. This feature helps maintain the quality of mentoring relationships and allows users to continuously improve.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-left">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-credit-card fa-3x text-info"></i>
                    <h5 class="card-title mt-3">Payment Integration</h5>
                    <p class="card-text">Supports various payment gateways for secure online payments, 
                    allowing users to pay for bookings seamlessly.</p>
                </div>
            </div>
        </div>
        <!---->
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                    <i class="fas fa-file fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Reports</h5>
                    <p class="card-text">Generates detailed reports, helping your businesses gain insights into most booked sessions,
                    mentees, countries & profits. These insights aid in informed decision-making.</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4" data-aos="fade-right">
            <div class="card p-4">
                <div class="card-body">
                 
                    <i class="fa fa-lock fa-3x text-success"></i>
                    <h5 class="card-title mt-3">Privacy and Security</h5>
                    <p class="card-text">We’re committed to keeping your data secure. We uses end-to-end encryption to
                    protect your sensitive financial information. 
                    Nobody gets a hand on your important data, not even us.</p>
                </div>
            </div>
        </div>
        
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    // When the login form is submitted
    $('#loginForm').on('submit', function(e){
        e.preventDefault(); // Prevent the form from submitting normally

        // Show processing message
        $('#statusMessage').html('Login is processing...');

        // Get form data
        var email = $('#email').val();
        var password = $('#password').val();

        // Send data to loginProcess.php via AJAX
        $.ajax({
            url: 'user_login_script.php',
            type: 'POST',
            data: {
                txtemail: email,
                password: password
            },
            success: function(response) {
                // Parse JSON response
                var data = JSON.parse(response);

                if (data.success) {
                    // Redirect to dashboard if login is successful
                    window.location.href = 'dashboard.php';
                } else {
                    // Display error message
                    $('#statusMessage').html(data.message).css('color', 'red');
                }
            },
            error: function() {
                // Handle error
                $('#statusMessage').html('Error occurred while processing login.').css('color', 'red');
            }
        });
    });
});
</script>

<?php  
include 'include/webfooter.php';
?>
