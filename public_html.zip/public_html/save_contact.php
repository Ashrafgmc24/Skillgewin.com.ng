<?php
session_start();
include "include/db_connection.php";

 // Load PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id']; // The ID of the logged-in user
    $tutorId = $_POST['id'];

    // Insert contact details into the database
    $sql = "INSERT INTO contact_tutor (user_id, tutor_id) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $userId, $tutorId);
    
    if ($stmt->execute()) {
        // Fetch the tutor's details (email, name)
        $tutorQuery = "SELECT email, names FROM tutor WHERE id = ?";
        $tutorStmt = $conn->prepare($tutorQuery);
        $tutorStmt->bind_param("i", $tutorId);
        $tutorStmt->execute();
        $tutorResult = $tutorStmt->get_result();
        $tutor = $tutorResult->fetch_assoc();
        
        $tutorEmail = $tutor['email'];
        $tutorName = $tutor['names'];
        
        // Get the user's name and image
        $userName = $_SESSION['user_name'];
        $userImage = $_SESSION['profile_img']; // Assuming user's profile image is stored in session

        // Send an email to the tutor
        $mail->SMTPDebug = 0;                      // Enable verbose debug output
        $mail->isSMTP();                           // Send using SMTP
        $mail->Host       = 'mail.skillgewin.com'; // Set the SMTP server to send through
        $mail->SMTPAuth   = true;                  // Enable SMTP authentication
        $mail->Username   = 'noreply@skillgewin.com'; // SMTP username
        $mail->Password   = '@Noreply12345#';       // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Enable SSL encryption; `PHPMailer::ENCRYPTION_STARTTLS` also accepted
        $mail->Port       = 465;    

        $mail->setFrom('noreply@skillgewin.com', 'SKILLGEWIN');
        $mail->addAddress($tutorEmail); // Tutor's email
        $mail->isHTML(true);

        $mail->Subject = 'New Contact Request';
        $mail->Body    = "
            <h3>You have a new contact request from $userName</h3>
            <p><img src='https://skillgewin.com/uploads/$userImage' alt='User Image' width='100'></p>
            <p>Message: A student is interested in contacting you. Please log in to your account for further details.</p>
        ";

        if ($mail->send()) {
            echo "success";
        } else {
            echo "error";
        }
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}
?>
