<?php
session_start();
include "include/db_connection.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: loginUser.php");
    exit(); 
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $names = $_POST['names'];
    $email = $_POST['email'];
    
    // Handle profile image upload
    if (!empty($_FILES['profile_img']['name'])) {
        $profile_img = $_FILES['profile_img']['name'];
        $target_dir = "uploads/";
        $target_file = basename("uploads/".$profile_img);
        move_uploaded_file($_FILES['profile_img']['tmp_name'], $target_file);
        
        // Update query with profile image
        $sql = "UPDATE user SET names = ?, email = ?, profile_img = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $names, $email, $profile_img, $user_id);
    } else {
        // Update query without changing profile image
        $sql = "UPDATE user SET names = ?, email = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $names, $email, $user_id);
    }

    if ($stmt->execute()) {
        // Redirect back to profile page after updating
        header("Location: profile.php");
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
