<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: loginUser.php");
    exit();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);

include "include/db_connection.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tutor_id = isset($_POST['tutor_id']) ? intval($_POST['tutor_id']) : 0;
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session

    if ($tutor_id && $user_id) {
        // Check if the user has already contacted the tutor
        $stmt = $conn->prepare("SELECT id FROM contact_tutor WHERE user_id = ? AND tutor_id = ?");
        $stmt->bind_param("ii", $user_id, $tutor_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Tutor has already been contacted, send a reminder email
            // Fetch tutor details
            $stmt = $conn->prepare("SELECT email, names FROM tutor WHERE id = ?");
            $stmt->bind_param("i", $tutor_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $tutor = $result->fetch_assoc();

            // Fetch user details
            $stmt = $conn->prepare("SELECT email, names FROM user WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();

            // Send reminder email to the tutor
            $mail = new PHPMailer(true);

            try {
                // Server settings
                $mail->SMTPDebug = 0;
                $mail->isSMTP();
                $mail->Host       = 'mail.skillgewin.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'noreply@skillgewin.com';
                $mail->Password   = '@Noreply12345#';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                $mail->Port       = 465;

                // Recipients
                $mail->setFrom('noreply@skillgewin.com', 'SKILLGEWIN');
                $mail->addAddress($tutor['email']); // Tutor's email

                // Attach the logo image
                $mail->addEmbeddedImage('img/logo.jpg', 'logo_cid');
                $logo = "<img src='cid:logo_cid' alt='SKILLGEWIN' style='display: block; margin: 0 auto; width: 200px;'>";

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Reminder: Contact from SKILLGEWIN';
                $mail->Body    = $logo . 
                    '<h1 style="text-align: center; background: green; color: white;padding: 20px;font-size: 20px;">SKILLGEWIN</h1>' .
                    '<br> Dear ' . $tutor['names'] . ',<br>' .
                    '<p style="text-align: justify; font-size: 30px;">' .
                    'This is a reminder that <b>' . $user['names'] . '</b><b> (' . $user['email'] . ')</b> has already contacted you.<br>' .
                    'Please login into your dashboard to review their contact request.<br>' .
                    'Best Regards. <a href="http://skillgewin.com/loginTutor.php">Veiw Web </a> </p> ' .
                    '<footer style="text-align: center; background: green; color: white;padding: 20px">SKILLGEWIN Team</footer>';
                $mail->AltBody = 'Reminder: Contact from SKILLGEWIN user.';

                if ($mail->send()) {
                    echo '<script>alert("You have already contacted this tutor. A reminder email has been sent.");</script>';
                    echo "<script> window.location.href='mytutor.php' </script>";
                } else {
                    echo 'Error sending email: ' . $mail->ErrorInfo;
                }
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            // User hasn't contacted this tutor yet, insert into contact_tutor table
            $stmt = $conn->prepare("INSERT INTO contact_tutor (user_id, tutor_id, contact_time) VALUES (?, ?, NOW())");
            $stmt->bind_param("ii", $user_id, $tutor_id);
            if ($stmt->execute()) {
                // Fetch tutor and user details again to send the email
                $stmt = $conn->prepare("SELECT email, names FROM tutor WHERE id = ?");
                $stmt->bind_param("i", $tutor_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $tutor = $result->fetch_assoc();

                $stmt = $conn->prepare("SELECT email, names FROM user WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();

                // Send new contact email to the tutor
                $mail = new PHPMailer(true);

                try {
                    // Server settings
                    $mail->SMTPDebug = 0;
                    $mail->isSMTP();
                    $mail->Host       = 'mail.skillgewin.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'noreply@skillgewin.com';
                    $mail->Password   = '@Noreply12345#';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port       = 465;

                    // Recipients
                    $mail->setFrom('noreply@skillgewin.com', 'SKILLGEWIN');
                    $mail->addAddress($tutor['email']);

                    // Attach the logo image
                    $mail->addEmbeddedImage('img/logo.jpg', 'logo_cid');
                    $logo = "<img src='cid:logo_cid' alt='SKILLGEWIN' style='display: block; margin: 0 auto; width: 200px;'>";

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'New Contact from SKILLGEWIN';
                    $mail->Body    = $logo .
                        '<h1 style="text-align: center; background: green; color: white;padding: 20px;font-size: 20px;">SKILLGEWIN</h1>' .
                        '<br> Dear ' . $tutor['names'] . ',<br>' .
                        '<p style="text-align: justify; font-size: 30px;">' .
                        'You have received a new contact request from <b>' . $user['names'] . ' </b>(' . $user['email'] . ').<br>' .
                        'Please login into your dashboard to review the request.<br>' .
                        'Best Regards.</p>' .
                        '<footer style="text-align: center; background: green; color: white;padding: 20px">SKILLGEWIN Team</footer>';
                    $mail->AltBody = 'New contact from SKILLGEWIN user.';

                    if ($mail->send()) {
                       // echo '<script>alert("Tutor contacted successfully.");</script>';
                        echo "<script> window.location.href='mytutor.php' </script>";
                    } else {
                        echo 'Error sending email: ' . $mail->ErrorInfo;
                    }
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
            } else {
                echo 'Error saving contact record.';
            }
        }
    } else {
        echo 'Invalid request.';
    }
}
?>
