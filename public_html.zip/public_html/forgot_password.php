<?php  
session_start();
$title = "Forgot Password";
include 'include/webheader1.php'; 
?>

<h1 class="w3-center" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"><i class="fa fa-lock"></i> Forgot Password:</h1>
<section>
<div class="mycontainer" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
  <form id="forgotPasswordForm" method="post" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <div class="myrow" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
      <div class="col">
        <p>Enter your email address to reset your password:</p>
        <input class="input" type="email" id="email" name="txtemail" placeholder="Enter your email" required>
        <input class="input" type="submit" value="Send Reset Link">
      </div>
    </div>
    <div id="statusMessage" style="text-align:center; color:green; margin-top:20px;"></div> <!-- For displaying status -->
  </form>
</div>
</section>

<script>
$(document).ready(function(){
    $('#forgotPasswordForm').on('submit', function(e){
        e.preventDefault(); // Prevent normal form submission

        // Show processing message
        $('#statusMessage').html('Processing request...');

        // Get form data
        var email = $('#email').val();

        // Send email to process the reset link
        $.ajax({
            url: 'send_reset_link.php',
            type: 'POST',
            data: { txtemail: email },
            success: function(response) {
                var data = JSON.parse(response);

                if (data.success) {
                    $('#statusMessage').html(data.message).css('color', 'green');
                    //window.location.href='reset_password.php'
                } else {
                    $('#statusMessage').html(data.message).css('color', 'red');
                }
            },
            error: function() {
                $('#statusMessage').html('Error occurred while sending reset link.').css('color', 'red');
            }
        });
    });
});
</script>

<?php  
include 'include/webfooter.php'; 
?>
