<div class="subject-slider">
    <button class="slider-btn left">&#8249;</button> <!-- Left arrow -->
    <div class="subjects-container">
        <div class="subject">
        <i class="fa fa-square-root"></i>
            <span>Maths</span>
        </div>
        <div class="subject">
            <img src="path-to-dance-icon.svg" alt="Dance" />
            <span>Dance</span>
        </div>
        <div class="subject">
            <img src="path-to-physics-icon.svg" alt="Physics" />
            <span>Physics</span>
        </div>
        <div class="subject">
            <img src="path-to-hindi-icon.svg" alt="Hindi" />
            <span>Hindi</span>
        </div>
        <div class="subject">
            <img src="path-to-python-icon.svg" alt="Python" />
            <span>Python</span>
        </div>
        <div class="subject">
            <img src="path-to-ielts-icon.svg" alt="IELTS" />
            <span>IELTS</span>
        </div>
        <div class="subject">
            <img src="path-to-academic-icon.svg" alt="Academic tutoring" />
            <span>Academic tutoring</span>
        </div>
        <div class="subject">
            <img src="path-to-accounting-icon.svg" alt="Accounting" />
            <span>Accounting</span>
        </div>
    </div>
    <button class="slider-btn right">&#8250;</button> <!-- Right arrow -->
</div>

<script>
// Get elements
const leftBtn = document.querySelector('.slider-btn.left');
const rightBtn = document.querySelector('.slider-btn.right');
const subjectsContainer = document.querySelector('.subjects-container');

// Define the scroll amount (you can adjust this value)
const scrollAmount = 300;

// Scroll to the right when the right button is clicked
rightBtn.addEventListener('click', () => {
    subjectsContainer.scrollBy({
        left: scrollAmount,
        behavior: 'smooth'
    });
});

// Scroll to the left when the left button is clicked
leftBtn.addEventListener('click', () => {
    subjectsContainer.scrollBy({
        left: -scrollAmount,
        behavior: 'smooth'
    });
});

</script>