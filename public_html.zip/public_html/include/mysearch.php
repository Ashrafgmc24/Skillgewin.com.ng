<!-- <form action="" method="get" class="w3-center w3-border w3-round-xxlarge w3-bar form w3-white"> -->
<!-- <span><i class="fa fa-search"></i></span> -->
<!-- <input type="text" name="search" class="srch" placeholder="Search" style="border: none;"> -->
<!-- <button class="w3-btn w3-green w3-round-large"><i class="fa fa-search"></i></button> -->
<!-- </form> -->
<!-- <div style="display: flex; justify-content: space-between;">
<p></p>
<div class="w3-bar w3-light-grey w3-center w3-round-xlarge" style="width: 80%">
  <a class="w3-bar-item w3-button">Home</a>
  
  <input type="text" class="w3-bar-item w3-input" placeholder="Search..">
  <a href="#" class="w3-bar-item w3-button w3-green respons">Go</a>
</div> 

</div> --> 

<!--data-aos-duration="1000" data-aos-delay="500"-->
<div class="container my-5" style="background:lightgreen;" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    
    <!--<div class="container mt-5">-->
    <!--<form action="tutor.php" method="GET">-->
    <!--    <div class="input-group">-->
            <!-- Search field -->
    <!--        <span class="input-group-text"><i class="fa fa-search"></i></span>-->
    <!--        <input type="text" name="search_term" class="form-control" placeholder="Search by tutor, skill, or role" aria-label="Search">-->
            
            <!-- Skill Acquisition Dropdown -->
    <!--        <select class="form-select" name="skill">-->
    <!--            <option value="">Skill Acquisition</option>-->
    <!--            <option value="Programming">Programming</option>-->
    <!--            <option value="Design">Design</option>-->
    <!--            <option value="Marketing">Marketing</option>-->
                <!-- Add more skills here -->
    <!--        </select>-->
            
            <!-- Country Dropdown -->
    <!--        <select class="form-select" name="country">-->
    <!--            <option value="">Country</option>-->
    <!--            <option value="USA">USA</option>-->
    <!--            <option value="Nigeria">Nigeria</option>-->
    <!--            <option value="Canada">Canada</option>-->
                <!-- Add more countries here -->
    <!--        </select>-->

            <!-- Search Button -->
    <!--        <button class="btn btn-success" type="submit">SEARCH</button>-->
    <!--    </div>-->
    <!--</form>-->
<!--</div>-->

<!-- Add Bootstrap and Font Awesome -->

    
    
    <!-- Search Bar -->
    <div class="search-bar">
         <i class="fas fa-search"></i> 
        <form action="tutor.php" method="post" class="form my-form">
        <input type="text" class="search-input w3-round" id="searchQuery" style="border: none; width: 100%" placeholder="Enter subject, e.g. 'Padel'" name="search">
        <button class="find-tutor-btn w3-green" name="query" style="width: 50px;text-align: center;padding:0px;"><i class="fa fa-search"></i></button>
        </form>
        
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#searchQuery').on('inputt', function() {
        var query = $(this).val();
        
        if (query.length > 2) { // Start searching after 3 characters
            $.ajax({
                url: 'searchTutor.php',
                method: 'POST',
                data: {query: query},
                success: function(response) {
                    $('#tutor-results').html(response);
                }
            });
        } else {
            $('#tutor-results').html(''); // Clear if less than 3 characters
        }
    });
});

</script>

    <!-- Subject List with Arrows -->
    <div class="subject-container">
        <i class="fas fa-chevron-left arrow" onclick="scrollPrev()"></i>
        <div class="subject-list" id="subjectList">
             <div class="subject-item" onclick="triggerSearch('Coding')">
                <i class="fas fa-book"></i>
                <p class="sub-sm">Coding</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Diction')">
                <i class="fas fa-book"></i>
                <p class="sub-sm">Diction</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Literature in English')">
                <i class="fas fa-font"></i>
                <p class="sub-sm">Literature in English</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('History')">
                <i class="fas fa-book-open"></i>
                <p class="sub-sm">History</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Microsoft Word')">
                <i class="fas fa-laptop"></i>
                <p class="sub-sm">Microsoft Word</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Commerce')">
                <i class="fas fa-briefcase"></i>
                <p class="sub-sm">Commerce</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('English')">
                <i class="fas fa-language"></i>
                <p class="sub-sm">English</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Cooking')">
                <i class="fas fa-language"></i>
                <p class="sub-sm">Cooking</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Saloon')">
                <i class="fas fa-language"></i>
                <p class="sub-sm">Saloon</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Shoe Making')">
    <i class="fas fa-language"></i>
    <p class="sub-sm">Shoe Making</p>
</div>


            <div class="subject-item" onclick="triggerSearch('Tailoring')">
                <i class="fas fa-language"></i>
                <p class="sub-sm">Tailoring</p>
            </div>
            <div class="subject-item" onclick="triggerSearch('Maths')"> 
                <i class="fas fa-square-root-alt"></i>
                <p class="sub-sm">Maths</p>
            </div>
        </div>
        <i class="fas fa-chevron-right arrow" onclick="scrollNext()"></i>
    </div>
</div>
<!-- JavaScript to Handle Click Event -->
<script>
function triggerSearch(subject) {
    // Set the value of the search input
    document.getElementById('searchQuery').value = subject;
    
    // Submit the form automatically
    document.querySelector('.form').submit();
}
</script>
<!-- Bootstrap 4 JS -->
<!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->

<!-- Custom JS for Next and Previous Scrolling -->
<script>
    function scrollNext() {
        document.getElementById('subjectList').scrollBy({ left: 120, behavior: 'smooth' });
    }

    function scrollPrev() {
        document.getElementById('subjectList').scrollBy({ left: -120, behavior: 'smooth' });
    }
</script>
