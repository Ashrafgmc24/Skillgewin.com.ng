<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title><?php echo $title; ?></title>
     <!-- Stylesheets -->
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/search.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/sign.css">
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <!-- Bootstrap 4 -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">



    <style>
    *{
        padding: 0px;
        margin: 0px;
        box-sizing: border-box;
    }
       .icon-circle {
            font-size: 40px;
            color: #28a745;
        }
        .step-card {
            text-align: center;
            padding: 20px;
            border-radius: 8}
            
         .card {
            position: relative;
            border-radius: 15px;
            overflow: hidden;
            transition: 0.3s;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
         .card2 {
            text-align: center;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
        .icon-circle2 {
            font-size: 40px;
            color: #28a745;
        }
        
        /*mmmmmmmmmmmm*/
        
        .favorite-icon {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 1.5rem;
            color: #e74c3c;
            cursor: pointer;
        }
        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .card-body {
            padding: 20px;
        }
        .star-rating {
            color: #f39c12;
        }
        .card-text {
            font-size: 14px;
            color: #7f8c8d;
        }
        .card-title {
            font-weight: bold;
        }
        .price {
            font-weight: bold;
            color: #2ecc71;
        }
        .first-lesson {
            color: #e74c3c;
        }
        .search-bar {
            background-color: white;
            border-radius: 50px;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .search-input {
            border: none;
            outline: none;
            background-color: transparent;
            flex-grow: 1;
            font-size: 18px;
            padding-left: 10px;
        }
        .find-tutor-btn {
            background-color: #ff6f61;
            color: #fff;
            border: none;
            border-radius: 25px;
            padding: 10px 25px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
        }
        .subject-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 20px;
        }
        .subject-list {
            display: flex;
            overflow-x: auto;
            scroll-behavior: smooth;
            white-space: nowrap;
            padding: 10px 0;
        }
        .subject-item {
            flex: 0 0 auto;
            width: 120px;
            text-align: center;
            margin-right: 20px;
            color: #333;
        }
        .subject-item i {
            font-size: 24px;
        }
        .arrow {
            font-size: 30px;
            cursor: pointer;
            color: #ff6f61;
        }
        .find-tutor-btn::before {
            /*content: "Find a Tutor";*/
            }
        .sub-sm{
            font-size: 14px;
        }
        .w3-sidebar a { font-family: "Roboto", sans-serif; }
    body, h1, h2, h3, h4, h5, h6, .w3-wide { font-family: "Montserrat", sans-serif; font-weight: bold; }
    p { font-size: 16px; }
    .w3-mytext p{
      text-align: justify;
    }
    .my-ull{
      font-size: 16px;
    }
    .footer {
            background-color: #1c1c1c;
            color: #ffffff;
            padding: 40px 20px;
        }

        .footer-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 20px;
        }

        .footer-column {
            flex: 1;
            min-width: 200px;
        }

        .footer-column h3 {
            font-size: 18px;
            margin-bottom: 15px;
            color: #ffffff;
            font-weight: bold;
        }

        .footer-column ul {
            list-style: none;
            padding: 0;
        }

        .footer-column ul li {
            margin-bottom: 10px;
        }

        .footer-column ul li a {
            color: #ffffff;
            text-decoration: none;
            font-size: 15px;
        }

        .footer-column ul li a:hover {
            color: #ff6f61;
        }

        .footer-social {
            display: flex;
            justify-content: flex-start;
            gap: 10px;
        }

        .footer-social a {
            font-size: 20px;
            color: #ffffff;
            text-decoration: none;
            padding: 10px;
            border-radius: 50%;
            background-color: #3b3b3b;
        }

        .footer-social a:hover {
            background-color: #ff6f61;
        }

        .footer-copyright {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            border-top: 1px solid #3b3b3b;
            padding-top: 15px;
            color: #ccc;
        }

        .mycontainer {
  position: relative;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px 0 30px 0;
}

/* style inputs and link buttons */
.input,
.btn {
  width: 100%;
  padding: 12px;
  border: none;
  border-radius: 4px;
  margin: 5px 0;
  opacity: 0.85;
  display: inline-block;
  font-size: 17px;
  line-height: 20px;
  text-decoration: none; /* remove underline from anchors */
}

.input:hover,
.btn:hover {
  opacity: 1;
}

/* add appropriate colors to fb, twitter and google buttons */
.fb {
  background-color: #3B5998;
  color: white;
}

.twitter {
  background-color: #55ACEE;
  color: white;
}

.google {
  background-color: #dd4b39;
  color: white;
}

/* style the submit button */
.input[type=submit] {
  background-color: #04AA6D;
  color: white;
  cursor: pointer;
}

.input[type=submit]:hover {
  background-color: #45a049;
}

/* Two-column layout */
.col {
  float: left;
  width: 50%;
  margin: auto;
  padding: 0 50px;
  margin-top: 6px;
}

/* Clear floats after the columns */
.myrow:after {
  content: "";
  display: table;
  clear: both;
}

/* vertical line */
.vl {
  position: absolute;
  left: 50%;
  transform: translate(-50%);
  border: 2px solid #ddd;
  height: 175px;
}

/* text inside the vertical line */
.inner {
  position: absolute;
  top: 50%;
  transform: translate(-50%, -50%);
  background-color: #f1f1f1;
  border: 1px solid #ccc;
  border-radius: 50%;
  padding: 8px 10px;
}

/* hide some text on medium and large screens */
.hide-md-lg {
  display: none;
}

/* bottom container */
.bottom-container {
  text-align: center;
  background-color: #666;
  border-radius: 0px 0px 4px 4px;
}
 .my-head{
     font-size: 50px;
 }
 
 .suggestions {
    border: 1px solid #ccc;
    max-height: 150px;
    overflow-y: auto;
    position: absolute;
    background: white;
    z-index: 1000;
}

.suggestion-item {
    padding: 10px;
    cursor: pointer;
}

.suggestion-item:hover {
    background-color: #f0f0f0;
}
.my-form{
    display: flex;
    
}

        @media (max-width: 768px) {
            .my-head{
     font-size: 30px;
 }
            .sub-sm{
            font-size: 11px;
        }
            .col {
    width: 100%;
    margin-top: 0;
  }
  /* hide the vertical line */
  .vl {
    display: none;
  }
  /* show the hidden text on small screens */
  .hide-md-lg {
    display: block;
    text-align: center;
  }
            .find-tutor-btn::before {
                /*content: "\f002";*/
                /*font-family: "Font Awesome 5 Free";*/
                /*font-weight: 900;*/
            }
            .subject-item {
                width: 80px;
                font-size: 12px;
            }
            .w3-mytext .w3-ul{
      text-align: justify;
      font-size: 14px;
    }
    p { font-size: 14px; }
    .card-text{
        font-size: 12px;
    }
    .card-title{
        font-size: 14px;
    }
      h1{
        font-size: 18px;
      } 
      h2{
        font-size: 18px;
      }
      .footer-container {
                flex-direction: column;
                align-items: flex-start;
            }

            .footer-column {
                margin-bottom: 20px;
            }
        }
        /*background-color: #378b29;background-image: linear-gradient(315deg, #378b29 0%, #ffffff 100%);*/
    </style>
</head>
<body class="w3-content" style="max-width:1500px; ">

  <?php include ("include/nav.php"); ?>

  <!-- Top menu on small screens -->
  <header class="w3-bar w3-top w3-hide-large w3-white w3-xlarge w3-border" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <div class="w3-bar-item w3-wide">
    <!-- <img src="img/logo.jpg" style="width: 100px; height: 50px;"> -->
    <h1>
    <img src="img/logo.png" style="width: 150px; height: 40px;" >
    </h1>
    </div>
    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
  </header>

  <!-- Overlay effect when opening sidebar on small screens -->
  <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

  <script>
   
// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}


</script>

 

  <!-- PAGE CONTENT -->
  <div class="w3-main" style="margin-left:250px">

    <!-- Push down content on small screens -->
    <div class="w3-hide-large" style="margin-top:83px"></div>
    <br> <br>
    <!-- Top header -->
    <header class="w3-container w3-xlarge">
      <div class="w3-center">
        <h1 class="w3-center w3-text-green w3-bold my-head" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">SKILLGEWIN</h1>
        <p data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">Empowering you to Acquire, Apply and Win</p>
      </div>
      </header>
     
