<!DOCTYPE html>
<html>
<head>
  <title><?php echo $title; ?></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Stylesheets -->
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" href="css/search.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/sign.css">
  
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  
  <!-- Scripts -->
  <script src="js/w3.js"></script>
  
  <!-- Inline styles -->
  <style>
    .w3-sidebar a { font-family: "Roboto", sans-serif; }
    body, h1, h2, h3, h4, h5, h6, .w3-wide { font-family: "Montserrat", sans-serif; font-weight: bold; }
    p { font-size: 16px; }
    .w3-mytext p{
      text-align: justify;
    }
    .my-ull{
      font-size: 16px;
    }

    @media screen and (max-width: 600px) {
      .w3-mytext .w3-ul{
      text-align: justify;
      font-size: 14px;
    }
    p { font-size: 14px; }
      h1{
        font-size: 18px;
      } 
      h2{
        font-size: 18px;
      }
    }
  </style>
</head>
<body class="w3-content" style="max-width:1500px; background-color: #378b29;background-image: linear-gradient(315deg, #378b29 0%, #ffffff 100%); ">

  <?php include ("include/nav.php"); ?>

  <!-- Top menu on small screens -->
  <header class="w3-bar w3-top w3-hide-large w3-green w3-xlarge">
    <div class="w3-bar-item w3-wide">
    <!-- <img src="img/logo.jpg" style="width: 100px; height: 50px;"> -->
    <p><b>SKILLGEWIN</b></p>
    </div>
    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
  </header>

  <!-- Overlay effect when opening sidebar on small screens -->
  <div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

  <script>
   
// Open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}


</script>



  <!-- PAGE CONTENT -->
  <div class="w3-main" style="margin-left:250px">

    <!-- Push down content on small screens -->
    <div class="w3-hide-large" style="margin-top:83px"></div>
    <br> <br>
    <!-- Top header -->
    <header class="w3-container w3-xlarge">
      <div class="w3-center">
        <h1 class="w3-center w3-text-green w3-bold">SKILLGEWIN</h1>
        <p>Empowering you to Acquire, Apply and Win</p>
      </div>
      
      
      <!-- Section -->
      <section class="w3-container w3-center sect">
        <?php // include 'include/subject.php'; ?>
      </section>
      
