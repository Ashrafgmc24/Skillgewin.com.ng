
    <!-- Footer -->
    <!-- <footer class="w3-padding-64 w3-white w3-small w3-center w3-white" id="footer">
      <section class="w3-row">
        <div class="w3-third w3-container">
          <img src="img/logo.jpg" alt="" style="width: 100px">
          <p>Empowering your journey, one tutor at a time. Unlock your potential with our SaaS tutoring system, designed to guide, inspire, and elevate your success.</p>
          <ul class="w3-bar nav-footer" style="list-style: none; display: flex;">
            <li><a href=""><i class="fab fa-facebook fa-3x"></i> </a></li>
            <li><a href=""><i class="fab fa-twitter fa-3x"></i> </a></li>
            <li><a href=""><i class="fab fa-instagram fa-3x"></i> </a></li>
            <li><a href=""><i class="fab fa-facebook fa-3x"></i> </a></li>
          </ul>
        </div>
        <div class="w3-third w3-container">
          <p>Services</p>
          <div class="nav">
            <a href="index.php" class="w3-bar-item w3-button"><i class="fa fa-home"></i> Home</a>
            <a href="tutor.php" class="w3-bar-item w3-button"><i class="fas fa-chalkboard-teacher"></i> Tutors</a>
            <a href="faqs.php" class="w3-bar-item w3-button"><i class="fa fa-question-circle"></i> FAQs</a>
            <a href="contact.php" class="w3-bar-item w3-button"><i class="fa fa-address-book"></i> Contact</a>

          </div>
        </div>
        <div class="w3-third w3-container">
          <p>Pages</p>
          <div class="nav">
            <a href="terms.php" class="w3-bar-item w3-button"><i class="fa fas fa-file-contract"> </i> Terms and Conditions</a>
            <a href="policy.php" class="w3-bar-item w3-button"><i class="fa fa-shield"></i> Privacy Policy</a>
          </div>
        </div>
      </section>
    </footer> -->

    <!-- Scripts -->
 <hr>
    <footer class="footer w3-white" style="color: black" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <div class="footer-container">
            <div class="footer-column">
                <h3 style="color: black">About</h3>
                <ul>
                    <li><a href="#" style="color: black">Who are we?</a></li>
                    <li><a href="#" style="color: black">Our Values</a></li>
                    <li><a href="#" style="color: black">Terms & Conditions</a></li>
                    <li><a href="#" style="color: black">Privacy Policy</a></li>
                    <li><a href="#" style="color: black">Countries</a></li>
                    <li><a href="#" style="color: black">Online Lessons</a></li>
                    <li><a href="#" style="color: black">Jobs</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h3 style="color: black">All Subjects</h3>
                <ul>
                    <li><a href="#" style="color: black">Arts & Crafts</a></li>
                    <li><a href="#" style="color: black">Professional Development</a></li>
                    <li><a href="#" style="color: black">Computer Sciences</a></li>
                    <li><a href="#" style="color: black">Languages</a></li>
                    <li><a href="#" style="color: black">Music</a></li>
                    <li><a href="#" style="color: black">Health & Well-being</a></li>
                    <li><a href="#" style="color: black">Academic Tutoring</a></li>
                    <li><a href="#" style="color: black">Web Design</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h3 style="color: black">Resources</h3>
                <ul>
                    <li><a href="#" style="color: black">The Blog</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h3 style="color: black">Help</h3>
                <ul>
                    <li style="color: black"><a href="#">Need Help?</a></li>
                    <li><a href="contact.php" style="color: black">Contact</a></li>
                </ul>
            </div>

            <div class="footer-column">
                <h3 style="color: black">Follow Us</h3>
                <div class="footer-social" style="color: black">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>

        <div class="footer-copyright">
            © <?php echo date('Y'); ?> SKILLGEWIN, Learn with the best!
        </div>
    </footer>
 



<!-- Bootstrap 4 JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
        AOS.init(); // Initialize AOS
    </script>

</body>
</html>