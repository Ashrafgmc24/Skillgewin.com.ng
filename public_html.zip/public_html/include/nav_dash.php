<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-dark-gray w3-collapse w3-top w3-animate-left" style="z-index:3;width:250px"  id="mySidebar">
  <div class="w3-container w3-display-container w3-padding-16">
    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
    <h3 class="w3-wide"><b><img src="img/logo.png" width="160px" alt=""></b></h3> 
  </div> 
  <a href="index.php" class="w3-bar-item w3-button"><i class="fas fa-home"></i> Home</a>
  <a href="dashboard.php" class="w3-bar-item w3-button"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="profile.php" class="w3-bar-item w3-button"><i class="fas fa-user-circle"></i> Profile</a>
            <a href="marketplace.php" class="w3-bar-item w3-button"><i class="fa fa-shopping-cart"></i>  Market Place</a>

    <a href="#" class="w3-bar-item w3-button"><i class="fas fa-user-circle"></i> Booking</a>
        <a href="msg.php" class="w3-bar-item w3-button"><i class="fas fa-envelope"></i> Messages</a>
        
    <a href="mytutor.php" class="w3-bar-item w3-button"><i class="fas fa-envelope"></i> Favourite</a>
  
    <a href="logoutuser.php" class="w3-bar-item w3-button w3-red"><i class="fas fa-sign-out-alt"></i> Logout</a>
 
    
    
   <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-button w3-block w3-white w3-left-align" id="myBtn">
    <i class="fa fa-book"></i> Pages <i class="fa fa-caret-down"></i>
    </a>
    <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium">
      <a href="terms.php" class="w3-bar-item w3-button"><i class="fa fas fa-file-contract"></i> Terms and Condition</a>
      <a href="policy.php" class="w3-bar-item w3-button"><i class="fa fa-shield"></i> Privacy Policy</a>
    </div>  
  <!-- </div> -->
 
  <!-- <a href="#footer" class="w3-bar-item w3-button w3-padding">Contact</a> 
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding" onclick="document.getElementById('newsletter').style.display='block'">Newsletter</a> 
  <a href="#footer"  class="w3-bar-item w3-button w3-padding">Subscribe</a> -->
</nav>
<script>

  // Accordion 
function myAccFunc() {
  var x = document.getElementById("demoAcc");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}
function myAccFunc1() {
  var x = document.getElementById("demoAcc1");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else {
    x.className = x.className.replace(" w3-show", "");
  }
}

// Click on the "Jeans" link on page load to open the accordion for demo purposes
document.getElementById("myBtn").click();

</script>