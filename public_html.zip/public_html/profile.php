<?php
session_start();
$title="My Profile";
include "include/webheader_dash.php";
include "include/db_connection.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: loginUser.php");
    exit(); 
}

// Get the current user's ID from the session
$user_id = $_SESSION['user_id'];

// Fetch user data
$sql = "SELECT names, email, profile_img FROM user WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<div class="container my-5 w3-white">
    <h2 class="text-center mb-4">My Profile</h2>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <img src="<?php echo htmlspecialchars($user['profile_img']); ?>" alt="Profile Image" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($user['names']); ?></h5>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                    <!-- Edit Profile Button -->
                    <button class="btn btn-primary" data-toggle="modal" data-target="#editProfileModal">Edit Profile</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Updating Profile -->
<div class="modal fade" id="editProfileModal" tabindex="-1" aria-labelledby="editProfileModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="editProfileForm" method="POST" action="update_profile.php" enctype="multipart/form-data">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                    <div class="form-group">
                        <label for="names">Name</label>
                        <input type="text" class="form-control" name="names" value="<?php echo htmlspecialchars($user['names']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="profile_img">Profile Image</label>
                        <input type="file" class="form-control-file" name="profile_img">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include "include/webfooter.php"; ?>
