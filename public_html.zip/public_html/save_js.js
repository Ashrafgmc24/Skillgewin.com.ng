
$(document).ready(function () {
    $('#nextBtn').on('click', function (e) {
        if (currentTab == $(".tab").length - 1) { // Only submit on the last tab
            e.preventDefault();

            // Show the progress modal
            $('#progressModal').css('display', 'block');

            // Prepare form data for submission
            var formData = new FormData($('#regForm')[0]);

            $.ajax({
                url: 'save_tutor.php',  // The backend PHP script
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                xhr: function () {
                    var xhr = new window.XMLHttpRequest();
                    // Upload progress
                    xhr.upload.addEventListener("progress", function (evt) {
                        if (evt.lengthComputable) {
                            var percentComplete = evt.loaded / evt.total;
                            percentComplete = parseInt(percentComplete * 100);
                            $('#progressBar').css('width', percentComplete + '%');

                            if (percentComplete === 100) {
                                $('#progressBar').css('background-color', 'green');
                            }
                        }
                    }, false);
                    return xhr;
                },
                success: function (response) {
                    var jsonData = JSON.parse(response);
                    if (jsonData.status == "success") {
                        //alert('Tutor saved successfully!');
                        $('#progressModal').css('display', 'none');
                        $('#regForm')[0].reset(); // Reset the form
                        currentTab = 0;
                        showTab(currentTab); // Reset tab navigation
                        window.location.href = 'getready.php';
                    } else {
                        alert(jsonData.message);
                    }
                },
                error: function (xhr, status, error) {
                    console.log('Error:', error);
                    //alert('An error occurred. Please try again.');
                    $('#progressModal').css('display', 'none');
                }
            });
        }
    });
});

