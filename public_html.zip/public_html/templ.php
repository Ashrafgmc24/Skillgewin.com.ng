<?php  
$title = "Home Page";
include 'include/webheader1.php';
?>

<h1 class="w3-center">Signup As:</h1>
<section>

</section>
          
<?php  
include 'include/webfooter.php';
?>
