<?php
session_start();
include "include/db_connection.php";

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch tutors contacted by the user
$sql = "SELECT tutor.id, tutor.names FROM tutor
        JOIN contact_tutor ON tutor.id = contact_tutor.tutor_id
        WHERE contact_tutor.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$tutors = [];
while ($row = $result->fetch_assoc()) {
    $tutors[] = $row;
}

echo json_encode($tutors);
?>
