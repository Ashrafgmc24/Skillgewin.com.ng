<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: loginUser.php");
    exit();
}

$title = "My Dashboard";
include "include/webheader_dash.php";
include "include/db_connection.php";
include "include/mysearch.php";
?>

<!-- Tutor Cards Section -->
<div class="container my-5 w3-white">
    <h2 class="text-center mb-4" data-aos="fade-up" data-aos-delay="200">
        Choose Any Tutor you want! <i class="fas fa-star" style="color: #f39c12;"></i>
    </h2>
    <div class="row" id="tutor-results">
        <!-- Fetch Tutor Data -->
        <?php
        $select = "SELECT * FROM tutor";
        $result = $conn->query($select);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
        ?>
        <div class="col-md-4 mb-4" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
            <div class="card">
                <img src="uploads/<?php echo $row['profile_img']; ?>" alt="Tutor Image" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($row['names']); ?></h5>
                   <p class="card-text w3-text-black"><strong>About You: </strong><?php echo ($row['about_you']); ?></p>
                    <p class="card-text"><?php echo htmlspecialchars($row['webcam_face']); ?></p>
                    <p class="price">₦<?php echo number_format($row['hourly_rate'], 2); ?></p> 

                    <!-- Contact Button Redirects to tutor_detail.php -->
                    <a href="tutor_detail.php?tutor_id=<?php echo $row['id']; ?>" class="w3-btn w3-green">Contact Tutor</a>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
            echo "<p class='text-center'>No tutors found.</p>";
        }
        ?>
    </div>
</div>

<?php include "include/webfooter.php"; ?>
