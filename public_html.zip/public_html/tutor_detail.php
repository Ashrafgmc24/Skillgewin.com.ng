<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: loginUser.php");
    exit();
}

include "include/webheader1.php";
include "include/db_connection.php";

// Get the tutor_id from the URL
$tutor_id = isset($_GET['tutor_id']) ? intval($_GET['tutor_id']) : 0;

if ($tutor_id == 0) {
    // Redirect if no valid tutor_id is provided
    header("Location: dashboard.php");
    exit();
}

// Fetch the tutor details from the database
$stmt = $conn->prepare("SELECT * FROM tutor WHERE id = ?");
$stmt->bind_param("i", $tutor_id);
$stmt->execute();
$result = $stmt->get_result();
$tutor = $result->fetch_assoc();

if (!$tutor) {
    echo "<p class='text-center'>Tutor not found.</p>";
    include "include/webfooter.php";
    exit();
}
?>

<!-- Tutor Detail Section -->
<div class="container my-5">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
            <img src="uploads/<?php echo htmlspecialchars($tutor['profile_img']); ?>" alt="Tutor Image" class="card-img-top">
        </div> </div>
        <div class="col-md-6">
            <h3><?php echo htmlspecialchars($tutor['names']); ?></h3>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($tutor['locations']); ?></p>
            <p><strong>Experience:</strong> <?php echo htmlspecialchars($tutor['experience']); ?></p>
            <p><strong>Webcam:</strong> <?php echo htmlspecialchars($tutor['webcam_face']); ?></p>
            <p><strong>Hourly Rate:</strong> ₦<?php echo number_format($tutor['hourly_rate'], 2); ?></p>
            <p><strong>Reviews:</strong> <?php echo htmlspecialchars($tutor['reviews']); ?></p>
            
            <!-- Message Tutor Button -->
            <form method="POST" action="message_tutor.php">
                <input type="hidden" name="tutor_id" value="<?php echo $tutor_id; ?>">
                <button type="submit" class="w3-btn w3-green">Message Tutor</button>
            </form>
        </div>
    </div>
</div>

<?php include "include/webfooter.php"; ?>
