<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'include/db_connection.php'; // Include your database connection file

    $name = $_POST['txtname'];
    $email = $_POST['txtemail'];
    $phone = $_POST['txtphone'];
    $password = $_POST['txtpass'];
    $country = $_POST['country'];
    $location = $_POST['txtlocation'];
    $experience = $_POST['txtexperience'];
    $subject = $_POST['txtsubject'];
    $txtskillDetails = $_POST['skillDetails'];
    $txtacademicSubject = $_POST['academicSubject'];
    $title = $_POST['txttitle'];
    $aboutLesson = $_POST['txtaboutlesson'];
    $aboutYou = $_POST['txtaboutyou']; 
    $hourlyRate = $_POST['txthour'];

    // File upload handling (for profile image)
    $allowedTypes = ['image/jpeg', 'image/png'];
    $maxFileSize = 3 * 1024 * 1024; // 3MB

    if (isset($_FILES['profile']) && $_FILES['profile']['error'] === UPLOAD_ERR_OK) {
        $profileImage = $_FILES['profile']['name'];
        $profileImageType = $_FILES['profile']['type'];
        $profileImageSize = $_FILES['profile']['size'];
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($profileImage);
        
        // Validate file type
        if (!in_array($profileImageType, $allowedTypes)) {
            echo json_encode(['status' => 'error', 'message' => 'Only JPG and PNG images are allowed.']);
            exit();
        }

        // Validate file size
        if ($profileImageSize > $maxFileSize) {
            echo json_encode(['status' => 'error', 'message' => 'File size must be less than 3MB.']);
            exit();
        }

        // Move the uploaded file
        if (!move_uploaded_file($_FILES['profile']['tmp_name'], $targetFile)) {
            echo json_encode(['status' => 'error', 'message' => 'Error uploading the file.']);
            exit();
        }
    } else {
        $profileImage = null;
    }

    // Insert into the database
    $sql = "INSERT INTO tutor (names, email, phone, passwords, country, locations, experience, subjects, skills, academic,
    title, about_lesson, about_you, hourly_rate, profile_img) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssss", $name, $email, $phone, $password, $country, $location, $experience, $subject, $txtskillDetails, $txtacademicSubject, $title, $aboutLesson, $aboutYou, $hourlyRate, $profileImage);



    if ($stmt->execute()) {
        $_SESSION["ready"] = "Okay";
        $_SESSION["usernameT"] = $_POST['txtname'];
        $_SESSION["email"] = $email;
        $_SESSION["name"] = $name;
        $_SESSION['tutor_id'] = $email;
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error saving the tutor data']);
    }

    $stmt->close();
    $conn->close();
}
?>






<?php
// save_tutor.php

// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     include 'include/db_connection.php'; // Include your database connection file

//     $name = $_POST['txtname'];
//     $email = $_POST['txtemail'];
//     $phone = $_POST['txtphone'];
//     $password = $_POST['txtpass'];
//     $location = $_POST['txtlocation'];

//     $experience = $_POST['txtexperience'];
//     $subject = $_POST['txtsubject'];
//     $title = $_POST['txttitle'];
//     $aboutLesson = $_POST['txtaboutlesson'];
//     $aboutYou = $_POST['txtaboutyou'];
//     $hourlyRate = $_POST['txthour'];

//     // File upload handling (for profile image)
//     if (isset($_FILES['profile'])) {
//         $profileImage = $_FILES['profile']['name'];
//         $targetDir = "uploads/";
//         $targetFile = $targetDir . basename($profileImage);
//         move_uploaded_file($_FILES['profile']['tmp_name'], $targetFile);
//     } else {
//         $profileImage = null;
//     }

//     // Insert into the database
//     $sql = "INSERT INTO tutor (names, email, phone, passwords, locations, experience, subjects, 
//     title, about_lesson, about_you, hourly_rate, profile_img) 
//             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
//     $stmt = $conn->prepare($sql);
//     $stmt->bind_param("ssssssssssss", $name, $email, $phone, $password, $location, $experience, $subject, $title, $aboutLesson, $aboutYou, $hourlyRate, $profileImage);
    
//     if ($stmt->execute()) {
//         $_SESSION["ready"] = "Okay";
//         $_SESSION["usernameT"] = $_POST['txtname'];
//         echo json_encode(['status' => 'success']);
      
//         // echo "<script>
//         //  </script>";

//     } else {
//         echo json_encode(['status' => 'error', 'message' => 'Error saving the tutor data']);
//     }
    
//     $stmt->close();
//     $conn->close();
// }
?>
