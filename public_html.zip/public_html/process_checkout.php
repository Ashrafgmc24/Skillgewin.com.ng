<?php
session_start();
include 'include/db_connection.php';
include 'include/webheader1.php';

// Ensure cart is not empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    echo "Your cart is empty.";
    exit();
}

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $name = $_POST['name'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];

    // Calculate the total price of the order
    $total_price = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total_price += $item['price'] * $item['quantity'];
    }

    // Insert the order into the orders table
    $stmt = $conn->prepare("INSERT INTO orders (customer_name, shipping_address, payment_method, total_price) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssd", $name, $address, $payment_method, $total_price);
    
    if ($stmt->execute()) {
        // Get the last inserted order ID
        $order_id = $conn->insert_id;

        // Insert each cart item into the order_items table
        foreach ($_SESSION['cart'] as $product_id => $item) {
            $quantity = $item['quantity'];
            $price = $item['price'];
            $subtotal = $price * $quantity;

            $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)");
            $stmt_item->bind_param("iiidd", $order_id, $product_id, $quantity, $price, $subtotal);
            $stmt_item->execute();
        }

        // Clear the cart after successful order
        unset($_SESSION['cart']);

        // Display success message
        echo "<h2>Thank you, $name! Your order has been placed successfully.</h2>";
        echo "<p>Shipping to: $address</p>";
        echo "<p>Payment Method: $payment_method</p>";
        echo "<p>Total Amount: $" . number_format($total_price, 2) . "</p>";
    } else {
        echo "There was an error processing your order. Please try again.";
    }
} else {
    echo "Invalid request.";
}
include 'include/webfooter.php';

?>
