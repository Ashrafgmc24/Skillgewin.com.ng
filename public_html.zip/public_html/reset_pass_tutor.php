<?php
session_start();
$title = "Reset Password";
include 'include/webheader1.php'; 
include 'include/db_connection.php'; // Database connection

if (isset($_POST['reset_password'])) {
    $email = $_POST['email'];
    $token = $_POST['token'];
    $new_password = $_POST['new_password'];

    // Verify the token and email in the database
    $query = $conn->prepare("SELECT * FROM password_resets WHERE email = ? AND token = ? AND expiry > NOW()");
    // AND expiry > NOW()
    $query->bind_param("ss", $email, $token);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        // If token and email match, update the password
        $hashed_password = $new_password; // You can hash the password if needed

        $update_query = $conn->prepare("UPDATE tutor SET passwords = ? WHERE email = ?");
        $update_query->bind_param("ss", $hashed_password, $email);

        if ($update_query->execute()) {
            // Delete the token after a successful password update
            $delete_query = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
            $delete_query->bind_param("s", $email);
            $delete_query->execute();

            //echo "<script>alert('Password has been updated successfully.');</script>";
                        echo "<script> window.location.href='loginTutor.php';</script>";

        } else {
            echo "<script>alert('Error updating password. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Invalid or expired token.');</script>";
    }
}
?>

<!-- HTML Form for entering token and new password -->
<div class="mycontainer w3-white" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <label>Email:</label>
                <input type="email" name="email" placeholder="Enter your email" required>
                
                <label>Reset Code:</label>
                <input type="text" name="token" placeholder="Enter the reset code" required>
                
                <label>New Password:</label>
                <input type="password" name="new_password" placeholder="Enter your new password" required>
                <hr>
                <input type="submit" name="reset_password" value="Reset Password">
            </form>
        </div>
    </div>
</div>
<?php  
include 'include/webfooter.php'; 
?>
